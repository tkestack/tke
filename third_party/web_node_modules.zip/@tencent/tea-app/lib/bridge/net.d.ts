export declare const net: {};
