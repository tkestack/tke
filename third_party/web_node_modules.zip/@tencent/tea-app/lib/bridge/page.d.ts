export declare const page: {};
