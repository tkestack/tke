export declare const router: {};
