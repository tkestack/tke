import { Moment } from "moment";
import { TimePickerProps } from "./TimeProps";
export declare function getHourMinuteSecond(time: Moment): {
    hour: number;
    minute: number;
    second: number;
};
/**
 * 解析 format
 * @param format
 */
export declare function genShowHourMinuteSecond(format: string): {
    showHour: boolean;
    showMinute: boolean;
    showSecond: boolean;
};
/**
 * 获取 disabled 部分
 */
export declare function getDisabledHours({ range, disabledHours, }: Partial<TimePickerProps>): number[];
export declare function getDisabledMinutes(hour: number, { range, disabledMinutes }: Partial<TimePickerProps>): number[];
export declare function getDisabledSeconds(hour: number, minute: number, { range, disabledSeconds }: Partial<TimePickerProps>): number[];
/**
 * 获取自动调整后的合法值
 */
export declare function getValidTimeValue(value: Moment, rangeOptions?: Partial<TimePickerProps>, format?: string): Moment;
