/// <reference types="react" />
import { TimePickerProps } from "./TimeProps";
export declare function Combobox({ value: _value, onChange, format, hourStep, minuteStep, secondStep, ...props }: Partial<TimePickerProps>): JSX.Element;
