/// <reference types="react" />
import { TimePickerProps } from "./TimeProps";
export declare function TimeTable({ caption, ...props }: TimePickerProps): JSX.Element;
