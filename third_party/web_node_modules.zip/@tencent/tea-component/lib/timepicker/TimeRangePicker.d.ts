/// <reference types="react" />
import { ControlledProps } from "../form/controlled";
import { Combine, Omit } from "../_type";
import { TimeDisabledProps, TimePickerProps } from "./TimeProps";
import { RangeDateType } from "../calendar/DateProps";
import { CommonDatePickerProps } from "../datepicker";
export interface TimeRangePickerProps extends Combine<Omit<CommonDatePickerProps, "header">, ControlledProps<RangeDateType>, Pick<TimePickerProps, "hourStep" | "minuteStep" | "secondStep">> {
    /**
     * 分隔符
     * @default ~
     */
    separator?: string;
    /**
     * placeholder
     * @default “选择时间”
     */
    placeholder?: string;
    /**
     * 日期展示格式
     * @default "HH:mm:ss"
     */
    format?: string;
    /**
     * 不可选的时间
     */
    disabledTime?: (dates: RangeDateType, partial: "start" | "end") => TimeDisabledProps;
}
export declare const TimeRangePicker: ((props: TimeRangePickerProps) => JSX.Element) & {
    defaultLabelAlign: string;
};
