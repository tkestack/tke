/// <reference types="react" />
import { TimePickerProps } from "./TimeProps";
export declare const TimePicker: ((props: TimePickerProps) => JSX.Element) & {
    defaultLabelAlign: string;
    RangePicker: ((props: import("./TimeRangePicker").TimeRangePickerProps) => JSX.Element) & {
        defaultLabelAlign: string;
    };
};
