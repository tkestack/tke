import React from "react";
import { TreeNode, TreeNodeProps } from "./TreeNode";
import { TreeContextValue } from "./TreeContext";
import { StyledProps, Omit } from "../_type";
export interface TreeData extends Omit<TreeNodeProps, "children"> {
    /**
     * 子节点数据
     */
    children?: TreeData[];
}
export interface TreeProps extends StyledProps {
    /**
     * 树节点是否支持选择
     *
     * @default false
     */
    selectable?: boolean;
    /**
     * 节点选择是否完全受控（父子节点状态取消关联）
     *
     * @default false
     */
    selectStrictly?: boolean;
    /**
     * 默认选中的节点
     */
    defaultSelectedIds?: string[];
    /**
     * 选中的节点（受控）
     */
    selectedIds?: string[];
    /**
     * 选择事件回调
     */
    onSelect?: (selectedIds: string[], context?: {
        selected: boolean;
        nodeId: string;
    }) => void;
    /**
     * 树节点是否支持点击高亮
     *
     * @default false
     */
    activable?: boolean;
    /**
     * 默认高亮的节点
     */
    defaultActiveIds?: string[];
    /**
     * 高亮的节点（受控）
     */
    activeIds?: string[];
    /**
     * 点击高亮事件回调
     */
    onActive?: (activeIds: string[], context?: {
        active: boolean;
        nodeId: string;
    }) => void;
    /**
     * 默认展开的节点
     */
    defaultExpandedIds?: string[];
    /**
     * 展开的节点（受控）
     */
    expandedIds?: string[];
    /**
     * 展开/收起事件回调
     */
    onExpand?: (expandedIds: string[], context?: {
        expanded: boolean;
        nodeId: string;
    }) => void;
    /**
     * 异步加载数据
     *
     * **需要返回 Promise**
     *
     * 节点展开时在 onExpand 前被调用，直到 Promise resolve 后调用 onExpand
     */
    onLoad?: TreeContextValue["onLoad"];
    /**
     * 异步加载数据失败回调
     *
     * onLoad Promise reject 后调用
     */
    onLoadError?: TreeContextValue["onLoadError"];
    /**
     * 树节点的展开/收起图标
     *
     * @docType React.ReactNode | (context: { expanded: boolean }) => React.ReactNode
     */
    switcherIcon?: TreeContextValue["switcherIcon"];
    /**
     * 树节点数据，如果设置则无需手动构造 <TreeNode />
     */
    data?: TreeData[];
    /**
     * 包含的树节点 <TreeNode />
     */
    children?: React.ReactNode;
}
export declare function isTreeNode(node: React.ReactNode): node is React.ReactComponentElement<typeof TreeNode, TreeNodeProps>;
export declare function Tree({ data, children, ...props }: TreeProps): JSX.Element;
export declare namespace Tree {
    var Node: ((props: TreeNodeProps) => JSX.Element) & {
        ActionLink: ({ children, className, ...props }: React.AnchorHTMLAttributes<HTMLAnchorElement>) => JSX.Element;
    };
}
export declare function TreeView({ selectable, selectStrictly, selectedIds, defaultSelectedIds, onSelect, activable, activeIds, defaultActiveIds, onActive, expandedIds, defaultExpandedIds, onExpand, onLoad, onLoadError, switcherIcon, className, style, children, }: TreeProps): JSX.Element;
