import React from "react";
export interface TreeContextValue {
    /**
     * 树节点是否可选择
     *
     * @default false
     */
    selectable: boolean;
    /**
     * 树节点是否支持点击高亮
     *
     * @default false
     */
    activable: boolean;
    /**
     * 高亮的节点
     */
    activeIds: string[];
    /**
     * 展开的节点
     */
    expandedIds: string[];
    /**
     * 异步加载
     */
    onLoad?: (id: string) => Promise<void>;
    /**
     * 异步加载失败
     */
    onLoadError?: (id: string, error: Error) => void;
    /**
     * 点击高亮
     */
    onActive?: (id: string) => void;
    /**
     * 展开/收起
     */
    onExpand?: (id: string, expanded: boolean) => void;
    /**
     * 树节点的展开/收起图标
     */
    switcherIcon?: ((context: {
        expanded: boolean;
    }) => React.ReactNode) | React.ReactNode;
}
export declare const TreeContext: React.Context<TreeContextValue>;
