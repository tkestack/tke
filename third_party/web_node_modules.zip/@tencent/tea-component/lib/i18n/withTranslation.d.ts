import { ComponentClass } from "react";
export declare function withTranslation<C extends ComponentClass<any>>(WrappedComponent: C): C;
