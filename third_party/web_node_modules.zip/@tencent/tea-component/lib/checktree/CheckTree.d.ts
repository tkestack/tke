import React from "react";
import { CheckChangeContext } from "../check/Check";
import { ControlledProps } from "../form/controlled";
export interface CheckTreeProps extends ControlledProps<string[]> {
    /**
     * 已勾选的叶子节点的 name 集合
     */
    value?: string[];
    /**
     * 勾选的节点变更时回调
     */
    onChange?: (value: string[], context: CheckChangeContext) => void;
    /**
     * 提供树的节点关系，每个子节点对应其父节点
     */
    relations: CheckTreeRelation;
    /**
     * 组件树内容，内部的 <Checkbox /> 状态将被托管
     */
    children?: React.ReactNode;
    /**
     * 禁用的控件 name
     */
    disabledNames?: string[];
    /**
     * 是否支持按 Shift 快捷键时多选
     * @default true
     */
    shiftSelect?: boolean;
}
/**
 * CheckTree 关系定义 interface
```ts
interface CheckTreeRelation {
  [child: string]: string;
}
```
 */
export interface CheckTreeRelation {
    [child: string]: string;
}
export declare function CheckTree(props: CheckTreeProps): JSX.Element;
