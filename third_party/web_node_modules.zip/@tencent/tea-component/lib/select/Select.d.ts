import React from "react";
import { Combine, StyledProps } from "../_type";
import { DropdownProps, CommonDropdownProps } from "../dropdown";
import { ControlledProps } from "../form";
import { SelectOptionWithGroup } from "./SelectOption";
import { SizeType } from "../input";
import { SelectSearchProps } from "./SelectProps";
export interface SelectProps extends Combine<SelectSearchProps<SelectOptionWithGroup>, CommonDropdownProps, StyledProps, ControlledProps<string>> {
    /**
     * 下拉选框类型，默认为 `native`，使用原生下拉框
     *
     * 设置为 `simulate` 则使用模拟下拉框
     *
     * @default "native"
     */
    type?: "native" | "simulate";
    /**
     * 下拉选项列表
     */
    options?: SelectOptionWithGroup[];
    /**
     * 分组
     */
    groups?: {
        [groupKey: string]: React.ReactNode;
    };
    /**
     * 占位符
     * @default "请选择"（已处理国际化）
     */
    placeholder?: string;
    /**
     * 展开时回调，仅对 `type = "simulate"` 有效
     */
    onOpen?: DropdownProps["onOpen"];
    /**
     * 收起时回调，仅对 `type = "simulate"` 有效
     */
    onClose?: DropdownProps["onClose"];
    /**
     * 下拉选框的外观，仅对 `type = "simulate"` 有效
     *
     * - `default` 无边框，适用于页面标题和表格内
     * - `button` 为按钮风格，有边框，多用于操作栏中
     * - `link` 为超链接风格
     * - `filter` 为过滤组件风格，多用于表头筛选
     * - `pure` 无额外样式
     *
     * 原有 `raw` 类型建议使用 `pure` 进行改造
     *
     * @default "default"
     */
    appearence?: DropdownProps["appearence"];
    /**
     * 是否禁用下拉选择
     * @default false
     */
    disabled?: boolean;
    /**
     * 下拉按钮的内容，只对 `type = "simulate"` 有效，如果不传，默认会使用选中的选项的内容
     */
    button?: DropdownProps["button"];
    /**
     * 下拉按钮尺寸，使用 `"full"` 撑满容器宽度
     */
    size?: SizeType | "auto";
    /**
     * `options` 滚动至底部的回调，只对 `type = "simulate"` 有效
     */
    onScrollBottom?: (event: React.UIEvent) => void;
    /**
     * 弹出区域尺寸（宽度）是否同步按钮尺寸，仅对 `type = "simulate"` 有效
     *
     * @default false
     */
    boxSizeSync?: boolean;
    /**
     * 弹出区域自定义类名，仅对 `type = "simulate"` 有效
     */
    boxClassName?: DropdownProps["boxClassName"];
    /**
     * 弹出区域自定义样式，仅对 `type = "simulate"` 有效
     */
    boxStyle?: DropdownProps["boxStyle"];
    /**
     * 状态提示，仅对 `type = "simulate"` 有效
     *
     * 可使用字符串或 [StatusTip](/component/tips) 相关组件
     */
    tips?: React.ReactNode;
    /**
     * 支持搜索，仅对 `type = "simulate"` 有效
     * @default false
     */
    searchable?: boolean;
}
export declare function Select(props: SelectProps): JSX.Element;
export declare namespace Select {
    var Multiple: ((props: import("./SelectMultiple").SelectMultipleProps) => JSX.Element) & {
        defaultLabelAlign: string;
    };
    var defaultLabelAlign: string;
}
