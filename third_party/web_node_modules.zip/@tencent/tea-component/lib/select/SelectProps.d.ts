export interface SelectSearchProps<T> {
    /**
     * 支持搜索
     * @default false
     */
    searchable?: boolean;
    /**
     * 搜索框占位符
     */
    searchPlaceholder?: string;
    /**
     * 自定义搜索筛选规则
     *
     * 默认根据输入值筛选
     */
    filter?: (inputValue: string, option: T) => boolean;
    /**
     * 搜索值变化回调
     */
    onSearch?: (inputValue: string) => void;
}
