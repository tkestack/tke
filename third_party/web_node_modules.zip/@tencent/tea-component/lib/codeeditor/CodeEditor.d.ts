import React from "react";
import { StyledProps } from "../_type";
declare type BasicType = string | boolean | number | (string | boolean | number)[];
declare type ExtractBasic<T> = Extract<T, BasicType>;
declare type PickBasic<T> = {
    [key in keyof T]: T[key] extends {
        [key: string]: any;
    } ? PickBasic<T[key]> : ExtractBasic<T[key]>;
};
declare type IEditorOptions = import("monaco-editor").editor.IEditorOptions;
declare type IEditorConstructionOptions = import("monaco-editor").editor.IEditorConstructionOptions;
/**
 * `options` 详见： [IEditorConstructionOptions](https://microsoft.github.io/monaco-editor/api/interfaces/monaco.editor.ieditorconstructionoptions.html)
 */
export interface CodeEditorOptions extends PickBasic<IEditorConstructionOptions> {
}
export interface CodeEditorProps extends StyledProps {
    /**
     * 编辑器配置，会合并下面的默认值：
      ```js
      { "language": "javascript" }
      ```
     * 该配置只有在初始渲染时传入有效，后续传入不再生效。
     * 支持的配置请参考： [IEditorConstructionOptions](https://microsoft.github.io/monaco-editor/api/interfaces/monaco.editor.ieditorconstructionoptions.html)
     *
     * > 注意：由于 `options` 经过 JSON 序列化给到 iframe，所以配置中传入函数的方式都会无效
     */
    options?: CodeEditorOptions;
    /**
     * 是否自动获得焦点
     * @default false
     */
    autoFocus?: boolean;
    /**
     * 加载时显示的文本
     */
    loadingPlaceholder?: React.ReactChild;
    /** 发生编辑时回调 */
    onEdit?: (editor: CodeEditorInstance) => void;
    /** 发生保存（Ctrl + S）时回调 */
    onSave?: (editor: CodeEditorInstance) => void;
    /** 编辑器可用时回调 */
    onReady?: (editor: CodeEditorInstance) => void;
    /**
     * 供 iframe 加载的 URL 地址
     *
     * 当默认提供的 Editor 不满足要求时，可定制页面供 iframe 加载，实现可参考：[tea-component/src/codeeditor/frame](https://git.code.oa.com/CFETeam/tea2/tree/master/tea-component/src/codeeditor/frame)
     */
    src?: string;
}
export interface CodeEditorInstance {
    /**
     * 异步获取编辑器当前文本
     */
    getValue(options?: {
        preserveBOM: boolean;
        lineEnding: "\n" | "\r\n";
    }): Promise<string>;
    /**
     * 设置编辑器当前文本
     * @param value
     */
    setValue(value: string): void;
    /**
     * 聚焦编辑器
     */
    focus(): void;
    /**
     * 更新配置
     */
    updateOptions(newOptions: IEditorOptions): void;
}
export declare function CodeEditor(props: CodeEditorProps): JSX.Element;
export {};
