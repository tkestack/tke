export declare function prepareMonaco(): Promise<typeof monaco>;
