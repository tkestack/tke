/// <reference types="react" />
import { BasicLineProps } from "../basicline";
import { Omit } from "../_type";
/**
 * CompareLine 组件支持的属性。
 */
export interface CompareLineProps extends Omit<BasicLineProps, "color"> {
    /**
     * 使用颜色来区分的数据系列（属性名）
     */
    color?: string;
}
export declare function CompareLine(props: CompareLineProps): JSX.Element;
