import React from "react";
import { EmptyTip } from "./EmptyTip";
import { LoadingTip } from "./LoadingTip";
import { ErrorTip } from "./ErrorTip";
import { FoundTip } from "./FoundTip";
import { StyledProps } from "../_type";
export interface StatusTipProps extends StyledProps {
    status: "empty" | "loading" | "found" | "error";
    /**
     * 空数据提示文案
     * @default "暂无数据"
     */
    emptyText?: React.ReactNode;
    /**
     * 加载文案
     * @default "加载中..."
     */
    loadingText?: React.ReactNode;
    /**
     * 错误时的提示文案
     * @default "加载失败"
     */
    errorText?: React.ReactNode;
    /**
     * 重试文案
     * 在 `status = “error"` 且包含 `onRetry` 时展现
     * @default "重试"
     */
    retryText?: React.ReactNode;
    /**
     * 找到结果时的文案
     * @default "找到下列结果"
     */
    foundText?: React.ReactNode;
    /**
     * 清空结果提示文案
     * 在 `status = found"` 且包含 `onClear` 时展现
     * @default "返回原列表"
     */
    clearResultText?: React.ReactNode;
    /**
     * `status = "found"` 时，用户点击 `clearResultText` 时回调。如果传空，则不渲染返回操作
     */
    onClear?: () => void;
    /**
     * `status = "error"` 时，用户点击 `retryText` 时回调。如果传空，则不渲染重试操作
     */
    onRetry?: () => void;
    /**
     * 隐藏图标
     * @default false
     */
    hideIcon?: boolean;
}
export declare const StatusTip: (({ status, emptyText, loadingText, errorText, foundText, clearResultText, retryText, onClear, onRetry, ...styledProps }: StatusTipProps) => JSX.Element) & {
    LoadingTip: typeof LoadingTip;
    EmptyTip: typeof EmptyTip;
    FoundTip: typeof FoundTip;
    ErrorTip: typeof ErrorTip;
};
