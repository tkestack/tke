import React from "react";
import { StyledProps } from "../_type";
export interface FoundTipProps extends StyledProps {
    /**
     * 找到结果的文案
     * @default "找到下列结果"
     */
    foundText?: React.ReactNode;
    /**
     * 清空结果提示文案
     * @default "返回原列表"
     */
    clearResultText?: React.ReactNode;
    /**
     * 返回原列表时回调，如果不传则不渲染此操作
     */
    onClear?: () => void;
}
export declare function FoundTip(props: FoundTipProps): JSX.Element;
