import React from "react";
import { StyledProps } from "../_type";
export interface ErrorTipProps extends StyledProps {
    /**
     * 错误文案
     * @default "加载失败"
     */
    errorText?: React.ReactNode;
    /**
     * 重试文案
     * @default "重试"
     */
    retryText?: React.ReactNode;
    /**
     * 重试时回调，如果传空，则不进行重试
     */
    onRetry?: () => void;
    /**
     * 隐藏图标
     * @default false
     */
    hideIcon?: boolean;
}
export declare function ErrorTip(props: ErrorTipProps): JSX.Element;
