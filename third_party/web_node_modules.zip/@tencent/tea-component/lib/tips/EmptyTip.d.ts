import React from "react";
import { StyledProps } from "../_type";
export interface EmptyTipProps extends StyledProps {
    /**
     * 空数据提示文案
     * @default "暂无数据"
     */
    emptyText?: React.ReactNode;
}
export declare function EmptyTip(props: EmptyTipProps): JSX.Element;
