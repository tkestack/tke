import React from "react";
import { ModalProps } from "./ModalMain";
import { Combine } from "../_type";
/**
 * API 的方式唤起一个告警对话框
 * @param options
 * @returns 异步返回布尔值，为 true 则表示用户确认，为 false 则表示用户取消
 */
export declare function alert(options: AlertOptions): Promise<void>;
/**
 * API 的方式唤起一个对话框显示成功信息
 */
export declare function success(options: Pick<AlertOptions, Exclude<keyof AlertOptions, "type">>): Promise<void>;
/**
 * API 的方式唤起一个对话框显示失败信息
 */
export declare function error(options: Pick<AlertOptions, Exclude<keyof AlertOptions, "type">>): Promise<void>;
/**
 *  `Modal.success`、`Modal.error` 及 `Modal.alert` 方法接收以下参数：
 */
export interface AlertOptions {
    /**
     * 提示类型
     */
    type?: "error" | "warning" | "success" | "pending" | "infoblue";
    /**
     * 要提示的消息
     */
    message: React.ReactNode;
    /**
     * 可选的详细解释
     */
    description?: React.ReactNode;
    /**
     * 默认告警对话框有唯一的关闭按钮
     *
     * 此处配置按钮的文案
     */
    buttonText?: React.ReactNode;
    /**
     * 如果对话框需要多个按钮，或者需要给按钮绑定事件，可直接传入按钮数组
     *
     * 此配置会覆盖 `buttonText` 的配置
     */
    buttons?: React.ReactElement[];
    /**
     * 对话框尺寸，决定对话框的宽度，详见 ModalProps 中 `size` 属性
     */
    size?: ModalProps["size"];
    /**
     * 是启用点击遮罩关闭
     * @default true
     */
    maskClosable?: boolean;
}
export interface ModalAlertProps extends Combine<ModalProps, AlertOptions> {
    onButtonClick(): void;
}
/**
 * 提供原始的 ModalAlert 组件。
 * 推荐使用 `Modal.success()` / `Modal.error()` API 来简化用法
 */
export declare function ModalAlert({ type, message, description, ...modalProps }: ModalAlertProps): JSX.Element;
