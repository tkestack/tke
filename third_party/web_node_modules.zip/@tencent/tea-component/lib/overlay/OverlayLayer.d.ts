import React, { HTMLProps } from "react";
import { TransitionProps } from "react-transition-group/Transition";
import { Placement } from "popper.js";
import { RefHandler, PopperChildrenProps, PopperProps } from "react-popper";
import { Omit } from "../_type";
export interface OverlayLayerProps {
    /**
     * 覆盖层内容
     * @docType React.ReactNode | ((props: OverlayContentProps) => React.ReactNode)
     */
    content: React.ReactNode | ((props: OverlayContentProps) => React.ReactNode);
    /**
     * 参考的定位内容
     *
     * 如果提供了 referenceElement，则不通过 `children` 定位，可以实现自定义定位参考
     * @see https://github.com/FezVrasta/react-popper#usage-without-a-reference-htmlelement
     */
    referenceElement?: PopperProps["referenceElement"];
    /**
     * 用于获取覆盖层 DOM Ref
     */
    overlayRef?: RefHandler;
    /**
     * 自定义覆盖层属性，会附加到覆盖层的 div 上
     *
     * 要使用 `ref`，请传入 `overlayRef`
     */
    overlayProps?: HTMLProps<HTMLElement>;
    /**
     * 覆盖层相对于定位元素的位置
     * @default "bottom-start"
     */
    placement?: Placement;
    /**
     * 覆盖层偏离定位元素的距离
     * @default 5
     */
    placementOffset?: number;
    /**
     * 覆盖层是否可见
     */
    visible?: boolean;
    /**
     * 出现时渐变动画时长
     * @default { enter: 50, exit: 300 }
     */
    transitionTimeout?: TransitionProps["timeout"];
    /**
     * 是否在 `resize` 和 `scroll` 事件发生的时候更新位置
     * @default true
     */
    updateOnDimensionChange?: boolean;
    /**
     * 出现动画滑动距离
     * @default 2
     */
    animationScaleFrom?: number;
}
export interface OverlayContentProps extends Omit<PopperChildrenProps, "ref" | "style"> {
    visible: boolean;
}
/**
 * 为定位元素创建一个覆盖层
 *
 * @example
 *
  ```js
  const [visible, setVisible] = useState(false);
  const open = () => setVisible(true);
  const close = () => setVisible(false);
  <Overlay
    visible={visible}
    content={<div>我是浮层内容，<a onClick={close}>关闭</a></div>}
    children={ref => <a ref={ref} onClick={open}>点击弹出浮层</a>}
  />
  ```
 */
export declare function OverlayLayer({ content, overlayRef, overlayProps, placement, visible, placementOffset, transitionTimeout, updateOnDimensionChange, referenceElement, animationScaleFrom, }: OverlayLayerProps): React.ReactPortal;
