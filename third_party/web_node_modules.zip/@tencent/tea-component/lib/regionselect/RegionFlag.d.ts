/// <reference types="react" />
export interface RegionFlagProps {
    flag?: string;
}
export declare function RegionFlag({ flag }: RegionFlagProps): JSX.Element;
