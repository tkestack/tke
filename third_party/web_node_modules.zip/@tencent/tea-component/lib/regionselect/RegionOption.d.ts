import React from "react";
export interface RegionOptionProps {
    /**
     * 地域值
     */
    value: string;
    /**
     * 地域显示文案
     */
    children?: React.ReactNode;
    /**
     * 已废弃
     * @deprecated
     */
    flag?: string;
    /**
     * 已废弃
     * @deprecated
     */
    country?: string;
    /**
     * 是否被选中
     *
     * **如在 `RegionSelect` 中使用，无需传值**
     */
    selected?: boolean;
    /**
     * 是否显示提醒小红点
     * @default false
     */
    dot?: boolean;
    /**
     * 被点击时回调
     */
    onClick?: React.MouseEventHandler;
}
export interface RegionOptionContext {
    inject(props: RegionOptionProps): RegionOptionProps;
}
export declare const RegionOptionContext: React.Context<RegionOptionContext>;
export declare function RegionOption(props: RegionOptionProps): JSX.Element;
