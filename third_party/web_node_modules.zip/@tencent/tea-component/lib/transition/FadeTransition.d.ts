/// <reference types="react" />
import { TransitionProps } from "react-transition-group/Transition";
export interface FadeTransitionProps extends Partial<TransitionProps> {
    /**
     * 目标出现时的透明度，默认为 1
     */
    opacity?: number;
}
export declare function FadeTransition({ opacity, timeout, ...rest }: FadeTransitionProps): JSX.Element;
