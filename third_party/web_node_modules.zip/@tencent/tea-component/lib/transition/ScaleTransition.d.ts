/// <reference types="react" />
import { TransitionProps } from "react-transition-group/Transition";
export interface ScaleTransitionProps extends Partial<TransitionProps> {
    /**
     * 从哪个缩放系数进场，默认为 0.5
     */
    from?: number;
    /**
     * 从哪个缩放系数离场，默认与 from 一致
     */
    to?: number;
    /**
     * 缩放原点
     */
    origin?: string;
}
export declare function ScaleTransition({ from, to, timeout, origin, ...rest }: ScaleTransitionProps): JSX.Element;
