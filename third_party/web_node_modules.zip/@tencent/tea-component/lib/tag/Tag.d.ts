import React from "react";
import { StyledProps } from "../_type";
export interface TagProps extends StyledProps {
    /**
     * 标签内容
     */
    children: React.ReactNode;
    /**
     * 关闭时回调
     *
     * **传递该参数时将展示关闭按钮**
     */
    onClose?: (event: React.MouseEvent) => void;
    /**
     * 颜色主题
     *
     * @default "default"
     */
    theme?: "default" | "primary" | "success" | "warning" | "error";
    /**
     * 是否为深色背景
     *
     * @default false
     */
    dark?: boolean;
}
export declare function Tag({ children, onClose, className, theme, dark, style, }: TagProps): JSX.Element;
