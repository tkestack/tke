import React from "react";
import { StyledProps } from "../_type";
export interface JustifyProps extends StyledProps {
    /**
     * 是否顶部对齐
     * @default false
     */
    top?: boolean;
    /**
     * 是否底部对齐
     * @default false
     */
    bottom?: boolean;
    /**
     * 左侧内容
     */
    left?: React.ReactNode;
    /**
     * 右侧内容
     */
    right?: React.ReactNode;
}
export declare function Justify({ left, right, top, bottom, className, style, }: JustifyProps): JSX.Element;
