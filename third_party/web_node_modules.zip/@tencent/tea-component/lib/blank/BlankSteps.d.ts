import React from "react";
import { StyledProps } from "../_type";
export interface BlankStepsProps extends StyledProps {
    /**
     * 步骤内容
     */
    steps: React.ReactNode[];
}
export declare function BlankSteps({ steps, className, style }: BlankStepsProps): JSX.Element;
