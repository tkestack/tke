import React from "react";
import { StyledProps } from "../_type";
export interface DrawerProps extends StyledProps {
    /**
     * Drawer 是否可见
     */
    visible: boolean;
    /**
     * 点击关闭图标或抽屉外区域的回调
     */
    onClose: () => void;
    /**
     * 抽屉方向
     * @default "right"
     */
    placement?: "right" | "left";
    /**
     * 抽屉大小
     *
     * - `"m"` - 360px
     * - `"l"` - 800px
     *
     * @default "m"
     */
    size?: "m" | "l";
    /**
     * Drawer 中的内容
     */
    children?: React.ReactNode;
    /**
     * Drawer 底部内容
     */
    footer?: React.ReactNode;
    /**
     * 头部标题
     */
    title?: React.ReactNode;
    /**
     * 头部副标题/说明文字
     */
    subtitle?: React.ReactNode;
    /**
     * **\[Deprecated\]** 请使用 `subtitle` 属性
     *
     * @deprecated
     */
    subTitle?: React.ReactNode;
    /**
     * 头部右侧渲染内容
     */
    extra?: React.ReactNode;
    /**
     * 点击面板外是否收起面板
     * @default true
     */
    outerClickClosable?: boolean;
    /**
     * 是否禁用头部关闭图标
     * @default false
     */
    disableCloseIcon?: boolean;
    /**
     * 是否禁用展开/收起动效
     * @default false
     */
    disableAnimation?: boolean;
}
export declare function Drawer({ className, style, children, visible, onClose, size, placement, footer, title, subTitle, subtitle, extra, disableCloseIcon, disableAnimation, outerClickClosable, }: DrawerProps): React.ReactPortal;
