/// <reference types="react" />
import { StyledProps } from "../_type";
export declare type AffixTargetType = Element | Window;
export interface AffixProps extends StyledProps {
    /**
     * 距离顶部偏移量
     */
    offsetTop?: number;
    /**
     * 距离底部偏移量
     */
    offsetBottom?: number;
    /**
     * 监听滚动事件的元素
     *
     * @default window
     */
    target?: AffixTargetType | (() => Element);
    /**
     * 需要被钉住的内容
     */
    children: React.ReactNode;
}
