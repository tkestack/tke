/// <reference types="react" />
import { Combine, StyledProps } from "../_type";
import { ControlledProps } from "../form/controlled";
import { CommonDropdownProps } from "../dropdown/Dropdown";
export interface CascaderProps extends Combine<CommonDropdownProps, StyledProps, ControlledProps<string[], React.SyntheticEvent, {
    options: CascaderOption[];
    event: React.MouseEvent;
}>> {
    /**
     * 选择数据
     */
    data: CascaderData;
    /**
     * 动态加载数据，**需要返回 Promise**
     *
     * 在 `data` 中某级 `options` 为空时调用
     */
    onLoad?: (value: string[], options: CascaderOption[]) => Promise<void>;
    /**
     * 是否每级选项变化都触发改变
     * @default false
     */
    changeOnSelect?: boolean;
    /**
     * 占位符
     * @default "请选择"（已处理国际化）
     */
    placeholder?: string;
    /**
     * 是否禁用选择
     * @default false
     */
    disabled?: boolean;
}
export interface CascaderOption {
    /**
     * 选项值
     */
    value: string;
    /**
     * 选项标题
     */
    label: React.ReactNode;
    /**
     * 子级数据
     */
    child?: CascaderData;
}
export interface CascaderData {
    /**
     * 当前选择面板标题
     */
    title: React.ReactNode;
    /**
     * 面板布局列数，支持 `1`, `2`, `4`
     * @default 4
     */
    col?: number;
    /**
     * 选项
     *
     * 当该项为空时将触发 `onLoad` 加载数据
     */
    options?: CascaderOption[];
}
export interface CascaderBoxProps extends StyledProps {
    /**
     * 选择数据
     */
    data: CascaderProps["data"];
    /**
     * 当前选择值
     */
    value: CascaderProps["value"];
    /**
     * 当前选择值
     */
    onChange: CascaderProps["onChange"];
    /**
     * 选择完毕收起下拉框
     */
    onClose: () => void;
    /**
     * 动态加载数据
     */
    onLoad: CascaderProps["onLoad"];
    /**
     * 是否每级选项变化都触发改变
     * @default false
     */
    changeOnSelect?: CascaderProps["changeOnSelect"];
}
export interface CascaderLoadingProps {
    /**
     * 动态加载数据
     */
    onLoad: () => Promise<void>;
}
