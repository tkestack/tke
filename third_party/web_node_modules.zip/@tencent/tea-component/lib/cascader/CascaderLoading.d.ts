/// <reference types="react" />
import { CascaderLoadingProps } from "./CascaderProps";
export declare function CascaderLoading({ onLoad }: CascaderLoadingProps): JSX.Element;
