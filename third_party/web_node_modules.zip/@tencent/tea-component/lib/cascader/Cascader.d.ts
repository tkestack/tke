/// <reference types="react" />
import { CascaderProps } from "./CascaderProps";
export declare function Cascader(props: CascaderProps): JSX.Element;
