import React from "react";
interface DomRefProps {
    children?: React.ReactNode;
}
export declare const DomRef: React.ForwardRefExoticComponent<DomRefProps & React.RefAttributes<HTMLElement>>;
export {};
