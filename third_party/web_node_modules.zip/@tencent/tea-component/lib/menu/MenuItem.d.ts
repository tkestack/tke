import React from "react";
import { StyledProps } from "../_type";
export interface MenuItemProps extends StyledProps {
    /**
     * 标题
     */
    title?: React.ReactNode;
    /**
     * 菜单折叠后标题处显示的图标 URL
     *
     * **传递一组 URL 时，第一个 URL 会作为未激活态图标，第二个 URL 会作为激活态图标**
     */
    icon?: [string, string] | string;
    /**
     * 是否为选中状态
     *
     * @default false
     */
    selected?: boolean;
    /**
     * 点击回调
     */
    onClick?: (event: React.MouseEvent) => void;
    /**
     * 自定义渲染
     *
     * @default children => <a>{children}</a>
     */
    render?: (children: JSX.Element) => JSX.Element;
}
export declare function MenuItem({ title, icon, selected, className, style, onClick, render, }: MenuItemProps): JSX.Element;
