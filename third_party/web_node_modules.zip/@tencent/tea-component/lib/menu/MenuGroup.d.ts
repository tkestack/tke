import React from "react";
import { StyledProps } from "../_type";
export interface MenuGroupProps extends StyledProps {
    /**
     * 标题
     */
    title?: React.ReactNode;
    /**
     * 菜单内容（Menu.SubMenu 或 Menu.Item）
     */
    children?: React.ReactNode;
}
export declare function MenuGroup({ title, children, className, style, }: MenuGroupProps): JSX.Element;
