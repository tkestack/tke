import React from "react";
import { StyledProps } from "../_type";
export interface SubMenuProps extends StyledProps {
    /**
     * 标题
     */
    title?: React.ReactNode;
    /**
     * 菜单折叠后标题处显示的图标 URL
     *
     * **传递一组 URL 时，第一个 URL 会作为未激活态图标，第二个 URL 会作为激活态图标**
     */
    icon?: string | [string, string];
    /**
     * 菜单内容（Menu.Item）
     */
    children?: React.ReactNode;
    /**
     * 是否默认展开
     *
     * @default false
     */
    defaultOpened?: boolean;
    /**
     * 是否展示
     */
    opened?: boolean;
    /**
     * 展开状态变化时回调
     */
    onOpenedChange?: (opened: boolean) => void;
}
export declare function SubMenu({ title, icon, children, defaultOpened, opened, onOpenedChange, className, style, }: SubMenuProps): JSX.Element;
