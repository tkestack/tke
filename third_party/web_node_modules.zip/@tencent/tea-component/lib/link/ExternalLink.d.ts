import React, { AnchorHTMLAttributes } from "react";
export interface ExternalLinkProps extends AnchorHTMLAttributes<HTMLAnchorElement> {
    /**
     * 不显示为高亮色
     * @default false
     */
    weak?: boolean;
}
export declare const ExternalLink: React.ForwardRefExoticComponent<ExternalLinkProps & React.RefAttributes<HTMLAnchorElement>>;
