import React from "react";
import { StyledProps } from "../_type";
export interface InputAdornmentProps extends StyledProps {
    /**
     * 前缀装饰
     */
    before?: React.ReactNode;
    /**
     * 后缀装饰
     */
    after?: React.ReactNode;
    /**
     * 被装饰内容
     */
    children?: React.ReactNode;
    /**
     * 展示类型
     * @default “default”
     */
    appearence?: "default" | "pure";
}
export declare function InputAdornment({ before, after, children, appearence, className, style, }: InputAdornmentProps): JSX.Element;
export declare namespace InputAdornment {
    var defaultLabelAlign: string;
}
/**
 * @deprecated
 *
 * 请使用 InputAdornment 代替
 */
export declare const InputAdorment: typeof InputAdornment;
