/// <reference types="react" />
interface FormContextValue {
    hideLabel?: boolean;
}
export declare const FormContext: import("react").Context<FormContextValue>;
export {};
