import React from "react";
import { StyledProps } from "../_type";
export interface FormControlProps extends StyledProps {
    /**
     * 表单组件
     */
    children?: React.ReactNode;
    /**
     * 字段状态
     */
    status?: "success" | "error" | "validating";
    /**
     * 是否展示 icon
     * @default true
     */
    showStatusIcon?: boolean;
    /**
     * 表单说明消息/错误消息
     */
    message?: React.ReactNode;
    /**
     * 是否增加顶部间距，以对齐标签文本
     * @default false
     */
    alignLabelTop?: boolean;
    /**
     * 是否为必填字段
     * @default false
     */
    required?: boolean;
}
export declare function FormControl({ status, children, message, className, style, alignLabelTop, showStatusIcon, }: FormControlProps): JSX.Element;
