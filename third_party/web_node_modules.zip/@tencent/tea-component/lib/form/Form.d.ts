import React from "react";
import { StyledProps } from "../_type";
import { FormItem } from "./FormItem";
import { FormControl } from "./FormControl";
export interface FormProps extends StyledProps {
    /**
     * 表单布局方式
     *
     * - `default` 默认布局
     * - `fixed` 固定标签栏宽度，可用于对齐多个表单
     * - `vertical` 标签和控件垂直排列
     * - `inline` 表单内容行内流水排列
     * - `inline-vertical` 表单内容行内流水排列，且标签和控件垂直排列
     * @default "default"
     */
    layout?: "default" | "fixed" | "vertical" | "inline" | "inline-vertical";
    /**
     * 是否为纯展示表单（样式更加紧凑）
     *
     * @default false
     */
    readonly?: boolean;
    /**
     * 不展示表单 Label 部分
     *
     * @default false
     */
    hideLabel?: boolean;
    /**
     * 表单内容
     */
    children?: React.ReactNode;
}
export declare function Form({ style, className, children, layout, readonly, hideLabel, }: FormProps): JSX.Element;
export declare namespace Form {
    var Item: typeof FormItem;
    var Title: React.ForwardRefExoticComponent<import("../_util/create-rocket").RocketProps & React.RefAttributes<HTMLElement>>;
    var Action: React.ForwardRefExoticComponent<import("../_util/create-rocket").RocketProps & React.RefAttributes<HTMLElement>>;
    var Control: typeof FormControl;
    var Text: React.ForwardRefExoticComponent<import("../_util/create-rocket").RocketProps & React.RefAttributes<HTMLElement>>;
}
export declare const FormTitle: React.ForwardRefExoticComponent<import("../_util/create-rocket").RocketProps & React.RefAttributes<HTMLElement>>;
export declare const FormAction: React.ForwardRefExoticComponent<import("../_util/create-rocket").RocketProps & React.RefAttributes<HTMLElement>>;
export declare const FormText: React.ForwardRefExoticComponent<import("../_util/create-rocket").RocketProps & React.RefAttributes<HTMLElement>>;
