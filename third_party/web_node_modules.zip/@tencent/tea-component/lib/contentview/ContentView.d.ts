import React from "react";
import { InferProps, StyledProps } from "../_type";
/**
 * @deprecated
 *
 * 请使用 Layout 组件代替
 */
export declare const ContentView: React.ForwardRefExoticComponent<import("../_util/create-rocket").RocketProps & React.RefAttributes<HTMLElement>> & {
    Header: typeof ContentViewHeader;
    Body: typeof ContentViewBody;
};
export interface ContentViewProps extends InferProps<typeof ContentView> {
}
export interface ContentViewHeaderProps extends StyledProps {
    /**
     * 是否展示返回按钮
     *
     * @default false
     */
    showBackButton?: boolean;
    /**
     * 返回按钮点击回调
     */
    onBackButtonClick?: (event: React.MouseEvent) => void;
    /**
     * 标题
     */
    title?: React.ReactNode;
    /**
     * 小标题（说明文字）
     */
    subtitle?: React.ReactNode;
    /**
     * 操作区内容
     */
    operation?: React.ReactNode;
    /**
     * 自定义渲染头部内容
     *
     * **此时不会渲染返回按钮、标题、操作区等内容**
     */
    children?: React.ReactNode;
}
export declare function ContentViewHeader({ showBackButton, onBackButtonClick, title, subtitle, operation, children, className, style, }: ContentViewHeaderProps): JSX.Element;
export interface ContentViewBodyProps extends StyledProps {
    /**
     * 是否为全屏
     * @default false
     */
    full?: boolean;
    /**
     * 侧边导航
     */
    sidebar?: React.ReactNode;
    /**
     * 内容
     */
    children?: React.ReactNode;
}
declare function ContentViewBody({ full, sidebar, children, className, style, }: ContentViewBodyProps): JSX.Element;
export {};
