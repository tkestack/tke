import React from "react";
import { StyledProps, Combine } from "../_type";
import { PopoverProps } from "../popover";
import { SizeType } from "../input";
/**
 * 下拉类组件通用 Props
 */
export interface CommonDropdownProps {
    /**
     * 是否默认展开
     */
    defaultOpen?: boolean;
    /**
     * 是否展开（受控）
     */
    open?: boolean;
    /**
     * 展开变化回调（受控）
     */
    onOpenChange?: (open: boolean) => void;
    /**
     * 下拉出现的位置
     * @default "bottom-start"（从底部弹出，左侧对齐）
     */
    placement?: PopoverProps["placement"];
    /**
     * 弹出位置偏离参考位置的位移
     * @default 5
     */
    placementOffset?: PopoverProps["placementOffset"];
    /**
     * 是否在父容器滚动时关闭
     * @default true
     */
    closeOnScroll?: PopoverProps["closeOnScroll"];
}
export interface DropdownProps extends Combine<CommonDropdownProps, StyledProps> {
    /**
     * 下拉按钮文本
     */
    button: React.ReactNode;
    /**
     * 下拉内容
     * @docType React.ReactNode | ((close: () => void) => React.ReactNode)
     */
    children: React.ReactNode | ((close: () => void) => React.ReactNode);
    /**
     * 下拉按钮的外观：
     *
     * - `default` 无边框，适用于页面标题和表格内
     * - `button` 为按钮风格，有边框，多用于操作栏中
     * - `link` 为超链接风格
     * - `filter` 为过滤组件风格，多用于表头筛选
     * - `pure` 无额外样式
     *
     * 原有 `raw` 类型建议使用 `pure` 进行改造
     *
     * @default "default"
     */
    appearence?: "default" | "button" | "link" | "filter" | "pure";
    /**
     * 下拉框尺寸，使用 `"full"` 撑满容器宽度
     */
    size?: SizeType | "auto";
    /**
     * 触发方式
     *
     * @default "click"
     */
    trigger?: "click" | "hover";
    /**
     * 是否在下拉内容点击时关闭
     * @default true
     */
    clickClose?: boolean;
    /**
     * 是否禁用
     * @default false
     */
    disabled?: boolean;
    /**
     * 打开时回调
     */
    onOpen?: () => void;
    /**
     * 关闭时回调
     */
    onClose?: () => void;
    /**
     * 弹出区域自定义类名
     */
    boxClassName?: string;
    /**
     * 弹出区域自定义样式
     */
    boxStyle?: React.CSSProperties;
    /**
     * 是否在 `children` 变化时更新位置
     *
     * @default false
     */
    updateOnChildrenChange?: boolean;
}
export declare function DropdownBox({ className, style, children, onClick, onUpdate, }: {
    onClick?: (event: React.MouseEvent) => void;
    children?: React.ReactNode;
    onUpdate?: () => void;
} & StyledProps): JSX.Element;
export declare const Dropdown: React.FunctionComponent<DropdownProps & React.RefAttributes<HTMLDivElement>> & {
    Footer: React.ForwardRefExoticComponent<import("../_util/create-rocket").RocketProps & React.RefAttributes<HTMLElement>>;
};
