import React from "react";
import { StyledProps } from "../_type";
export interface TabPanelProps extends StyledProps {
    /**
     * 选项卡 ID
     */
    id: string;
    /**
     * 选项卡内容
     */
    children?: React.ReactNode;
    /**
     * 未激活时是否强制渲染
     * @default false
     */
    forceRender?: boolean;
}
/**
 * TabPanel 应该用在 Tabs 内部，如果单独使用，会直接渲染其 children
 */
export declare function TabPanel({ children, className, style }: TabPanelProps): JSX.Element;
