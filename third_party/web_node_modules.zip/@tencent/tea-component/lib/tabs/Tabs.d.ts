/// <reference types="react" />
import { TabsProps } from "./TabProps";
export declare function Tabs({ tabs, destroyInactiveTabPanel, activeId, onActive, defaultActiveId, children, animated, placement, ceiling, addon, maxHeight, className, style, tabBarRender, }: TabsProps): JSX.Element;
