import React from "react";
export interface TabItemProps {
    label: React.ReactNode;
    actived: boolean;
    disabled: boolean;
    onClose: (evt: React.MouseEvent) => void;
    onClick: (evt: React.MouseEvent) => void;
    render: (children: JSX.Element) => JSX.Element;
}
export declare const TabItem: React.ForwardRefExoticComponent<TabItemProps & React.RefAttributes<HTMLLIElement>>;
