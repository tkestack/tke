/// <reference types="react" />
import { SelectOptionWithGroup } from "../select";
export interface SegmentOption extends SelectOptionWithGroup {
    /**
     * 弹出气泡内容
     */
    bubble?: React.ReactNode;
}
