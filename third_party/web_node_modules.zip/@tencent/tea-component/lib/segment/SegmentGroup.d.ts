import React from "react";
export declare const SegmentGroup: React.ForwardRefExoticComponent<import("../_util/create-rocket").RocketProps & React.RefAttributes<HTMLElement>>;
export declare function SegmentGroupItem({ name, children, }: {
    name: React.ReactNode;
    children: React.ReactNode;
}): JSX.Element;
