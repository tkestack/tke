import React from "react";
import { CollapsePanel } from "./CollapsePanel";
import { StyledProps } from "../_type";
export interface CollapseProps extends StyledProps {
    /**
     * 当前激活的面板 ID 组
     */
    activeIds?: string[];
    /**
     * 默认激活的面板 ID 组
     */
    defaultActiveIds?: string[];
    /**
     * 面板激活变化回调
     */
    onActive?: (activeIds: string[], context: {
        event: React.SyntheticEvent;
    }) => void;
    /**
     * 面板 <Collapse.Panel />
     */
    children?: React.ReactNode;
}
export declare function Collapse({ activeIds, defaultActiveIds, onActive, children, className, style, }: CollapseProps): JSX.Element;
export declare namespace Collapse {
    var Panel: typeof CollapsePanel;
}
