/// <reference types="react" />
export interface CollapseContextValue {
    /**
     * 当前激活的面板 ID
     */
    activeIds: string[];
    /**
     * 面板激活变化回调
     */
    onActive: (activeIds: string[], context: {
        event: React.SyntheticEvent;
    }) => void;
}
export declare const CollapseContext: import("react").Context<CollapseContextValue>;
