import React from "react";
import { StyledProps } from "../_type";
export interface TransferProps extends StyledProps {
    /**
     * 头部内容
     */
    header?: React.ReactNode;
    /**
     * 左侧 TransferCell
     * @docType React.ReactElement
     */
    leftCell: React.ReactElement;
    /**
     * 右侧 TransferCell
     * @docType React.ReactElement
     */
    rightCell: React.ReactElement;
}
export declare function Transfer({ header, leftCell, rightCell, className, style, }: TransferProps): JSX.Element;
export declare namespace Transfer {
    var Cell: typeof TransferCell;
}
interface TransferCellProps extends StyledProps {
    /**
     * Cell 标题
     */
    title?: React.ReactNode;
    /**
     * Cell 内容区头部内容
     */
    header?: React.ReactNode;
    /**
     * Cell 底部提示
     */
    tip?: React.ReactNode;
    /**
     * Cell 内容
     */
    children: React.ReactNode;
    /**
     * Cell 内容区是否垂直可滚动
     *
     * 需要实现内容内部滚动时（如 Table），可禁用此选项
     *
     * @default true
     */
    scrollable?: boolean;
}
declare function TransferCell({ title, tip, header, children, scrollable, className, style, }: TransferCellProps): JSX.Element;
export {};
