import React from "react";
import { StyledProps } from "../_type";
export interface MediaObjectProps extends StyledProps {
    /**
     * 媒体元素
     */
    media: React.ReactNode;
    /**
     * 内容块
     */
    children: React.ReactNode;
    /**
     * 媒体元素与内容块对齐方式
     * @default "top"
     */
    align?: "top" | "middle" | "bottom";
    /**
     * 媒体元素与内容块反置
     * @default false
     */
    reverse?: boolean;
}
export declare function MediaObject({ align, reverse, media, children, }: MediaObjectProps): JSX.Element;
