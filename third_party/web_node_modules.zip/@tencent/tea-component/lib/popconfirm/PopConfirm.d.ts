import React from "react";
import { BubbleProps } from "../bubble";
import { StyledProps } from "../_type";
export interface PopConfirmProps extends StyledProps {
    /**
     * 使用受控模式来控制弹出气泡的显示，配合 `onVisibleChange` 方法使用
     */
    visible?: BubbleProps["visible"];
    /**
     * 处理 `visible` 变化的情况
     */
    onVisibleChange?: BubbleProps["onVisibleChange"];
    /**
     * 提示标题
     */
    title?: React.ReactNode;
    /**
     * 提示信息
     */
    message?: React.ReactNode;
    /**
     * 底部渲染内容
     * @docType React.ReactNode | ((close: () => void) => React.ReactNode)
     */
    footer?: React.ReactNode | ((close: () => void) => React.ReactNode);
    /**
     * 气泡放置的位置，将影响三角的朝向和位置
     * @default "top"
     */
    placement?: BubbleProps["placement"];
    /**
     * 需要被气泡包裹的内容
     */
    children?: React.ReactNode;
    /**
     * 是否在父容器滚动时关闭
     * @default false
     */
    closeOnScroll?: BubbleProps["closeOnScroll"];
}
export declare function PopConfirm({ title, message, children, placement, footer, className, style, closeOnScroll, visible: _visible, onVisibleChange: _onVisibleChange, }: PopConfirmProps): JSX.Element;
