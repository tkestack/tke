import React from "react";
import { StyledProps } from "../_type";
import { DropdownProps } from "../dropdown";
export interface NavMenuItemProps extends StyledProps {
    /**
     * 菜单项类型
     *
     * - `default` 默认文字类型菜单项
     * - `logo` 导航 Logo
     * - `dropdown` 包含下拉的菜单项
     * - `icon` 图标类型菜单项
     *
     * @default "default"
     */
    type?: "default" | "logo" | "dropdown" | "icon";
    /**
     * 菜单项是否为选中样式
     *
     * @default false
     */
    selected?: boolean;
    /**
     * 菜单项点击回调
     */
    onClick?: (event: React.MouseEvent) => void;
    /**
     * 菜单项内容
     */
    children?: React.ReactNode;
    /**
     * `type="dropdown"` 时弹出层内容
     * @docType React.ReactNode | ((close: () => void) => React.ReactNode)
     */
    overlay?: DropdownProps["children"];
}
export declare function NavMenuItem({ type, selected, onClick, className, style, overlay, children, }: NavMenuItemProps): JSX.Element;
export interface NavMenuProps extends StyledProps {
    /**
     * 导航左侧 <NavMenu.Item />
     */
    left?: React.ReactNode;
    /**
     * 导航右侧 <NavMenu.Item />
     */
    right?: React.ReactNode;
}
export declare const NavMenu: (({ left, right, className, style }: NavMenuProps) => JSX.Element) & {
    Item: typeof NavMenuItem;
};
