import React from "react";
import { StyledProps } from "../_type";
export interface AlertProps extends StyledProps {
    /**
     * 提示类型
     * @default "info"
     */
    type?: "info" | "success" | "warning" | "error";
    /**
     * 提示内容
     */
    children?: React.ReactNode;
    /**
     * 控制 Alert 是否显示，如果没传，默认显示
     * 配合 `onClose` 回调可以实现关闭效果
     */
    visible?: boolean;
    /**
     * 默认是否显示。如果不想自己控制 Alert 的显示状态，可以传入 defaultVisible 为 true，此时会渲染关闭图标，并且用户点击关闭时隐藏。
     * @default true
     */
    defaultVisible?: boolean;
    /**
     * 传入 visibile 或者 defaultVisible 都会渲染关闭图标，用户点击关闭图标时回调 onClose
     */
    onClose?: () => void;
}
export declare function Alert(props: AlertProps): JSX.Element;
