export interface QueryState<TFilter> {
    date?: DateQuery;
    paging?: PagingQuery;
    search?: string;
    keyword?: string;
    filter?: TFilter;
    sort?: SortQuery;
}
export interface DateQuery {
    /**
     * 查询的起始日期
     */
    from?: string;
    /**
     * 查询的结束日期
     */
    to?: string;
    /**
     * 跨越的天数
     */
    length?: number;
    /**
     * 区间的时间粒度
     */
    stride?: number;
}
/** 表示一次分页请求 */
export interface PagingQuery {
    /** 请求的页码，从 1 开始索引 */
    pageIndex?: number;
    /** 请求的每页记录数 */
    pageSize?: number;
}
export interface SortQuery {
    by?: string;
    desc?: boolean;
}
