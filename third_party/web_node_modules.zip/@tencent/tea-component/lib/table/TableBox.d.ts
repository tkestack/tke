import React from "react";
import { TableColumn } from "./TableProps";
import { StyledProps } from "../_type";
export interface TableBoxProps extends StyledProps {
    columns: TableColumn[];
    children: React.ReactChild;
}
export declare function TableBox({ columns, children, style }: TableBoxProps): JSX.Element;
