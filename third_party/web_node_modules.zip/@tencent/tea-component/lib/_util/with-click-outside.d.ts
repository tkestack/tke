/// <reference types="react" />
export declare function withClickOutSide(methodName?: string): <P, T extends import("react").ComponentType<P>>(Component: T) => T;
