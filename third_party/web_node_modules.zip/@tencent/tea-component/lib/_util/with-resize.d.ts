import React from "react";
export declare const withResize: (methodName: string) => <P, T extends React.ComponentClass<{}, any>>(Component: T) => T;
