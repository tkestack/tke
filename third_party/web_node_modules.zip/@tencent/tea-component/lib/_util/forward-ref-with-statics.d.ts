import { RefAttributes } from "react";
export declare function forwardRefWithStatics<P, T = any, S = {}>(component: React.RefForwardingComponent<T, P>, statics?: S): React.FunctionComponent<P & RefAttributes<T>> & S;
