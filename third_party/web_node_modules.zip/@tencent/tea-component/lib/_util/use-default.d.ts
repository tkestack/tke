export interface ChangeHandler<T, P extends any[]> {
    (value: T, ...args: P): any;
}
export declare function useDefault<T, P extends any[]>(value: T, defaultValue: T, onChange: ChangeHandler<T, P>): [T, ChangeHandler<T, P>];
