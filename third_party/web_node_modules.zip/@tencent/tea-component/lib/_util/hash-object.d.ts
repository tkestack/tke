export declare function hashObject(obj: any): number;
