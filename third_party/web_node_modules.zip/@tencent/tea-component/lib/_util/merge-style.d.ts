import React from "react";
export declare function mergeStyle(...styles: React.CSSProperties[]): React.CSSProperties;
