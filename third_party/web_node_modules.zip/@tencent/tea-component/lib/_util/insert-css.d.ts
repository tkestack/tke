/**
 * insert css to the current page
 * */
export declare function insertCSS(id: string, cssText: string): HTMLStyleElement;
