import { MutableRefObject } from "react";
export declare function useLast<T>(value: T): MutableRefObject<T>;
