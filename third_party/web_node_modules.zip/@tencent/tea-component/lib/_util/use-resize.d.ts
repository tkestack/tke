export declare function useResize(handler: (event: UIEvent) => void): void;
