/**
 * @fileOverview
 *
 * 有序维护选区
 */
export interface Identifiable {
    id: string | number;
}
/**
 * 插入到选区中，保持与 records 相同的偏序顺序
 */
export declare function selectionInsert<T extends Identifiable>(records: T[], selection: T[], item: T): T[];
/**
 * 从选取中删除
 */
export declare function selectionRemove<T extends Identifiable>(records: T[], selection: T[], item: T): T[];
