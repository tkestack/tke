/**
 * 获取/创建对话框容器
 */
export declare function getOverlayRoot(): HTMLElement;
