export declare function useScheduleUpdate(deps?: any[]): (fn: any) => void;
