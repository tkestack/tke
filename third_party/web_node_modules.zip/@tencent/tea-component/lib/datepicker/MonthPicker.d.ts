/// <reference types="react" />
import { Moment } from "moment";
import { ControlledProps } from "../form/controlled";
import { Combine } from "../_type";
import { CommonDatePickerProps } from "./DatePickerProps";
export interface MonthPickerProps extends Combine<CommonDatePickerProps, ControlledProps<Moment>> {
}
export declare const MonthPicker: ((props: MonthPickerProps) => JSX.Element) & {
    defaultLabelAlign: string;
};
