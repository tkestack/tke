/// <reference types="react" />
import { StyledProps, Combine } from "../_type";
import { RangeDateType } from "../calendar/DateProps";
import { CommonDropdownProps } from "../dropdown/Dropdown";
export interface CommonDatePickerProps extends Combine<CommonDropdownProps, StyledProps> {
    /**
     * 是否禁用
     * @default false
     */
    disabled?: boolean;
    /**
     * placeholder
     * @default "选择日期" 或 “选择时间”（包含时间选择时）
     */
    placeholder?: string;
    /**
     * 可选择日期范围
     */
    range?: RangeDateType;
    /**
     * 头部渲染内容
     */
    header?: React.ReactNode;
    /**
     * 日期展示格式
     * @default "YYYY-MM-DD" 或 "YYYY-MM-DD HH:mm:ss"（包含时间选择时）
     */
    format?: string;
}
