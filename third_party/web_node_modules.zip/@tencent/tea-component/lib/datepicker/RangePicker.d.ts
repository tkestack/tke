/// <reference types="react" />
import { Moment } from "moment";
import { ControlledProps } from "../form/controlled";
import { Combine } from "../_type";
import { CommonDatePickerProps } from "./DatePickerProps";
import { TimeDisabledProps } from "../timepicker/TimeProps";
import { RangeDateType, showTimeType } from "../calendar/DateProps";
export interface RangePickerProps extends Combine<CommonDatePickerProps, ControlledProps<RangeDateType>> {
    /**
     * 分隔符
     * @default ~
     */
    separator?: string;
    /**
     * 是否开启时间选择，可传递对象设定时间选择配置
     */
    showTime?: showTimeType<RangeDateType>;
    /**
     * 不可选的日期
     */
    disabledDate?: (date: Moment, startDate?: Moment) => boolean;
    /**
     * 不可选的时间
     */
    disabledTime?: (dates: RangeDateType, partial: "start" | "end") => TimeDisabledProps;
}
export declare function isValidRangeValue(value: any): boolean;
export declare const RangePicker: ((props: RangePickerProps) => JSX.Element) & {
    defaultLabelAlign: string;
};
