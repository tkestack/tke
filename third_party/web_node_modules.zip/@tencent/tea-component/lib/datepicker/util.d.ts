/// <reference types="react" />
import { Moment } from "moment";
import { TriggerProps } from "../popover/trigger";
export declare function getYearMonthDate(date: Moment): {
    year: number;
    month: number;
    date: number;
};
export declare const DatePickerTrigger: ({ childrenElementRef, overlayElementRef, visible, render, onOpen, onClose, }: TriggerProps & {
    onOpen: () => void;
    onClose: () => void;
}) => JSX.Element;
