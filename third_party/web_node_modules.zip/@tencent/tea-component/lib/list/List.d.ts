import React from "react";
import { StyledProps } from "../_type";
export interface ListItemProps extends StyledProps {
    /**
     * 是否处于激活态
     */
    current?: boolean;
    /**
     * 是否处于选中态
     */
    selected?: boolean;
    /**
     * 是否处于禁用态
     */
    disabled?: boolean;
    /**
     * 点击时回调
     */
    onClick?: (evt: React.MouseEvent) => void;
    /**
     * Tooltip 说明文本
     */
    tooltip?: React.ReactNode;
    /**
     * 菜单项
     */
    children?: React.ReactNode;
}
export declare const ListItem: React.ForwardRefExoticComponent<ListItemProps & React.RefAttributes<HTMLLIElement>>;
export interface SubMenuProps extends StyledProps {
    /**
     * 子菜单名
     */
    label?: React.ReactNode;
    /**
     * 菜单项
     */
    children?: React.ReactNode;
    /**
     * 弹出方向
     * @default "right"
     */
    placement?: "right" | "left";
}
export declare function SubMenu({ label, children, placement, className, style, }: SubMenuProps): JSX.Element;
export interface ListProps extends StyledProps {
    /**
     * 列表内容。使用 `<List.Item>` 来表示列表项
     */
    children?: React.ReactNode;
    /**
     * 列表类型
     *
     * - 可以不传，表示简单平铺的列表
     * - `bullet` 列表项以点号开头
     * - `number` 列表项以列表序号开头
     * - `option` 列表以菜单的形式渲染
     * - `option-group` 列表以分组菜单的形式渲染
     */
    type?: "bullet" | "number" | "option" | "option-group";
    /**
     * 列表项之间的分割方式
     *
     * - `divide` 表示使用分割线分割
     * - `stripe` 表示使用条纹背景色分割
     */
    split?: "divide" | "stripe";
    /**
     * 列表项滚动至底部的回调
     */
    onScrollBottom?: (event: React.UIEvent) => void;
}
export declare const List: React.FunctionComponent<ListProps & React.RefAttributes<HTMLOListElement | HTMLUListElement>> & {
    GroupLabel: React.ForwardRefExoticComponent<import("../_util/create-rocket").RocketProps & React.RefAttributes<HTMLElement>>;
    StatusTip: React.ForwardRefExoticComponent<import("../_util/create-rocket").RocketProps & React.RefAttributes<HTMLElement>>;
    SubMenu: typeof SubMenu;
    Item: React.ForwardRefExoticComponent<ListItemProps & React.RefAttributes<HTMLLIElement>>;
};
