import React from "react";
import { BubbleContentProps } from "../bubble";
/**
 * 使用 Tooltip 的内容需要使用容器包裹。
 *
 * 默认会使用 span 包裹内容，如有需要，可以改为使用 div 包裹。
 */
export interface TooltipProps {
    /**
     * Tooltip 放置位置
     * @default "bottom-start"
     */
    placement?: BubbleContentProps["placement"];
    /**
     * 文本提示内容
     */
    title?: React.ReactNode;
    /**
     * 要提示的对象
     */
    children?: React.ReactNode;
    /**
     * 出现延迟时间（ms）
     * @default 600
     */
    openDelay?: number;
    /**
     * 距上次 Tooltip 出现 1s 内再次出现延迟时间（ms）
     * @default 300
     */
    openDelayWhenHasInstance?: number;
}
export declare function Tooltip({ title, placement, children, openDelay, openDelayWhenHasInstance, }: TooltipProps): JSX.Element;
