import React from "react";
export interface AttributeValue {
    /**
     * 为资源属性需求值的类型
     */
    type: string | [string, {
        [key: string]: any;
    }];
    /**
     * 属性的唯一标识，会在结果中返回
     */
    key: string;
    /**
     * 资源属性值名称
     */
    name: string;
    /**
     * 属性是否可重复选择
     */
    values?: any[] | Function;
    /**
     * 该属性是否可重复选择
     * @default false
     */
    reusable?: boolean;
    /**
     * 该属性是否可移除
     * @default true
     */
    removeable?: boolean;
}
export interface AttributeSelectProps {
    attributes: AttributeValue[];
    inputValue: string;
    onSelect?: (attribute: AttributeValue) => void;
    maxHeight: number;
}
export interface AttributeSelectState {
    select: number;
}
export declare class AttributeSelect extends React.Component<AttributeSelectProps, AttributeSelectState> {
    static contextType: React.Context<import("./TagSearchBoxContext").TagSearchBoxContextValue>;
    state: AttributeSelectState;
    componentWillReceiveProps(nextProps: AttributeSelectProps): void;
    handleKeyDown: (keyCode: number) => boolean;
    getUseableList(): Array<AttributeValue>;
    getAttribute(select: number): AttributeValue;
    move: (step: number) => void;
    handleClick: (e: React.MouseEvent<Element, MouseEvent>, index: number) => void;
    render(): JSX.Element;
}
