import React from "react";
import { TagValue } from "./Tag";
import { AttributeValue } from "./AttributeSelect";
import { TranslationProps } from "../i18n";
import { StyledProps } from "../_type";
export interface TagSearchBoxProps extends StyledProps {
    /**
     * 要选择过滤的资源属性的集合
     */
    attributes?: AttributeValue[];
    /**
     * 搜索框中默认包含的标签值的集合
     */
    defaultValue?: any[];
    /**
     * 配合 onChange 作为受控组件使用
     */
    value?: any[];
    /**
     * 搜索框收起后宽度
     * @default 210
     */
    minWidth?: string | number;
    /**
     * 当搜索框中新增、修改或减少标签时调用此函数
     */
    onChange?: (tags: any[]) => void;
    /**
     * 搜索框中提示语
     *
     * @default "多个关键字用竖线 “|” 分隔，多个过滤标签用回车键分隔" （已处理国际化）
     */
    tips?: string;
    /**
     * 资源属性选择下拉框提示
     *
     * @default "选择资源属性进行过滤" （已处理国际化）
     */
    attributesSelectTips?: string;
    /**
     * 隐藏帮助信息
     *
     * @default false
     */
    hideHelp?: boolean;
}
export interface TagSearchBoxState {
    /**
     * 搜索框是否为展开状态
     */
    active: boolean;
    /**
     * 是否展示提示框
     */
    dialogActive: boolean;
    /**
     * 当前光标位置
     */
    curPos: number;
    /**
     * 当前光标（焦点）所在位置的元素类型
     */
    curPosType: FocusPosType;
    /**
     * 是否展示值选择组件
     */
    showSelect: boolean;
    /**
     * 已选标签
     */
    tags: TagValue[];
}
/**
 * 焦点所在位置类型
 */
export declare enum FocusPosType {
    INPUT = 0,
    INPUT_EDIT = 1,
    TAG = 2
}
export declare class TagSearchBox extends React.Component<TagSearchBoxProps & TranslationProps> {
    state: TagSearchBoxState;
    componentDidMount(): void;
    componentWillReceiveProps(nextProps: TagSearchBoxProps): void;
    resetTagsState: (props: TagSearchBoxProps, callback?: Function) => void;
    open: () => void;
    close: () => void;
    notify: (tags: TagValue[]) => void;
    setTags(tags: Array<TagValue>, callback?: Function, notify?: boolean): void;
    /**
     * 点击清除按钮触发事件
     */
    handleClean: (e: any) => void;
    /**
     * 点击帮助触发事件
     */
    handleHelp: (e: any) => void;
    /**
     * 点击搜索触发事件
     */
    handleSearch: (e: any) => void;
    /**
     *  处理Tag相关事件
     */
    handleTagEvent: (type: string, index: number, payload?: any) => void;
    render(): JSX.Element;
}
