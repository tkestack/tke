import React from "react";
export interface TagSearchBoxContextValue {
    attributesSelectTips?: string;
}
export declare const TagSearchBoxContext: React.Context<TagSearchBoxContextValue>;
