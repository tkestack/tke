import { ReferenceObject } from "popper.js";
import { RefObject, HTMLProps, ComponentType } from "react";
export declare type Trigger = ComponentType<TriggerProps>;
export declare type TriggerWithProps<P = any> = [ComponentType<P & TriggerProps>, P];
export interface TriggerProps {
    overlayElementRef: RefObject<HTMLElement>;
    childrenElementRef: RefObject<HTMLElement>;
    visible: boolean;
    setVisible: (visible: boolean, delay?: number) => Promise<boolean>;
    openDelay: number;
    closeDelay: number;
    render: (renderProps: TriggerRenderProps) => JSX.Element;
}
export interface TriggerRenderProps {
    overlayProps: HTMLProps<HTMLElement>;
    childrenProps: HTMLProps<HTMLElement>;
    referenceElement?: ReferenceObject;
}
export declare const buildinTriggers: {
    click: ComponentType<TriggerProps>;
    hover: ComponentType<TriggerProps>;
    focus: ComponentType<TriggerProps>;
    empty: ComponentType<TriggerProps>;
};
/**
 * 点击的时候打开
 *
 * - children 上绑定 onClick 事件，点击时打开
 * - children 上添加 useClickOutside Hook，外部点击时关闭，并排除 overlayElement
 */
export declare function ClickTrigger({ childrenElementRef, overlayElementRef, visible, setVisible, openDelay, closeDelay, render, }: TriggerProps): JSX.Element;
/**
 * 鼠标经过的时候打开
 */
export declare function HoverTrigger({ setVisible, openDelay, closeDelay, render, }: TriggerProps): JSX.Element;
export declare function FocusTrigger({ setVisible, openDelay, closeDelay, render, }: TriggerProps): JSX.Element;
/**
 * 表示空的触发交互
 */
export declare function EmptyTrigger(props: TriggerProps): JSX.Element;
