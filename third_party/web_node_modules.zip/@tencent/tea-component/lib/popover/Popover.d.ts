import React from "react";
import { RefHandler } from "react-popper";
import { OverlayLayerProps } from "../overlay";
import { buildinTriggers, Trigger, TriggerWithProps } from "./trigger";
export interface PopoverProps {
    /**
     * 触发弹出层的内容，会直接渲染出来
     *
     * 内容触发弹出层的方式，由 `trigger` 属性指定
     *
     * 如果传入的不是 `ReactElement`（如文本、数字等），则渲染时会套一层 `span`
     */
    children?: React.ReactNode;
    /**
     * 弹出层内容
     * @docType React.ReactNode | ((props: OverlayContentProps) => JSX.Element)
     */
    overlay?: OverlayLayerProps["content"];
    /**
     * 触发弹出层显示的事件
     *
     * - `hover`：用户鼠标进入渲染内容时，显示浮层；离开渲染内容时，隐藏浮层。
     *   使用该交互请保证 `children` 可以接收 `onMouseEnter` 和 `onMouseLeave` 事件
     *
     * - `click`：用户在渲染内容上点击鼠标时，显示浮层；在渲染内容以及浮层外点击时，隐藏浮层。
     *   使用该交互请保证 `children` 可以接收 `onClick` 事件
     *
     * - 传入自定义组件以实现自定义弹出逻辑
     *
     * @default "hover"
     */
    trigger?: keyof typeof buildinTriggers | Trigger | TriggerWithProps;
    /**
     * 传入 `visible` 则表示使用受控模式来控制弹出层的显示，请处理 `onVisibleChange` 方法
     */
    visible?: boolean;
    /**
     * `visible` 变化时回调
     */
    onVisibleChange?: (visbile: boolean) => void;
    /**
     * 气泡默认是否打开
     * @default false
     */
    defaultVisible?: boolean;
    /**
     * 打开浮层前的延时
     */
    openDelay?: number;
    /**
     * 关闭浮层前的延时
     */
    closeDelay?: number;
    /**
     * 是否在容器滚动发生关闭
     * @default false
     */
    closeOnScroll?: boolean;
    /**
     * 气泡弹出的位置
     * @default "top"
     */
    placement?: OverlayLayerProps["placement"];
    /**
     * 弹出位置偏离参考位置的位移
     * @default 10
     */
    placementOffset?: OverlayLayerProps["placementOffset"];
    /**
     * 出现动画滑动距离
     */
    animationScaleFrom?: OverlayLayerProps["animationScaleFrom"];
    /**
     * 自定义定位参考信息
     * @see https://github.com/FezVrasta/react-popper#usage-without-a-reference-htmlelement
     */
    referenceElement?: OverlayLayerProps["referenceElement"];
    /**
     * 是否在 `resize` 和 `scroll` 发生时更新位置
     */
    updateOnDimensionChange?: OverlayLayerProps["updateOnDimensionChange"];
    /**
     * 自定义覆盖层样式
     */
    overlayStyle?: React.CSSProperties;
    /**
     * 动画事件
     */
    transitionTimeout?: OverlayLayerProps["transitionTimeout"];
}
export declare type PopoverRenderFunction = (props: PopupRenderProps) => JSX.Element;
export interface PopupRenderProps {
    ref: RefHandler;
    open: () => void;
    close: () => void;
}
export declare type PopupTrigger = "click" | "hover";
export declare function Popover(props: PopoverProps): JSX.Element;
