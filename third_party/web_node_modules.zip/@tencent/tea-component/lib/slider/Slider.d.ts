import React from "react";
import { ControlledProps } from "../form/controlled";
import { Combine, StyledProps } from "../_type";
export interface SliderMarkItem {
    /** 值 */
    value: number;
    /** 标记 */
    label?: string;
}
export interface SliderProps extends Combine<ControlledProps<number>, StyledProps> {
    /**
     * 最小值
     * @default 0
     */
    min: number;
    /**
     * 最大值
     */
    max: number;
    /**
     * 可选范围
     * @default [min, max]
     */
    range?: [number, number];
    /**
     * 刻度标记
     */
    marks?: SliderMarkItem[];
    /**
     * 步长，必须大于 0，且可被 (max - min) 除尽
     * @default 1
     */
    step?: number;
    /**
     * 是否只能拖拽到刻度上
     * @default false
     */
    markValueOnly?: boolean;
    /**
     * 是否禁用
     * @default false
     */
    disabled?: boolean;
    /**
     * 后置内容
     */
    after?: React.ReactNode;
    /**
     * Bubble 中提示为该函数为返回值，若为 null，则隐藏
     */
    tipFormatter?: (value: number) => number | string | null;
    /**
     * 滑动过程中 value 更新回调
     */
    onUpdate?: (value: number) => void;
    /**
     * 是否在滑轨上显示提示
     * @default false
     */
    enableTrackTip?: boolean;
}
export declare function Slider({ min, max, ...props }: SliderProps): JSX.Element;
