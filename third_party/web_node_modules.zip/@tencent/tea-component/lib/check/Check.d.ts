import React, { LabelHTMLAttributes } from "react";
import { Combine, WithoutMethod, Omit } from "../_type";
import { ControlledProps, ChangeContext } from "../form/controlled";
/**
 * `CheckInput` 组件所接收的参数
 */
export interface CheckProps extends Combine<Omit<LabelHTMLAttributes<HTMLLabelElement>, "onChange" | "defaultValue">, ControlledProps<boolean>> {
    /**
     * 获取内部 `input` 的引用
     */
    inputRef?: React.Ref<HTMLInputElement>;
    /**
     * `Checkbox` 的名称，对于 `CheckGroup` 等管理时必传
     */
    name?: string;
    /**
     * 选项类型
     */
    type: "radio" | "checkbox";
    /**
     * 是否已经勾选
     */
    value?: boolean;
    /**
     * 勾选状态发生变更时回调
     */
    onChange?: (value: boolean, context: CheckChangeContext) => void;
    /**
     * 是否半选状态（仅对 `checkbox` 生效）
     * @default false
     */
    indeterminate?: boolean;
    /**
     * 是否可用
     * @default false
     */
    disabled?: boolean;
    /**
     * 渲染方式，设置为 `block` 会独占一行
     * @default "inline"
     */
    display?: "inline" | "block";
    /** 文本解释内容，可用于解释选项的作用 */
    tooltip?: React.ReactNode;
    /** 点击时触发 */
    onClick?: (event: React.MouseEvent) => void;
}
/**
 * 为变更事件提供额外的内容
 */
export interface CheckChangeContext extends ChangeContext {
    /**
     * 发生变化的选项组件实例
     */
    check: ReadonlyCheckProps;
}
/**
 * 组件实例只读属性集合
 */
export interface ReadonlyCheckProps extends Readonly<WithoutMethod<CheckProps>> {
}
/**
 * Check 组件支持使用 CheckContext 进行状态托管
 */
export declare const CheckContext: React.Context<CheckContextValue>;
/**
 * 托管 Check 组件的状态，请提供 inject() 方法注入托管好的 props
 */
export interface CheckContextValue {
    inject: (props: CheckProps) => CheckProps;
}
export declare const Check: React.ForwardRefExoticComponent<CheckProps & React.RefAttributes<HTMLLabelElement>>;
