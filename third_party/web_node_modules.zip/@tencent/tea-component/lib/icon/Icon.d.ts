import React, { HTMLAttributes } from "react";
export interface IconProps extends HTMLAttributes<HTMLElement> {
    /** 图标类型 */
    type: string;
    /**
     * 默认为 16x16 图标
     *
     * 状态图标支持配置为 32x32，包括：`success`、`infowaiting`、`infoblue` 和 `error`
     *
     * @default "default"
     */
    size?: "default" | "l";
    /**
     * 是否渲染为超链接
     * @default false
     */
    link?: boolean;
    /**
     * 在图标上添加 Tooltip 的快捷方式，详见 [Tooltip](/component/tooltip) 组件
     */
    tooltip?: React.ReactNode;
}
export declare const Icon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<HTMLElement>>;
