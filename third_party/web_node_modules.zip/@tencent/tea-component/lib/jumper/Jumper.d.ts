/// <reference types="react" />
import { StyledProps } from "../_type";
export interface JumperProps extends StyledProps {
    /**
     * 是否使用无边框样式
     * @default false
     */
    noBordered?: boolean;
    /**
     * 按钮方向
     * @default "leftright"
     */
    direction?: "updown" | "leftright";
    /**
     * 是否展示当前按钮
     * @default false
     */
    showCurrent?: boolean;
    /**
     * 是否处于当前状态
     * @default false
     */
    isCurrent?: boolean;
    /** 点击下一步回调函数 */
    onNext?: () => void;
    /** 点击上一步回调函数 */
    onPrev?: () => void;
    /** 点击当前回调函数 */
    onCurrent?: () => void;
    /**
     * 下一步按钮是否可用
     * @default false
     */
    nextDisabled?: boolean;
    /**
     * 上一步按钮是否可用
     * @default false
     */
    prevDisabled?: boolean;
    /**
     * 当前按钮是否可用
     * @default false
     */
    curDisabled?: boolean;
    /** 下一步提示文案 */
    nextTitle?: string;
    /** 上一步提示文案 */
    prevTitle?: string;
    /** 当前提示文案 */
    curTitle?: string;
}
export declare function Jumper({ direction, noBordered, showCurrent, isCurrent, onNext, onPrev, onCurrent, nextDisabled, prevDisabled, curDisabled, nextTitle, prevTitle, curTitle, className, style, }: JumperProps): JSX.Element;
