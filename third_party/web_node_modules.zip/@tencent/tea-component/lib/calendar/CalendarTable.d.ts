import React from "react";
import { Moment } from "moment";
import { ControlledProps } from "../form/controlled";
import { TimeDisabledProps } from "../timepicker/TimeProps";
import { RangeDateType, showTimeType, CalendarTableType, DateChangeContext } from "./DateProps";
export interface CalendarTableProps extends ControlledProps<Moment | RangeDateType, React.SyntheticEvent, DateChangeContext> {
    /**
     * 允许选择的时间范围限制
     */
    range?: RangeDateType;
    /**
     * 不可选的日期
     */
    disabledDate?: (date: Moment, startDate?: Moment) => boolean;
    /**
     * 不可选的时间
     */
    disabledTime?: (date: Moment | RangeDateType, partial?: "start" | "end") => TimeDisabledProps;
    /**
     * 是否开启时间选择
     */
    showTime?: showTimeType<Moment>;
    /**
     * 当前展示日期
     */
    curViewMoment?: Moment;
    /**
     * 当前展示日期改变回调
     */
    onCurViewMomentChange?: (date: Moment) => void;
    /**
     * 当前展示的日历类型
     */
    type: CalendarTableType;
    /**
     * 日历类型改变回调
     */
    onTypeChange?: (types: CalendarTableType) => void;
    /**
     * 作为范围选择部分时的位置
     */
    rangeType?: "start" | "end";
    /**
     * 是否只选择到月份
     */
    monthOnly?: boolean;
}
/**
 * 获取当前时间选择范围
 */
export declare function getTimeRange(value: Moment, range?: RangeDateType): RangeDateType;
export declare function CalendarTable({ value, onChange, type, onTypeChange, curViewMoment, onCurViewMomentChange, range, disabledDate, disabledTime, showTime, rangeType, monthOnly, }: CalendarTableProps): JSX.Element;
