/// <reference types="react" />
import { Moment } from "moment";
import { ChangeContext } from "../form/controlled";
export declare type RangeDateType = [Moment, Moment];
export declare type CalendarTableType = "date" | "time" | "month" | "year";
export declare type showTimeType<T> = boolean | {
    /**
     * 默认值
     */
    defaultValue?: T;
    /**
     * 小时选项间隔
     * @default 1
     */
    hourStep?: number;
    /**
     * 秒选项间隔
     * @default 1
     */
    minuteStep?: number;
    /**
     * 分钟选项间隔
     * @default 1
     */
    secondStep?: number;
    /**
     * 时间格式，用于指定显示各列
     *
     * @default "HH:mm:ss"
     */
    format?: string;
    /**
     * 顶部内容
     */
    caption?: React.ReactNode;
};
export interface DateChangeContext extends ChangeContext<React.SyntheticEvent> {
    type?: CalendarTableType;
}
