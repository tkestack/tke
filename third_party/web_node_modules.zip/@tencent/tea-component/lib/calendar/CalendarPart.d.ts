import React from "react";
import { StyledProps } from "../_type";
import { JustifyProps } from "../justify";
declare const _default: {
    Panel: typeof CalendarPanel;
    Header: typeof CalendarHeader;
    Body: typeof CalendarBody;
    Footer: typeof CalendarFooter;
};
export default _default;
/**
 * 日历面板
 */
declare type ContainerProps = StyledProps & {
    children: React.ReactNode;
};
export declare function CalendarPanel({ style, className, children, rangeMode, timeMode, }: ContainerProps & {
    rangeMode?: boolean;
    timeMode?: boolean;
}): JSX.Element;
export declare function CalendarHeader({ style, className, children }: ContainerProps): JSX.Element;
export declare function CalendarBody({ style, className, children }: ContainerProps): JSX.Element;
export declare function CalendarFooter({ style, className, left, right, }: StyledProps & JustifyProps): JSX.Element;
