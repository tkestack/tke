/// <reference types="react" />
import { BasicLineProps } from "../basicline";
import { Omit } from "../_type";
/**
 * SimpleLine 组件支持的属性。
 */
export interface SimpleLineProps extends Omit<BasicLineProps, "xAxis" | "color" | "scale" | "legend" | "yAxis" | "tooltip"> {
    /**
     *  Y 轴
     * @default false
     */
    yAxis?: boolean | BasicLineProps["yAxis"];
    /**
     * 提示框
     * @default false
     */
    tooltip?: BasicLineProps["tooltip"];
}
export declare function SimpleLine(props: SimpleLineProps): JSX.Element;
