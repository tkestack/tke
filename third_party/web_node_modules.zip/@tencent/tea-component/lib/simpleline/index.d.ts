export { SimpleLine, SimpleLineProps } from "./SimpleLine";
