import React from "react";
import { StyledProps } from "../_type";
import { ProgressInfo, UploadEventContext } from "./uploadFile";
export interface UploadProps extends StyledProps {
    /**
     * 唤起文件选择的组件
     *
     * 直接传递 ReactNode 将默认在该元素使用点击上传
     *
     * 使用 Render Props 形式可自定义点击/拖拽上传
     *
     *  - `open`: 打开文件选择
     *  - `getDraggerProps(props?)`: 在需要执行拖拽的根元素传递这些 props
     *  - `isDragging`: 是否有文件拖拽至可拖拽区域
     *
     * @docType React.ReactNode | (props: { open: () => void, getDraggerProps: (props?: object) => object, isDragging: boolean }) => React.ReactNode;
     */
    children: React.ReactNode | ((props: {
        open: () => void;
        getDraggerProps: (props?: object) => object;
        isDragging: boolean;
    }) => React.ReactNode);
    /**
     * 是否支持多选文件
     * @default false
     */
    multiple?: boolean;
    /**
     * 上传地址
     */
    action?: string;
    /**
     * 接受的文件类型
     */
    accept?: string | string[];
    /**
     * 上传文件大小限制（bytes）
     */
    maxSize?: number;
    /**
     * 请求文件参数名
     * @default "file"
     */
    name?: string;
    /**
     * 设置请求头部
     */
    headers?: object | ((file: File) => object);
    /**
     * 附加请求参数
     */
    data?: object | ((file: File) => object);
    /**
     * 请求时是否携带 cookie
     * @default false
     */
    withCredentials?: boolean;
    /**
     * 上传文件前调用
     *
     *  - `isAccepted`: 当前文件是否符合 `accept` 及 `maxSize` 限制
     *
     * 返回 `true` 执行上传，返回 `false` 时不执行后续上传流程
     */
    beforeUpload?: (file: File, fileList: File[], isAccepted: boolean) => boolean;
    /**
     * 上传开始时回调
     */
    onStart?: (file: File, context: {
        xhr: XMLHttpRequest;
    }) => void;
    /**
     * 上传进度更新时回调
     */
    onProgress?: (progress: ProgressInfo, context: UploadEventContext) => void;
    /**
     * 上传成功时回调
     */
    onSuccess?: (result: object | string, context: UploadEventContext) => void;
    /**
     * 上传失败时回调
     */
    onError?: (error: Error, context: UploadEventContext) => void;
}
export declare function Upload({ action, accept, maxSize, multiple, headers, data, name, withCredentials, beforeUpload, onStart, onProgress, onSuccess, onError, children, className, style, }: UploadProps): JSX.Element;
export declare namespace Upload {
    var defaultLabelAlign: string;
}
