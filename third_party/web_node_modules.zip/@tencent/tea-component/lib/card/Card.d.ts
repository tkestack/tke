import React from "react";
import { StyledProps, InferProps } from "../_type";
/**
 * 卡片组件 `<Card>` 属性集合。
 */
export interface CardProps extends StyledProps {
    /**
     * 卡片内容，可包含
     *
     * - `<Card.Header>` 卡片头部
     * - `<Card.Body>` 卡片主体
     * - `<Card.Footer>` 卡片底部
     */
    children?: React.ReactNode;
    /**
     * 是否显示为带边框样式
     */
    bordered?: boolean;
    /**
     * 是否铺满内容区
     *
     * - `false` - 不铺满
     * - `true` - 铺满（页面不包含顶部一级标题，即 `Layout.Content.Header`）
     * - `"withHeader"` - 铺满（页面包含顶部一级标题，即 `Layout.Content.Header`）
     */
    full?: boolean | "withHeader";
}
declare const CardHeader: React.ForwardRefExoticComponent<import("../_util/create-rocket").RocketProps & React.RefAttributes<HTMLElement>>;
declare const CardFooter: React.ForwardRefExoticComponent<import("../_util/create-rocket").RocketProps & React.RefAttributes<HTMLElement>>;
/**
 * 卡片头部 `<Card.Header>` 属性集合。
 */
export interface CardHeaderProps extends InferProps<typeof CardHeader> {
}
/**
 * 卡片主体 `<Card.Body>` 属性集合。
 */
export interface CardBodyProps extends StyledProps {
    /**
     * 内容标题（可选）
     */
    title?: React.ReactNode;
    /**
     * 内容小标题（可选）
     */
    subtitle?: React.ReactNode;
    /**
     * 操作区（可选）
     */
    operation?: React.ReactNode;
    /**
     * 内容
     */
    children?: React.ReactNode;
}
/**
 * 卡片底部 `<Card.Footer> 属性列表`
 */
export interface CardFooterProps extends InferProps<typeof CardFooter> {
}
export declare const Card: React.FunctionComponent<CardProps & React.RefAttributes<HTMLDivElement>> & {
    Header: React.ForwardRefExoticComponent<import("../_util/create-rocket").RocketProps & React.RefAttributes<HTMLElement>>;
    Body: React.ForwardRefExoticComponent<CardBodyProps & React.RefAttributes<HTMLDivElement>>;
    Footer: React.ForwardRefExoticComponent<import("../_util/create-rocket").RocketProps & React.RefAttributes<HTMLElement>>;
};
export {};
