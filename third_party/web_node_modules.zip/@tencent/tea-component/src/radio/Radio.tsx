import React, { Ref } from "react";
import { Omit } from "../_type";
import { CheckProps, Check } from "../check";
import { RadioGroup } from "./RadioGroup";
import { forwardRefWithStatics } from "../_util/forward-ref-with-statics";

/**
 * Radio 组件所接收的属性
 */
export interface RadioProps
  extends Omit<CheckProps, "type" | "indeterminate"> {}

export const Radio = forwardRefWithStatics(
  (props: RadioProps, ref: Ref<HTMLLabelElement>) => {
    return <Check ref={ref} type="radio" {...props} />;
  },
  // statics
  {
    Group: RadioGroup,
  }
);

Radio.displayName = "Radio";
