/* eslint-disable-next-line */
/// <reference path="../../node_modules/monaco-editor/monaco.d.ts" />

const bundle = process.env.NODE_ENV === "development" ? "dev" : "min";
const bundlePath = `https://imgcache.qq.com/qcloud/main/scripts/release/common/vendors/monaco-editor/${bundle}/`;
const loaderPath = `${bundlePath}/vs/loader.js`;

let prepared = null;

/* eslint-disable dot-notation */

// eslint-disable-next-line no-undef
export async function prepareMonaco(): Promise<typeof monaco> {
  if (prepared) return prepared;

  if (typeof window["AMDLoader"] !== "object") {
    if (await prepareLoader()) {
      return prepareMonaco();
    }
    throw new Error("Can not load monaco editor");
  }
  /**
   * 解决 worker 跨域问题
   * @see https://github.com/Microsoft/monaco-editor#integrate-cross-domain
   */
  const workerCode = `
		self.MonacoEnvironment = {
			baseUrl: '${bundlePath}'
		};
		importScripts('${bundlePath}/vs/base/worker/workerMain.js');
	`;
  const worker = URL.createObjectURL(
    new Blob([workerCode], {
      type: "text/javascript",
    })
  );

  // eslint-disable-next-line no-undef
  prepared = new Promise<typeof monaco>((resolve, reject) => {
    window["_amdreq"].config({
      paths: {
        vs: `https://imgcache.qq.com/qcloud/main/scripts/release/common/vendors/monaco-editor/${bundle}/vs`,
      },
      "vs/nls": {
        availableLanguages: {
          "vs/editor/editor.main": "zh-cn",
        },
      },
    });

    const timer = setTimeout(() => {
      reject(new Error("Load editor script timeout"));
    }, 5 * 1000);

    // 手动指定worker路径为一个blob url
    window["MonacoEnvironment"] = {
      getWorkerUrl: () => worker,
    };

    window["_amdreq"](["vs/editor/editor.main"], () => {
      clearTimeout(timer);
      if (window["monaco"]) {
        const editorCss = document.querySelector(
          'link[data-name="vs/editor/editor.main"]'
        );
        if (editorCss) {
          editorCss.setAttribute("data-role", "global");
        }
        resolve(window["monaco"]);
      } else {
        reject(new Error("Init script error! global.monaco not found"));
      }
    });
  });

  return prepared;
}

let preparingLoader = null;
function prepareLoader() {
  preparingLoader =
    preparingLoader ||
    new Promise((resolve, reject) => {
      const callback = () => {
        if (typeof window["AMDLoader"] === "object" && window["AMDLoader"]) {
          resolve(window["AMDLoader"]);
        } else {
          reject(new Error("Cannot load AMDLoader"));
        }
      };
      if (
        typeof window["seajs"] === "object" &&
        window["seajs"] &&
        window["seajs"].use
      ) {
        window["seajs"].use(loaderPath, callback);
      } else {
        const script = document.createElement("script");
        script.onload = callback;
        script.onerror = callback;
        script.src = loaderPath;
        document.head.appendChild(script);
      }
    });
  return preparingLoader;
}

/* eslint-enable dot-notation */
