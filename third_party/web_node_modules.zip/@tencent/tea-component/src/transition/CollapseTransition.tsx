import React from "react";
import { CSSTransition } from "react-transition-group";
import { TransitionProps } from "react-transition-group/Transition";
import { collapse } from "../_util/transition";

export interface CollapseTransitionProps extends Partial<TransitionProps> {
  /**
   * 动画元素目标高度
   */
  height?: number;
}

export function CollapseTransition({
  height,
  timeout,
  ...rest
}: CollapseTransitionProps) {
  let enterTimeout: number;
  let exitTimeout: number;
  if (typeof timeout === "number") {
    enterTimeout = timeout;
    exitTimeout = timeout;
  } else if (timeout && typeof timeout === "object") {
    enterTimeout = timeout.enter;
    exitTimeout = timeout.exit;
  }
  return (
    <CSSTransition {...collapse(height, enterTimeout, exitTimeout)} {...rest} />
  );
}
