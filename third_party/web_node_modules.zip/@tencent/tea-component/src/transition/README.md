# Transition 转场动画

Tea 组件内置了渐变、缩放、滑动、收起四种转场动画。

## 使用示例

[Example: TransitionExample](./_example/TransitionExample.jsx)

## 组件属性

[Interface: SlideTransitionProps](./SlideTransition.tsx)
