import React from "react";
import { CSSTransition } from "react-transition-group";
import { TransitionProps } from "react-transition-group/Transition";
import { scale } from "../_util/transition";

export interface ScaleTransitionProps extends Partial<TransitionProps> {
  /**
   * 从哪个缩放系数进场，默认为 0.5
   */
  from?: number;

  /**
   * 从哪个缩放系数离场，默认与 from 一致
   */
  to?: number;

  /**
   * 缩放原点
   */
  origin?: string;
}

export function ScaleTransition({
  from,
  to,
  timeout,
  origin,
  ...rest
}: ScaleTransitionProps) {
  let enterTimeout: number;
  let exitTimeout: number;
  if (typeof timeout === "number") {
    enterTimeout = timeout;
    exitTimeout = timeout;
  } else if (timeout && typeof timeout === "object") {
    enterTimeout = timeout.enter;
    exitTimeout = timeout.exit;
  }
  return (
    <CSSTransition
      {...scale(from, to, enterTimeout, exitTimeout, origin)}
      {...rest}
    />
  );
}
