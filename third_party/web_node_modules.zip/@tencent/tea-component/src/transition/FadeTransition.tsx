import React from "react";
import { CSSTransition } from "react-transition-group";
import { TransitionProps } from "react-transition-group/Transition";
import { fade } from "../_util/transition";

export interface FadeTransitionProps extends Partial<TransitionProps> {
  /**
   * 目标出现时的透明度，默认为 1
   */
  opacity?: number;
}

export function FadeTransition({
  opacity,
  timeout,
  ...rest
}: FadeTransitionProps) {
  let enterTimeout: number;
  let exitTimeout: number;
  if (typeof timeout === "number") {
    enterTimeout = timeout;
    exitTimeout = timeout;
  } else if (timeout && typeof timeout === "object") {
    enterTimeout = timeout.enter;
    exitTimeout = timeout.exit;
  }
  return (
    <CSSTransition {...fade(opacity, enterTimeout, exitTimeout)} {...rest} />
  );
}
