# Dropdown 下拉

Dropdown 用于显示下拉交互。弹出的内容可以是菜单，也可以是其它内容。

如果要使用类似原生 select 的交互，请使用 Select 组件。

## 使用示例

[Example: Dropdown](./_example/DropdownExample.jsx)

## 组件属性

[Interface: DropdownProps](./Dropdown.tsx)
