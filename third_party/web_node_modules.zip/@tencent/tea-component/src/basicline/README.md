# BasicLine 基本折线

基本折线是其他折线组件的基础组件，包含几乎全部属性，但是意味着使用起来会较为复杂。建议选择特定场景的组件来使用。

## 使用示例

对于最简单的使用只需要配置少量参数即可

[Example: 基本使用](./_example/SimpleLine.jsx)

使用颜色来区分多条数据系列

[Example: 基本使用](./_example/MultipleLine.jsx)

也可以自定义提示框

[Example: 基本使用](./_example/Tooltip.jsx)

当数据量比较大导致线条太粗无法看清数据时，可以调整折线的宽度

[Example: 折线宽度](./_example/LineWidth.jsx)

可以设置值域范围，使折线处于较为平稳的状态

[Example: 值域设置](./_example/Domain.jsx)

当 `dataSource` 为空时，默认会显示数据为空状态，也可以自己定义状态的展示

[Example: 状态](./_example/Status.jsx)

## 组件属性

[Interface: BasicLineProps](./BasicLine.tsx)

[Interface: Scale](../_chart/type/chart.ts)