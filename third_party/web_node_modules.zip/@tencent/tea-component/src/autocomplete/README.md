# AutoComplete 自动补全

提供输入类组件自动补全功能。

## 使用示例

### 基本用法

[Example: AutoComplete](./_example/AutoCompleteExample.jsx)

### 异步加载

[Example: AutoCompleteAsync](./_example/AutoCompleteAsyncExample.jsx)

## 组件属性

[Interface: AutoCompleteProps](./AutoComplete.tsx)
