import React from "react";
import classNames from "classnames";
import { StyledProps } from "../_type";
import { JustifyProps, Justify } from "../justify";

export default {
  Panel: CalendarPanel,
  Header: CalendarHeader,
  Body: CalendarBody,
  Footer: CalendarFooter,
};

/**
 * 日历面板
 */
type ContainerProps = StyledProps & { children: React.ReactNode };

export function CalendarPanel({
  style,
  className,
  children,
  rangeMode = false,
  timeMode = false,
}: ContainerProps & { rangeMode?: boolean; timeMode?: boolean }) {
  return (
    <div
      className={classNames("tea-calendar", className, {
        "tea-calendar--date-range": rangeMode,
        "tea-calendar--time": timeMode,
      })}
      style={style}
    >
      {children}
    </div>
  );
}

export function CalendarHeader({ style, className, children }: ContainerProps) {
  return (
    <div
      className={classNames("tea-calendar__header", className)}
      style={style}
    >
      {children}
    </div>
  );
}

export function CalendarBody({ style, className, children }: ContainerProps) {
  return (
    <div className={classNames("tea-calendar__body", className)} style={style}>
      {children}
    </div>
  );
}

export function CalendarFooter({
  style,
  className,
  left,
  right,
}: StyledProps & JustifyProps) {
  return (
    <div
      className={classNames("tea-calendar__footer", className)}
      style={style}
    >
      <Justify left={left} right={right} />
    </div>
  );
}
