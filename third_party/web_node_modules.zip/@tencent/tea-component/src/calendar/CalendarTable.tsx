import React, { useRef } from "react";
import moment, { Moment, isMoment } from "moment";
import { DateTable } from "./tables/DateTable";
import { ControlledProps } from "../form/controlled";
import { CellStatus } from "./tables/BaseTable";
import { MonthTable } from "./tables/MonthTable";
import { ScaleTransition } from "../transition/ScaleTransition";
import { YearTable } from "./tables/YearTable";
import { TimeDisabledProps } from "../timepicker/TimeProps";
import { TimeTable } from "../timepicker/TimeTable";
import { useTranslation } from "../i18n";
import {
  RangeDateType,
  showTimeType,
  CalendarTableType,
  DateChangeContext,
} from "./DateProps";

export interface CalendarTableProps
  extends ControlledProps<
    Moment | RangeDateType,
    React.SyntheticEvent,
    DateChangeContext
  > {
  /**
   * 允许选择的时间范围限制
   */
  range?: RangeDateType;

  /**
   * 不可选的日期
   */
  disabledDate?: (date: Moment, startDate?: Moment) => boolean;

  /**
   * 不可选的时间
   */
  disabledTime?: (
    date: Moment | RangeDateType,
    partial?: "start" | "end"
  ) => TimeDisabledProps;

  /**
   * 是否开启时间选择
   */
  showTime?: showTimeType<Moment>;

  /**
   * 当前展示日期
   */
  curViewMoment?: Moment;

  /**
   * 当前展示日期改变回调
   */
  onCurViewMomentChange?: (date: Moment) => void;

  /**
   * 当前展示的日历类型
   */
  type: CalendarTableType;

  /**
   * 日历类型改变回调
   */
  onTypeChange?: (types: CalendarTableType) => void;

  /**
   * 作为范围选择部分时的位置
   */
  rangeType?: "start" | "end";

  /**
   * 是否只选择到月份
   */
  monthOnly?: boolean;
}

/**
 * 动画参数
 */
const ZOMM_OUT = 1.04;
const ZOOM_IN = 1 / ZOMM_OUT;

/**
 * 获取当前时间选择范围
 */
export function getTimeRange(
  value: Moment,
  range: RangeDateType = [null, null]
): RangeDateType {
  if (!Array.isArray(range) || !value) {
    return undefined;
  }
  const [min, max] = range;
  const timeRange: RangeDateType = [
    moment().startOf("day"),
    moment().endOf("day"),
  ];
  if (isMoment(min) && value.isSame(min, "day")) {
    timeRange[0] = min;
  }
  if (isMoment(max) && value.isSame(max, "day")) {
    timeRange[1] = max;
  }
  return timeRange;
}

export function CalendarTable({
  value,
  onChange,
  type,
  onTypeChange,
  curViewMoment = moment(),
  onCurViewMomentChange,
  range,
  disabledDate = () => true,
  disabledTime = () => ({}),
  showTime,
  rangeType,
  monthOnly,
}: CalendarTableProps) {
  const t = useTranslation();

  // 记录 Table 切换
  const prevTypeRef = useRef<CalendarTableType>(null);
  const prevType = prevTypeRef.current;
  if (type === "month" || type === "date") {
    prevTypeRef.current = type;
  }

  const tableProps = {
    range,
    onTypeChange,
    current: curViewMoment,
    onCurrentChange: onCurViewMomentChange,
  };

  const timeProps = typeof showTime === "object" ? showTime : {};

  function getValue(): Moment {
    if (!Array.isArray(value)) {
      return value;
    }
    if (rangeType === "start") {
      return value[0];
    }
    return value[1];
  }

  return (
    <>
      {/* Year */}
      <ScaleTransition in={type === "year"} exit={false} from={ZOMM_OUT}>
        <YearTable
          {...tableProps}
          onSelect={value => {
            onCurViewMomentChange(moment(curViewMoment).year(value.year()));
            onTypeChange(prevType || (monthOnly ? "date" : "month"));
          }}
          cellStatus={date => {
            if (!Array.isArray(value)) {
              if (isMoment(value) && date.isSame(value, "year")) {
                return CellStatus.Selected;
              }
            }
            return CellStatus.Common;
          }}
        />
      </ScaleTransition>

      {/* Month */}
      <ScaleTransition
        in={type === "month"}
        exit={false}
        from={prevType !== "date" ? ZOOM_IN : ZOMM_OUT}
      >
        <MonthTable
          {...tableProps}
          onSelect={(value, context) => {
            onCurViewMomentChange(moment(curViewMoment).month(value.month()));
            if (monthOnly) {
              onChange(value, context);
              return;
            }
            onTypeChange("date");
          }}
          cellStatus={date => {
            if (!Array.isArray(value)) {
              if (isMoment(value) && date.isSame(value, "month")) {
                return CellStatus.Selected;
              }
            }
            return CellStatus.Common;
          }}
        />
      </ScaleTransition>

      {/* Date */}
      <ScaleTransition in={type === "date"} exit={false} from={ZOOM_IN}>
        <DateTable
          {...tableProps}
          value={getValue()}
          disabledDate={(date: Moment) => {
            // 范围选择已选择 start，未选择 end
            if (
              Array.isArray(value) &&
              isMoment(value[0]) &&
              !isMoment(value[1])
            ) {
              return disabledDate(date, value[0]);
            }
            return disabledDate(date);
          }}
          onSelect={(v, context) => {
            // 单日选择
            context.type = "date";
            if (!Array.isArray(value)) {
              return onChange(v, context);
            }
            // 范围选择
            if (isMoment(value[0]) && !isMoment(value[1])) {
              if (value[0].isBefore(v)) {
                return onChange([value[0], v], context);
              }
              return onChange([v, value[0]], context);
            }
            return onChange([v, null], context);
          }}
          cellStatus={date => {
            // 单日选择
            if (!Array.isArray(value)) {
              if (isMoment(value) && date.isSame(value, "day")) {
                return CellStatus.Selected;
              }
              return CellStatus.Common;
            }
            // 范围选择
            if (isMoment(value[0]) && date.isSame(value[0], "day")) {
              // 只选中了开始或开始结束在同一天返回 Selected
              if (!isMoment(value[1])) {
                return CellStatus.Selected;
              }
              if (value[0].isSame(value[1], "day")) {
                return CellStatus.Selected;
              }
              return CellStatus.RangeStart;
            }
            if (isMoment(value[1]) && date.isSame(value[1], "day")) {
              return CellStatus.RangeEnd;
            }
            if (isMoment(value[0]) && isMoment(value[1])) {
              if (value[0].isBefore(date) && value[1].isAfter(date)) {
                return CellStatus.InRange;
              }
            }
            return CellStatus.Common;
          }}
        />
      </ScaleTransition>

      {/* Time */}
      <ScaleTransition in={type === "time"} exit={false} from={ZOMM_OUT}>
        <TimeTable
          caption={isMoment(getValue()) ? getValue().format("L") : t.selectTime}
          value={getValue()}
          onChange={(v, context) => {
            context.type = "time";
            // 日期选择完才可选择时间，所以 value 必定合法
            if (!Array.isArray(value)) {
              return onChange(v, context);
            }
            if (rangeType === "start") {
              return onChange([v, value[1]], context);
            }
            return onChange([value[0], v], context);
          }}
          range={getTimeRange(getValue(), range)}
          {...disabledTime(value, rangeType) || {}}
          {...timeProps}
        />
      </ScaleTransition>
    </>
  );
}
