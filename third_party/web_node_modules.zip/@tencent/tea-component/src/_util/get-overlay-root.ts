/**
 * 获取/创建对话框容器
 */

const rootId = "tea-overlay-root";
let root: HTMLElement;

export function getOverlayRoot() {
  root = root || document.getElementById(rootId);
  if (!root) {
    root = document.createElement("div");
    root.id = rootId;
    document.body.appendChild(root);
  }
  return root;
}
