import onClickOutSide from "react-onclickoutside";

export function withClickOutSide(methodName?: string) {
  return <P, T extends React.ComponentType<P>>(Component: T) =>
    (onClickOutSide(Component, {
      handleClickOutside: instance => instance[methodName],
    }) as any) as T;
}
