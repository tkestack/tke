import { useEffect, useRef } from "react";

export function useScheduleUpdate(deps = []) {
  const scheduleRef = useRef(null);
  useEffect(() => {
    if (scheduleRef.current) {
      scheduleRef.current();
    }
  }, deps);
  return fn => {
    scheduleRef.current = fn;
  };
}
