import { useEffect } from "react";

export function useResize(handler: (event: UIEvent) => void) {
  useEffect(() => {
    window.addEventListener("resize", handler);
    return () => window.removeEventListener("resize", handler);
  }, [handler]);
}
