import React from "react";
import { isChildOfType } from "./is-child-of-type";

export function getPropsFromChildrenByType<P>(
  children: React.ReactNode,
  component: React.ComponentType<P>
) {
  const props = [] as P[];

  const dfs = (_children: React.ReactNode) => {
    React.Children.forEach(_children, child => {
      if (isChildOfType(child, component as any)) {
        props.push(child.props);
      } else if (
        React.isValidElement<{ children: any }>(child) &&
        child.props.children
      ) {
        dfs(child.props.children);
      }
    });
  };

  dfs(children);
  return props;
}
