import * as TeaComponentV2 from "./index";

/**
 * 输出到 TeaComponentV2 全局变量
 */
window["TeaComponentV2"] = TeaComponentV2; // eslint-disable-line dot-notation
