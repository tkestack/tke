import React, { useRef } from "react";
import ReactDOM from "react-dom";
import classNames from "classnames";
import { createRocket } from "../_util/create-rocket";
import { StyledProps } from "../_type";
import { Justify } from "../justify";
import { Button } from "../button";
import { SlideTransition } from "../transition";
import { useOutsideClick } from "../_util/use-outside-click";

export interface DrawerProps extends StyledProps {
  /**
   * Drawer 是否可见
   */
  visible: boolean;

  /**
   * 点击关闭图标或抽屉外区域的回调
   */
  onClose: () => void;

  /**
   * 抽屉方向
   * @default "right"
   */
  placement?: "right" | "left";

  /**
   * 抽屉大小
   *
   * - `"m"` - 360px
   * - `"l"` - 800px
   *
   * @default "m"
   */
  size?: "m" | "l";

  /**
   * Drawer 中的内容
   */
  children?: React.ReactNode;

  /**
   * Drawer 底部内容
   */
  footer?: React.ReactNode;

  /**
   * 头部标题
   */
  title?: React.ReactNode;

  /**
   * 头部副标题/说明文字
   */
  subtitle?: React.ReactNode;

  /**
   * **\[Deprecated\]** 请使用 `subtitle` 属性
   *
   * @deprecated
   */
  subTitle?: React.ReactNode;

  /**
   * 头部右侧渲染内容
   */
  extra?: React.ReactNode;

  /**
   * 点击面板外是否收起面板
   * @default true
   */
  outerClickClosable?: boolean;

  /**
   * 是否禁用头部关闭图标
   * @default false
   */
  disableCloseIcon?: boolean;

  /**
   * 是否禁用展开/收起动效
   * @default false
   */
  disableAnimation?: boolean;
}

export function Drawer({
  className,
  style,
  children,
  visible,
  onClose = () => null,
  size,
  placement,
  footer,
  title,
  subTitle,
  subtitle = subTitle,
  extra,
  disableCloseIcon,
  disableAnimation,
  outerClickClosable = true,
}: DrawerProps) {
  const ref = useRef(null);
  const { listen } = useOutsideClick(ref);
  const { portalInterceptProps } = listen(
    () => outerClickClosable && onClose()
  );

  const width = size === "l" ? 800 : 320;
  const from = placement === "left" ? 0 - width : width;
  const showHeader = title || subtitle || extra || !disableCloseIcon;

  return ReactDOM.createPortal(
    <SlideTransition
      in={visible}
      from={[from, 0]}
      timeout={disableAnimation ? 0 : undefined}
    >
      <div
        ref={ref}
        style={style}
        className={classNames("tea-drawer", className, {
          "tea-drawer--left": placement === "left",
          "size-l": size === "l",
        })}
        {...portalInterceptProps}
      >
        {showHeader && (
          <div className="tea-drawer__header">
            <Justify
              left={<DrawerTitle title={title} subtitle={subtitle} />}
              right={
                <>
                  {extra}
                  {!disableCloseIcon && (
                    <Button icon="close" onClick={onClose} />
                  )}
                </>
              }
            />
          </div>
        )}
        <DrawerBody>{children}</DrawerBody>
        {footer && <DrawerFooter>{footer}</DrawerFooter>}
      </div>
    </SlideTransition>,
    document.body
  );
}

function DrawerTitle({
  title,
  subtitle,
}: Pick<DrawerProps, "title" | "subtitle">) {
  const sub =
    typeof subtitle === "string" ? (
      <span className="tea-card__subtitle">{subtitle}</span>
    ) : (
      subtitle
    );

  if (typeof title === "string") {
    return (
      <h3 className="tea-h3">
        {title}
        {sub}
      </h3>
    );
  }
  return (
    <>
      {title}
      {sub}
    </>
  );
}

const DrawerBody = createRocket(
  "DrawerBody",
  "div.tea-drawer__body",
  "div.tea-drawer__body-inner"
);
const DrawerFooter = createRocket("DrawerFooter", "div.tea-drawer__footer");
