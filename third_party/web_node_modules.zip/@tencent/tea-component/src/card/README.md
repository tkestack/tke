# Card 卡片

基础的容器组件，可以容纳任意内容。

## 使用示例

[Example: 卡片的使用](./_example/CardExample.jsx)

## 使用场景

[传送门](http://teaui.pages.oa.com/#/card?a=%E4%BD%BF%E7%94%A8%E5%9C%BA%E6%99%AF)

## 组件属性

[Interface: CardProps](./Card.tsx)

[Interface: CardHeaderProps](./Card.tsx)

[Interface: CardBodyProps](./Card.tsx)

[Interface: CardFooterProps](./Card.tsx)
