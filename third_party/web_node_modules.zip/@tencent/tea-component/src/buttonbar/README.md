---
category: 表单
---

# (DEPRECATED) 按钮选项组（ButtonBar）

ButtonBar 已废弃，请使用 Segment 组件。

## 使用示例

[Example: ButtonBarExample](./_example/ButtonBarExample.jsx)
