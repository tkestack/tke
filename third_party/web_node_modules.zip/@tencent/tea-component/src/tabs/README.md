# Tabs 选项卡

通过按钮快速切换多个视图。

## 基本用法

[Example: Tabs](./_example/TabsExample.jsx)

## 新增和关闭

[Example: TabsClosable](./_example/TabsClosableExample.jsx)

## 搭配 Layout

可以指定 `ceiling` 属性来搭配 Layout。

[Example: TabsCeiling](../layout/_example/LayoutContentWithTabsExample.jsx)

## 配合路由使用

[Example: TabsWithRouter](./_example/TabsWithRouterExample.jsx)

## 组件属性

[Interface: TabsProps](./TabProps.tsx)

[Interface: TabPanelProps](./TabPanel.tsx)
