# BasicLine 基本柱状图

基本柱状图是其他柱状图组件的基础组件，包含几乎全部属性，但是意味着使用起来会较为复杂。建议选择特定场景的组件来使用。

## 使用示例

对于最简单的使用只需要配置少量参数即可

[Example: 基本使用](./_example/SimpleBar.jsx)

使用颜色来区分多条数据系列

[Example: 基本使用](./_example/MultipleBar.jsx)

若包含大量数据，推荐使用折线图，而非柱状图

[Example: 大量数据](./_example/LargeValue.jsx)

## 组件属性

[Interface: BasicBarProps](./BasicBar.tsx)

[Interface: Scale](../_chart/type/chart.ts)
