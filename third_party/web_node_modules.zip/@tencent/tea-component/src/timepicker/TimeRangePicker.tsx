import React, { useState, useEffect, useRef, useCallback } from "react";
import classNames from "classnames";
import moment, { isMoment } from "moment";
import { ControlledProps, useDefaultValue } from "../form/controlled";
import CalendarPart from "../calendar/CalendarPart";
import { CalendarTable } from "../calendar/CalendarTable";
import { Combine, Omit } from "../_type";
import { Input } from "../input/Input";
import { useTranslation } from "../i18n";
import { getValidTimeValue } from "./util";
import { TimeDisabledProps, TimePickerProps } from "./TimeProps";
import { DropdownBox } from "../dropdown";
import { RangeDateType } from "../calendar/DateProps";
import { withStatics } from "../_util/with-statics";
import { CommonDatePickerProps } from "../datepicker";
import { Button } from "../button";
import { Popover } from "../popover/Popover";
import { DatePickerTrigger } from "../datepicker/util";
import { useDefault } from "../_util/use-default";

export interface TimeRangePickerProps
  extends Combine<
    Omit<CommonDatePickerProps, "header">,
    ControlledProps<RangeDateType>,
    Pick<TimePickerProps, "hourStep" | "minuteStep" | "secondStep">
  > {
  /**
   * 分隔符
   * @default ~
   */
  separator?: string;

  /**
   * placeholder
   * @default “选择时间”
   */
  placeholder?: string;

  /**
   * 日期展示格式
   * @default "HH:mm:ss"
   */
  format?: string;

  /**
   * 不可选的时间
   */
  disabledTime?: (
    dates: RangeDateType,
    partial: "start" | "end"
  ) => TimeDisabledProps;
}

const getDefaultMoment = (
  range: RangeDateType,
  disabledTime: TimeDisabledProps
) => {
  return getValidTimeValue(moment("00:00:00", "HH:mm:ss"), {
    range,
    ...disabledTime,
  });
};

function isValidRangeValue(value: any) {
  return Array.isArray(value) && isMoment(value[0]) && isMoment(value[1]);
}

export const TimeRangePicker = withStatics(
  function TimeRangePicker(props: TimeRangePickerProps) {
    const t = useTranslation(moment);

    const {
      className,
      style,
      value,
      onChange,
      disabled,
      separator = "~",
      format = "HH:mm:ss",
      placeholder = t.selectTime,
      defaultOpen = false,
      open,
      onOpenChange = () => null,
      placement = "bottom-start",
      placementOffset = 5,
      closeOnScroll = true,
      range,
      disabledTime = () => ({}),
      hourStep = 1,
      minuteStep = 1,
      secondStep = 1,
    } = useDefaultValue(props, [null, null]);

    // 当前选中时间
    const [curValue, setCurValue] = useState<RangeDateType>(
      isValidRangeValue(value)
        ? [value[0].clone(), value[1].clone()]
        : [null, null]
    );

    // 选择器是否展开
    const [active, setActive] = useDefault(open, defaultOpen, onOpenChange);

    // 输入框显示值
    const inputRef = useRef<HTMLInputElement>(null);
    const getInputValue = useCallback(
      (value: RangeDateType): string => {
        const [start, end] = value || [null, null];
        if (isMoment(start) && isMoment(end)) {
          return `${start
            .locale(t.locale)
            .format(format)} ${separator} ${end
            .locale(t.locale)
            .format(format)}`;
        }
        return "";
      },
      [format, separator, t.locale]
    );
    const [inputValue, setInputValue] = useState<string>(
      getInputValue(curValue)
    );

    useEffect(() => {
      const [start, end] = value;
      setCurValue([
        isMoment(start)
          ? start.clone()
          : getDefaultMoment(range, disabledTime(value, "start")),
        isMoment(end)
          ? end.clone()
          : getDefaultMoment(range, disabledTime(value, "end")),
      ]);
      setInputValue(getInputValue(value));
    }, [format, separator, value]); // eslint-disable-line react-hooks/exhaustive-deps

    function handleChange(
      value: RangeDateType
      // context: DateChangeContext
    ): void {
      const [start, end] = value;
      const fullValue: RangeDateType = [
        start || getDefaultMoment(range, disabledTime(value, "start")),
        end || getDefaultMoment(range, disabledTime(value, "end")),
      ];
      setCurValue(fullValue);
      // moment 更改后直接获取值（format）可能拿到是之前值
      setTimeout(() => setInputValue(getInputValue(fullValue)), 0);
    }

    function handleOk(event): void {
      let value = curValue;
      if (isValidRangeValue(curValue) && curValue[0].isAfter(curValue[1])) {
        value = [curValue[1], curValue[0]];
        setCurValue(value);
      }
      onChange(value, { event });
      handleClose();
    }

    function handleOpen(): void {
      if (disabled) {
        return;
      }
      setActive(true);
    }

    function handleClose(): void {
      setInputValue(getInputValue(value));
      setActive(false);
    }

    const timeProps = {
      hourStep,
      minuteStep,
      secondStep,
      format,
      caption: t.selectTime,
    };

    return (
      <Popover
        trigger={[
          DatePickerTrigger,
          { onOpen: handleOpen, onClose: handleClose },
        ]}
        visible={active}
        onVisibleChange={setActive}
        placement={placement}
        placementOffset={placementOffset}
        closeOnScroll={closeOnScroll}
        overlay={
          <DropdownBox>
            <CalendarPart.Panel rangeMode timeMode>
              <CalendarPart.Body>
                <CalendarTable
                  {...props}
                  rangeType="start"
                  type="time"
                  showTime={timeProps}
                  value={curValue}
                  onChange={handleChange}
                />
                <CalendarTable
                  {...props}
                  rangeType="end"
                  type="time"
                  showTime={timeProps}
                  value={curValue}
                  onChange={handleChange}
                />
              </CalendarPart.Body>
              <CalendarPart.Footer
                right={
                  <Button type="primary" onClick={handleOk}>
                    {t.okText}
                  </Button>
                }
              />
            </CalendarPart.Panel>
          </DropdownBox>
        }
      >
        <div className={classNames("tea-timepicker", className)} style={style}>
          <div className="tea-timepicker__input size-l">
            <Input
              ref={inputRef}
              maxLength={8}
              disabled={disabled}
              placeholder={placeholder}
              value={inputValue}
              onFocus={() => inputRef.current.blur()}
            />
          </div>
        </div>
      </Popover>
    );
  },
  { defaultLabelAlign: "middle" }
);
