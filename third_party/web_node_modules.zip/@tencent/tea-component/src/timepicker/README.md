# TimePicker 时间选择

时分秒选择控件。

## 依赖安装

日期相关组件实现依赖了 [moment](http://momentjs.com/)，使用时需自行安装：

```
npm install moment
```

## 使用示例

### 基本用法

[Example: TimePicker](./_example/TimePickerExample.jsx)

### 限制可选范围（range）

[Example: TimePickerRange](./_example/TimePickerRangeExample.jsx)

### 限制可选范围（disabled 函数）

[Example: TimePickerDisabled](./_example/TimePickerDisabledExample.jsx)

### 时间范围选择

[Example: TimeRangePicker](./_example/TimeRangePickerExample.jsx)

## 组件属性

[Interface: TimePickerProps](./TimeProps.tsx)

[Interface: TimeRangePickerProps](./TimeRangePicker.tsx)
