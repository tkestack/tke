import React, { useState, useRef, useEffect, useCallback } from "react";
import classNames from "classnames";
import moment, { Moment, isMoment } from "moment";
import CalendarPart from "../calendar/CalendarPart";
import { useDefaultValue } from "../form/controlled";
import { Input } from "../input";
import { TimeTable } from "./TimeTable";
import { Button } from "../button";
import { useTranslation } from "../i18n";
import { DropdownBox } from "../dropdown";
import { TimePickerProps } from "./TimeProps";
import {
  getHourMinuteSecond,
  genShowHourMinuteSecond,
  getDisabledHours,
  getDisabledSeconds,
  getDisabledMinutes,
} from "./util";
import { withStatics } from "../_util/with-statics";
import { TimeRangePicker } from "./TimeRangePicker";
import { useDefault } from "../_util/use-default";
import { Popover } from "../popover/Popover";
import { DatePickerTrigger } from "../datepicker/util";

const Keys = {
  "13": "enter",
  "27": "esc",
};

export const TimePicker = withStatics(
  function TimePicker(props: TimePickerProps) {
    const t = useTranslation(moment);

    const {
      value,
      onChange,
      format = "HH:mm:ss",
      placeholder = t.selectTime,
      disabled = false,
      hourStep = 1,
      minuteStep = 1,
      secondStep = 1,
      defaultOpen = false,
      open,
      onOpenChange = () => null,
      placement = "bottom-start",
      placementOffset = 5,
      closeOnScroll = true,
      className,
      style,
    } = useDefaultValue(props);

    const [curValue, setCurValue] = useState<Moment>(value);
    const [active, setActive] = useDefault(open, defaultOpen, onOpenChange);
    const [bubble, setBubble] = useState<string | null>(null);

    const inputRef = useRef<HTMLInputElement>(null);
    const getInputValue = useCallback(
      value => {
        return isMoment(value) ? value.locale(t.locale).format(format) : "";
      },
      [t.locale, format]
    );

    const [inputValue, setInputValue] = useState<string>(
      getInputValue(curValue)
    );

    useEffect(() => {
      setCurValue(value);
      setInputValue(getInputValue(value));
    }, [format, getInputValue, value]);

    function handleInputChange(content: string) {
      setInputValue(content);

      const value = moment(content, format, true);

      // 格式校验
      if (!value.isValid()) {
        setBubble(t.invalidFormat(format));
        return;
      }

      const { hour, minute, second } = getHourMinuteSecond(value);
      const { showHour, showMinute, showSecond } = genShowHourMinuteSecond(
        format
      );

      // 范围校验
      if (
        (showHour && getDisabledHours(props).includes(hour)) ||
        (showMinute && getDisabledMinutes(hour, props).includes(minute)) ||
        (showSecond && getDisabledSeconds(hour, minute, props).includes(second))
      ) {
        setBubble(t.invalidTime);
        return;
      }

      // 步长校验
      if (
        (showHour && hour % hourStep) ||
        (showMinute && minute % minuteStep) ||
        (showSecond && second % secondStep)
      ) {
        setBubble(t.invalidTime);
        return;
      }

      setCurValue(value);
      setBubble(null);
    }

    function handleKeyDown(event: React.KeyboardEvent) {
      switch (Keys[event.keyCode]) {
        case "enter":
          if (!bubble) {
            handleOk(event);
          }
          break;
        case "esc":
          handleClose();
          break;
      }
    }

    function handleSelectChange(value: Moment) {
      setBubble(null);
      setInputValue(getInputValue(value));
      setCurValue(value);
    }

    function handleOk(event: React.SyntheticEvent) {
      onChange(curValue, { event });
      handleClose();
    }

    function handleOpen() {
      if (disabled) {
        return;
      }
      setActive(true);
    }

    function handleClose() {
      setInputValue(getInputValue(value));
      setActive(false);
      setBubble(null);
      inputRef.current.blur();
    }

    return (
      <Popover
        trigger={[
          DatePickerTrigger,
          { onOpen: handleOpen, onClose: handleClose },
        ]}
        visible={active}
        onVisibleChange={setActive}
        placement={placement}
        placementOffset={placementOffset}
        closeOnScroll={closeOnScroll}
        overlay={
          <DropdownBox>
            <CalendarPart.Panel timeMode>
              <CalendarPart.Body>
                <TimeTable
                  {...props}
                  value={curValue}
                  onChange={handleSelectChange}
                />
              </CalendarPart.Body>
              <CalendarPart.Footer
                right={
                  <Button type="primary" onClick={handleOk}>
                    {t.okText}
                  </Button>
                }
              />
            </CalendarPart.Panel>
          </DropdownBox>
        }
      >
        <div className={classNames("tea-timepicker", className)} style={style}>
          <div className="tea-timepicker__input">
            <Input
              ref={inputRef}
              maxLength={8}
              disabled={disabled}
              placeholder={placeholder}
              value={inputValue}
              onChange={handleInputChange}
              onKeyDown={handleKeyDown}
            />
          </div>
        </div>
      </Popover>
    );
  },
  {
    defaultLabelAlign: "middle",
    RangePicker: TimeRangePicker,
  }
);
