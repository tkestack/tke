import React from "react";
import Table from "../calendar/tables/BaseTable";
import { Combobox } from "./TimeCombobox";
import { TimePickerProps } from "./TimeProps";

export function TimeTable({ caption, ...props }: TimePickerProps) {
  return (
    <Table caption={caption}>
      <Combobox {...props} />
    </Table>
  );
}
