import React from "react";
import { TimeSelect } from "./TimeSelect";
import { TimePickerProps } from "./TimeProps";
import {
  getValidTimeValue,
  genShowHourMinuteSecond,
  getHourMinuteSecond,
  getDisabledHours,
  getDisabledMinutes,
  getDisabledSeconds,
} from "./util";
import { DateChangeContext } from "../calendar/DateProps";

type SelectType = "hour" | "minute" | "second";

export function Combobox({
  value: _value,
  onChange,
  format = "HH:mm:ss",
  hourStep = 1,
  minuteStep = 1,
  secondStep = 1,
  ...props
}: Partial<TimePickerProps>) {
  const value = getValidTimeValue(_value, props, format);

  const { showHour, showMinute, showSecond } = genShowHourMinuteSecond(format);
  const { hour, minute, second } = getHourMinuteSecond(value);

  const handleItemChange = (type: SelectType) => (
    selectValue: number,
    context: DateChangeContext
  ): void => {
    const newValue = value.clone();
    switch (type) {
      case "hour":
        newValue.hour(selectValue);
        break;
      case "minute":
        newValue.minute(selectValue);
        break;
      case "second":
        newValue.second(selectValue);
        break;
    }
    onChange(getValidTimeValue(newValue, props, format), context);
  };

  return (
    <>
      {showHour && (
        <TimeSelect
          value={hour}
          to={23}
          step={hourStep}
          disabledValues={getDisabledHours(props)}
          onChange={handleItemChange("hour")}
        />
      )}
      {showMinute && (
        <TimeSelect
          value={minute}
          to={59}
          step={minuteStep}
          disabledValues={getDisabledMinutes(hour, props)}
          onChange={handleItemChange("minute")}
        />
      )}
      {showSecond && (
        <TimeSelect
          value={second}
          to={59}
          step={secondStep}
          disabledValues={getDisabledSeconds(hour, minute, props)}
          onChange={handleItemChange("second")}
        />
      )}
    </>
  );
}
