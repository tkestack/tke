import { Moment } from "moment";
import { ControlledProps } from "../form/controlled";
import { Combine } from "../_type/util";
import { RangeDateType, DateChangeContext } from "../calendar/DateProps";
import { StyledProps } from "../_type";
import { CommonDropdownProps } from "../dropdown";

export interface TimeDisabledProps {
  /**
   * 禁止选择部分小时选项
   */
  disabledHours?: () => number[];

  /**
   * 禁止选择部分分钟选项
   */
  disabledMinutes?: (selectedHour: number) => number[];

  /**
   * 禁止选择部分秒选项
   */
  disabledSeconds?: (selectedHour: number, selectedMinutes: number) => number[];
}

export interface TimePickerProps
  extends Combine<
    CommonDropdownProps,
    StyledProps,
    TimeDisabledProps,
    ControlledProps<Moment, React.SyntheticEvent, DateChangeContext>
  > {
  /**
   * 展示的时间格式
   * @default "HH:mm:ss"
   */
  format?: string;

  /**
   * 未选中日期的时候显示的文案
   * @default "时间选择"
   */
  placeholder?: string;

  /**
   * 是否禁用
   * @default false
   */
  disabled?: boolean;

  /**
   * 允许选择的时间范围限制
   */
  range?: RangeDateType;

  /**
   * 小时选项间隔
   * @default 1
   */
  hourStep?: number;

  /**
   * 秒选项间隔
   * @default 1
   */
  minuteStep?: number;

  /**
   * 分钟选项间隔
   * @default 1
   */
  secondStep?: number;

  /**
   * 标题渲染
   */
  caption?: React.ReactNode;

  /**
   * 弹出和关闭的时的回调
   */
  onOpenChange?: (open: boolean) => void;
}
