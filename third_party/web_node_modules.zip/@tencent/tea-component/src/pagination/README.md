# Pagination 分页

提供标准的分页交互方式。

## 使用示例

[Example: 分页](./_example/PaginationExample.jsx)

## 组件属性

[Interface: PaginationProps](./Pagination.tsx)

## 从 Tea v1 升级

- 交互规范变更：之前的页码选择改成了页码输入，主要是应对超多页的情况
- `state` 改为使用 `stateText`，为了跟 React 组件里的 state 概念区分开来
- `minPageSize`, `maxPageSize`, `pageSizeInterval` 移除，改为直接提供允许的页长配置 `pageSizeOptions`
