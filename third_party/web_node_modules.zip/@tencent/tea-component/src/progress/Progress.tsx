import React from "react";
import classNames from "classnames";
import { injectValue } from "../_util/inject-value";

export interface ProgressProps {
  /**
   * 进度条类型
   *
   * @default "line"
   */
  type?: "line" | "circle";

  /**
   * 百分比，取值 \[0, 100\]
   *
   * @default 0
   */
  percent?: number;

  /**
   * 描述内容
   *
   * **环形进度条中默认展示当前进度百分比**
   *
   * @docType React.ReactNode | ((percent: number) => React.ReactNode);
   */
  text?: React.ReactNode | ((percent: number) => React.ReactNode);

  /**
   * 进度条下提示内容
   *
   * 仅在 `type = "circle"` 时有效
   */
  tips?: React.ReactNode;

  /**
   * 进度条样式
   *
   * **默认将在 `percent` 小于 100 时使用 `default`，等于 100 时使用 `success`**
   */
  theme?: "default" | "success" | "danger";
}

export function Progress({
  type = "line",
  percent = 0,
  text,
  tips,
  theme = +percent === 100 ? "success" : "default",
}: ProgressProps) {
  // Circle
  if (type === "circle") {
    return (
      <div
        className={classNames("tea-progress-circle ", {
          "is-error": theme === "danger",
          "is-success": theme === "success",
        })}
      >
        <div className="tea-progress-circle__area">
          <div className="tea-progress-circle__svg-path">
            <svg
              version="1.1"
              id="图层_1"
              xmlns="http://www.w3.org/2000/svg"
              xmlnsXlink="http://www.w3.org/1999/xlink"
              x="0px"
              y="0px"
              width="160px"
              height="160px"
              viewBox="0 0 160 160"
              xmlSpace="preserve"
            >
              <circle
                className="tea-progress-circle__base-ring"
                fill="none"
                strokeWidth="2"
                cx="80"
                cy="80"
                r="69"
              />
              <circle
                className="tea-progress-circle__current-ring"
                fill="none"
                strokeWidth="2"
                cx="80"
                cy="80"
                r="69"
                style={{
                  strokeDasharray: `${(434 * percent) / 100}px 434px`,
                  transition: "stroke-dasharray .2s",
                }}
              />
            </svg>
          </div>
          <div className="tea-progress-circle__current-text" id="progress-num">
            {text ? (
              <span className="text--chinese">
                {injectValue(text)(percent)}
              </span>
            ) : (
              <>
                {percent}
                <i className="text--symbol">%</i>
              </>
            )}
          </div>
        </div>
        <div className="tea-progress-circle__tips">{tips}</div>
      </div>
    );
  }

  return (
    <div
      className={classNames("tea-progress", {
        "tea-progress--error": theme === "danger",
        "tea-progress--succeed": theme === "success",
      })}
    >
      <div
        className="tea-progress__value"
        style={{ width: `${percent}%`, transition: "width .2s" }}
      >
        {text && (
          <span className="tea-progress__text">
            {injectValue(text)(percent)}
          </span>
        )}
      </div>
    </div>
  );
}
