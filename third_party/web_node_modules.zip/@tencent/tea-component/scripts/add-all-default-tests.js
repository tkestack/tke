const fs = require("fs");
const path = require("path");

const src = path.resolve(__dirname, "../src");

const defaultTextContent = `/* eslint-disable @typescript-eslint/no-unused-vars */
import React from "react";
import { testExamples } from "@test/utils";

// 测试组件代码 Example 快照
testExamples(__dirname);

test("TODO", () => {
  // add test here
});
`;

for (const componentName of fs.readdirSync(src)) {
  if (/^_/.test(componentName)) {
    continue; // eslint-disable-line
  }
  const componentPath = path.join(src, componentName);
  if (!fs.statSync(componentPath).isDirectory()) {
    continue; // eslint-disable-line
  }

  const testDir = path.join(componentPath, "__tests__");
  if (!fs.existsSync(testDir)) {
    fs.mkdirSync(testDir);
  }

  const testFilePath = path.join(testDir, `${componentName}.test.tsx`);
  fs.writeFileSync(testFilePath, defaultTextContent, "utf8");
}
