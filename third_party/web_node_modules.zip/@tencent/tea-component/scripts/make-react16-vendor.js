// / <reference types="node" />

const path = require("path");
const fs = require("fs");
const cdn = require("@tencent/cdn-deploy");

const banner = `
/**
 * 本文件导出 React 和 ReactDOM 到全局变量中
 *
 * 为了不与老版本冲突，全局变量命名改为 React16 和 ReactDOM16
 */
`.trim();

const bundleDevelopment = [
  {
    file: "react/umd/react.development.js",
    modification: [/global\.React/, "global.React16"],
  },
  {
    file: "react-dom/umd/react-dom.development.js",
    modification: [
      /global\.ReactDOM = factory\(global\.React\)/,
      "global.ReactDOM16 = factory(global.React16)",
    ],
  },
];

const bundleProduction = [
  {
    file: "react/umd/react.production.min.js",
    modification: [/(\w+)\.React=(\w+\(\))/, "$1.React16=$2"],
  },
  {
    file: "react-dom/umd/react-dom.production.min.js",
    modification: [
      /(\w+)\.ReactDOM=(\w+)\(\1\.React\)/,
      "$1.ReactDOM16 = $2($1.React16)",
    ],
  },
];

const NODE_MODULE_PATH = path.resolve(__dirname, "../node_modules");
const OUTPUT_PATH = path.resolve(__dirname, "../vendors/react");

if (!fs.existsSync(OUTPUT_PATH)) {
  fs.mkdirSync(OUTPUT_PATH, { recursive: true });
}

/**
 *
 * @param {string} bundleName
 * @param {typeof bundleProduction} bundle
 */
const makeBundle = (bundleName, bundle) => {
  const bundleContents = [];

  bundleContents.push(banner);
  // eslint-disable-next-line
  const { version } = require(path.resolve(
    NODE_MODULE_PATH,
    "react/package.json"
  ));

  for (const { file, modification } of bundle) {
    const filePath = path.resolve(NODE_MODULE_PATH, file);
    const fileContent = fs.readFileSync(filePath, "utf8");
    const [found, replacement] = modification;

    const modifiedContent = fileContent.replace(found, replacement);
    bundleContents.push(modifiedContent);
  }

  const bundlePath = path.resolve(OUTPUT_PATH, bundleName(version));
  fs.writeFileSync(bundlePath, bundleContents.join("\n"), { encoding: "utf8" });
};

makeBundle(version => `react-${version}.development.js`, bundleDevelopment);
makeBundle(version => `react-${version}.production.js`, bundleProduction);

cdn.deploy({
  project: "qcloud-vendors",
  cdnRoot: "http://imgcache.qq.com/qcloud/vendors",
  distDir: path.resolve(__dirname, "../vendors"),
  skipHashCheckAndIUnderstandHowDangerousItIs: true,
});
