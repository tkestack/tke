// @ts-check
/* eslint-env node */
const path = require("path");
const fs = require("fs");
const webpack = require("webpack");
const WebpackBar = require("webpackbar");
const rimraf = require("rimraf");

const srcRoot = path.resolve(__dirname, "../src");
const releasePath = path.resolve(__dirname, "../release");

const name = "tea-component";

const babelOptions = {
  // 业界通用 preset
  presets: [require("@babel/preset-env"), require("@babel/preset-react")], // eslint-disable-line global-require
  // 缓存 loader 结果，可提高编译性能
  cacheDirectory: true,
  // 维持行号，否则 Webpack 异常消息中的行号不正确
  retainLines: true,
};

const externals = {
  react: "window.React",
  "react-dom": "window.ReactDOM",
  moment: "moment",
};

// 清理上次构建内容
if (fs.existsSync(releasePath)) {
  rimraf.sync(releasePath);
}
fs.mkdirSync(releasePath);

const compiler = webpack({
  name,
  mode: "production",
  entry: {
    [name]: path.resolve(srcRoot, "expose.ts"),
  },
  output: {
    path: releasePath,
    filename: "[name].[chunkhash:10].js",
    publicPath: "https://imgcache.qq.com/qcloud/tea/component/",
  },
  module: {
    rules: [
      {
        test: /\.tsx?/,
        use: [
          {
            loader: "babel-loader",
            options: babelOptions,
          },
          {
            loader: "ts-loader",
            options: {
              transpileOnly: true,
            },
          },
        ],
        exclude: /node_modules/,
      },
      {
        test: /\.jsx?/,
        use: [
          {
            loader: "babel-loader",
            options: babelOptions,
          },
        ],
        exclude: /node_modules/,
      },
    ],
  },
  resolve: {
    extensions: [".js", ".jsx", ".ts", ".tsx"],
    alias: {
      "@tea/component": srcRoot,
    },
  },
  externals,
  devtool: "source-map",
  plugins: [
    new webpack.NoEmitOnErrorsPlugin(),
    new webpack.DefinePlugin({
      "process.env.NODE_ENV": '"production"',
    }),
    new WebpackBar({
      name,
    }),
  ],
});

compiler.run((error, stats) => {
  if (error) {
    return process.exit(-1);
  }
  const statsJson = stats.toJson();
  fs.writeFileSync(
    path.join(releasePath, "stats.json"),
    JSON.stringify(statsJson, null, 2)
  );
  if (statsJson.errors && statsJson.errors.length) {
    statsJson.errors.forEach(err => console.error(`\n${err}`));
    return process.exit(-1);
  }
  return null;
});
