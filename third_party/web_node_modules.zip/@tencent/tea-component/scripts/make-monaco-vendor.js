const path = require("path");
const fs = require("fs-extra");
const cdn = require("@tencent/cdn-deploy");
// @ts-ignore
const { version } = require("monaco-editor/package.json");

const monacoHome = path.resolve(__dirname, "../node_modules/monaco-editor");
const monacoDist = path.resolve(__dirname, "../vendors/monaco-editor", version);

fs.copy(monacoHome, monacoDist, { recursive: true });
// fs.mkdirSync(monacoDist, { recursive: true });

const releaseDirs = ["min-maps", "min", "dev"];

cdn.deploy({
  project: "qcloud-vendors",
  cdnRoot: "http://imgcache.qq.com/qcloud/vendors",
  distDir: path.resolve(__dirname, "../vendors"),
  skipHashCheckAndIUnderstandHowDangerousItIs: true,
  filter: filename => {
    if (!/monaco-editor/.test(filename)) {
      return false;
    }
    // "monaco-editor/0.16.2/min-maps/vs/loader.js.map"
    // -> ["monaco-editor", "/min-maps/vs/loader.js.map"]
    const [_, monacoContent] = filename.split(version);
    if (!monacoContent) {
      return false;
    }
    if (!releaseDirs.includes(monacoContent.split(path.sep)[1])) {
      return false;
    }

    return true;
  },
});
