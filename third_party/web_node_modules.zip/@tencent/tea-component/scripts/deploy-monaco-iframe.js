const path = require("path");
const fs = require("fs-extra");
const cdn = require("@tencent/cdn-deploy");

const frameSource = path.resolve(__dirname, "../src/codeeditor/frame");
const monacoDist = path.resolve(__dirname, "../vendors/monaco-editor/frame");

if (fs.existsSync(monacoDist)) {
  fs.emptyDirSync(monacoDist);
}
fs.copySync(frameSource, monacoDist, { recursive: true });

cdn.deploy({
  project: "qcloud-vendors",
  cdnRoot: "http://imgcache.qq.com/qcloud/vendors",
  distDir: path.resolve(__dirname, "../vendors"),
  skipHashCheckAndIUnderstandHowDangerousItIs: true,
  filter: filename => {
    if (!/monaco-editor[\\/]frame/.test(filename)) {
      return false;
    }
    return true;
  },
});
