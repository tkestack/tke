const path = require("path");
const { deploy } = require("@tencent/cdn-deploy");

deploy({
  project: "qcloud-tea-component",
  distDir: path.resolve(__dirname, "../release"),
  filter: filename => /tea-component\..+\.js/.test(filename),
  yes: true,
  skipHashCheckAndIUnderstandHowDangerousItIs: true,
  cdnRoot: "http://imgcache.qq.com/qcloud/tea/component",
});
