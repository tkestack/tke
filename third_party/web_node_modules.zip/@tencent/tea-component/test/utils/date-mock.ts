import * as dateMock from "jest-date-mock";

export { dateMock };
