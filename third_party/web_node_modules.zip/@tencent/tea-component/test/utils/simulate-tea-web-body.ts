/**
 * 模拟 tea.tencent.com 上的 tea-web-body
 */
export function simulateTeaWebBody() {
  let simuateWebBody: HTMLDivElement;
  beforeEach(() => {
    simuateWebBody = document.createElement("div");
    simuateWebBody.className = "tea-web-body";
    document.body.appendChild(simuateWebBody);
  });
  afterEach(() => {
    simuateWebBody.remove();
    simuateWebBody = null;
  });

  return { simuateWebBody };
}
