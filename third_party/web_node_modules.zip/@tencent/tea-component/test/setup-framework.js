// setup file
import "babel-polyfill";

jest.useFakeTimers();
