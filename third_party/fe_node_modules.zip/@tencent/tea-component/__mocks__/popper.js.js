// NOTE: 解决 popper.js 不支持 jsdom 问题
import PopperJs from "popper.js";

export default class Popper {
  static placements = PopperJs.placements;

  constructor() {
    return {
      destroy: () => {},
      scheduleUpdate: () => {},
    };
  }
}
