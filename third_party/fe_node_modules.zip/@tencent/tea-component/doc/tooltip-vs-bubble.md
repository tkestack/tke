Tooltip 和 Bubble 有什么区别？
===========================

```
TODO
```

## 参考资料

- https://docs.qq.com/doc/DTFdubkdDZmNBcHhk