import Debug from "debug";

export const testDebug = Debug("test");
