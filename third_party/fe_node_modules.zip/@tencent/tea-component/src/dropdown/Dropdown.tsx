import React, { useLayoutEffect, useMemo, useCallback } from "react";
import classNames from "classnames";
import { Icon } from "../icon";
import { StyledProps, Combine } from "../_type";
import { Popover, PopoverProps, TriggerProps } from "../popover";
import { createRocket } from "../_util/create-rocket";
import { SizeType } from "../input";
import { useOutsideClick } from "../_util/use-outside-click";
import { forwardRefWithStatics } from "../_util/forward-ref-with-statics";
import { useDefault } from "../_util/use-default";

/**
 * 下拉类组件通用 Props
 */
export interface CommonDropdownProps {
  /**
   * 是否默认展开
   */
  defaultOpen?: boolean;

  /**
   * 是否展开（受控）
   */
  open?: boolean;

  /**
   * 展开变化回调（受控）
   */
  onOpenChange?: (open: boolean) => void;

  /**
   * 下拉出现的位置
   * @default "bottom-start"（从底部弹出，左侧对齐）
   */
  placement?: PopoverProps["placement"];

  /**
   * 弹出位置偏离参考位置的位移
   * @default 5
   */
  placementOffset?: PopoverProps["placementOffset"];

  /**
   * 是否在父容器滚动时关闭
   * @default true
   */
  closeOnScroll?: PopoverProps["closeOnScroll"];
}

export interface DropdownProps
  extends Combine<CommonDropdownProps, StyledProps> {
  /**
   * 下拉按钮文本
   */
  button: React.ReactNode;

  /**
   * 下拉内容
   * @docType React.ReactNode | ((close: () => void) => React.ReactNode)
   */
  children: React.ReactNode | ((close: () => void) => React.ReactNode);

  /**
   * 下拉按钮的外观：
   *
   * - `default` 无边框，适用于页面标题和表格内
   * - `button` 为按钮风格，有边框，多用于操作栏中
   * - `link` 为超链接风格
   * - `filter` 为过滤组件风格，多用于表头筛选
   * - `pure` 无额外样式
   *
   * 原有 `raw` 类型建议使用 `pure` 进行改造
   *
   * @default "default"
   */
  appearence?: "default" | "button" | "link" | "filter" | "pure";

  /**
   * 下拉框尺寸，使用 `"full"` 撑满容器宽度
   */
  size?: SizeType | "auto";

  /**
   * 触发方式
   *
   * @default "click"
   */
  trigger?: "click" | "hover";

  /**
   * 是否在下拉内容点击时关闭
   * @default true
   */
  clickClose?: boolean;

  /**
   * 是否禁用
   * @default false
   */
  disabled?: boolean;

  /**
   * 打开时回调
   */
  onOpen?: () => void;

  /**
   * 关闭时回调
   */
  onClose?: () => void;

  /**
   * 弹出区域自定义类名
   */
  boxClassName?: string;

  /**
   * 弹出区域自定义样式
   */
  boxStyle?: React.CSSProperties;

  /**
   * 是否在 `children` 变化时更新位置
   *
   * @default false
   */
  updateOnChildrenChange?: boolean;
}

const appearenceConfig = {
  // appearence  headerClassName         icon
  default: ["tea-dropdown-default", "arrowdown"],
  button: ["tea-dropdown-btn", "arrowdown"],
  link: ["tea-dropdown-link", "arrowdown"],
  filter: ["tea-dropdown-filter", "filter"],
  // 兼容原有 raw 类型
  raw: [null, null],
};

const noop = () => {};

export function DropdownBox({
  className,
  style = {},
  children,
  onClick,
  onUpdate = noop,
}: {
  onClick?: (event: React.MouseEvent) => void;
  children?: React.ReactNode;
  onUpdate?: () => void;
} & StyledProps) {
  useLayoutEffect(
    () => () => {
      onUpdate();
    },
    [children, onUpdate]
  );

  if (!children) {
    return null;
  }

  return (
    <div
      className={classNames("tea-dropdown-box", className)}
      style={{ position: "relative", ...style }}
      onClick={onClick}
    >
      {children}
    </div>
  );
}

const ClickTrigger = ({
  childrenElementRef,
  overlayElementRef,
  visible,
  setVisible,
  openDelay = 0,
  closeDelay = 0,
  render,
  onClose,
  onOpen,
}: TriggerProps & DropdownProps) => {
  const { listen } = useOutsideClick([childrenElementRef, overlayElementRef]);

  listen(() => {
    if (visible) {
      onClose();
    }
    setVisible(false, closeDelay);
  });

  return render({
    overlayProps: {},
    childrenProps: {
      onClick: (event: React.MouseEvent) => {
        event.stopPropagation();
        if (!visible) {
          onOpen();
        } else {
          onClose();
        }
        setVisible(!visible, !visible ? openDelay : closeDelay);
      },
    },
  });
};

const HoverTrigger = ({
  visible,
  setVisible,
  openDelay = 50,
  closeDelay = 100,
  render,
  onClose,
  onOpen,
}: TriggerProps & DropdownProps) => {
  const commonProps = {
    onMouseEnter: () => {
      setVisible(true, openDelay).then(done => done && !visible && onOpen());
    },
    onMouseLeave: () => {
      setVisible(false, closeDelay).then(done => done && onClose());
    },
  };
  return render({
    overlayProps: commonProps,
    childrenProps: commonProps,
  });
};

export const Dropdown = forwardRefWithStatics(
  (props: DropdownProps, ref: React.Ref<HTMLDivElement>) => {
    const {
      defaultOpen = false,
      open,
      onOpenChange,
      appearence,
      button,
      size,
      placement = "bottom-start",
      placementOffset = 5,
      trigger,
      children,
      disabled,
      onOpen = noop,
      onClose = noop,
      clickClose = true,
      closeOnScroll = true,
      style,
      className,
      boxStyle,
      boxClassName,
      updateOnChildrenChange,
    } = props;

    const [isOpened, setIsOpened] = useDefault(open, defaultOpen, onOpenChange);

    const close = useCallback(() => {
      setIsOpened(false);
      onClose();
    }, [onClose, setIsOpened]);

    const [headerClassName, icon] =
      appearenceConfig[appearence] || appearenceConfig.default;

    const boxChildren = useMemo(() => {
      return typeof children === "function"
        ? children.call(null, close)
        : children;
    }, [children, close]);

    const Trigger = trigger === "hover" ? HoverTrigger : ClickTrigger;
    return (
      <Popover
        trigger={
          disabled
            ? "empty"
            : [
                Trigger,
                {
                  onClose,
                  onOpen,
                },
              ]
        }
        visible={isOpened}
        onVisibleChange={setIsOpened}
        placement={placement}
        placementOffset={placementOffset}
        closeOnScroll={closeOnScroll}
        overlay={({ scheduleUpdate }) => (
          <DropdownBox
            className={boxClassName}
            style={boxStyle}
            onClick={clickClose ? close : null}
            onUpdate={updateOnChildrenChange ? scheduleUpdate : undefined}
          >
            {boxChildren}
          </DropdownBox>
        )}
      >
        <div
          ref={ref}
          className={classNames("tea-dropdown", className, {
            [`size-${
              size === "full" || size === "auto" ? `${size}-width` : size
            }`]: size,
            "is-expanded": isOpened,
            "is-disabled": disabled,
          })}
          style={style}
        >
          {appearence === "pure" ? (
            button
          ) : (
            <div
              className={classNames("tea-dropdown__header", headerClassName)}
            >
              <div className="tea-dropdown__value">{button}</div>
              {icon && <Icon type={icon} />}
            </div>
          )}
        </div>
      </Popover>
    );
  },
  {
    Footer: createRocket("DropdownFooter", "div.tea-dropdown-box__footer"),
  }
);
