import React, { useRef, useEffect } from "react";
import { EmptyTip } from "../tips/EmptyTip";
import Chart from "../_chart";
import { RectProps } from "../_chart/type";
import { Line } from "../_chart/core/shape";
import { useResize } from "../_util/use-resize";

export interface BasicLineProps extends RectProps {
  /**
   * 状态提示，可使用 StatusTip 相关组件
   */
  tips?: React.ReactNode;
  /**
   * Tips 遮罩层样式
   */
  tipsStyle?: React.CSSProperties;
}

export function BasicLine(props: BasicLineProps) {
  const {
    height,
    width,
    tips,
    dataSource,
    position,
    size = 3,
    scale,
    tooltip = true,
    color,
    legend = !!color,
    xAxis = true,
    yAxis = true,
    tipsStyle = {},
  } = props;
  const container = useRef(null);
  const chartRef = useRef<Chart>();
  const lineRef = useRef<Line>();

  useEffect(() => {
    chartRef.current = new Chart(container.current);
    lineRef.current = chartRef.current.line();

    return () => {
      chartRef.current.destroy();
    };
  }, []);

  useEffect(() => {
    const xAxes = typeof xAxis === "boolean" ? { enable: xAxis } : xAxis;
    const yAxes = typeof yAxis === "boolean" ? { enable: yAxis } : yAxis;

    chartRef.current
      .source(dataSource)
      .scale(scale)
      .tooltip(tooltip)
      .legend(legend);
    lineRef.current
      .position(position)
      .color(color)
      .size(size)
      .axis({ xAxes, yAxes });
    chartRef.current.render();
  }, [color, dataSource, legend, position, scale, size, tooltip, xAxis, yAxis]);

  useResize(() => {
    chartRef.current.resize();
  });

  const showStatus =
    tips || !Array.isArray(dataSource) || dataSource.length === 0;

  return (
    <div style={{ height, width, position: "relative" }}>
      {showStatus && (
        <div
          className="tea-chart-status"
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            textAlign: "center",
            lineHeight: `${height}px`,
            background: "#F2F2F2",
            zIndex: 999,
            ...tipsStyle,
          }}
        >
          {tips || <EmptyTip />}
        </div>
      )}

      <div
        style={{ height: "100%", width: "100%", position: "relative" }}
        ref={container}
      />
    </div>
  );
}
