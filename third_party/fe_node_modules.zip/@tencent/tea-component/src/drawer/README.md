# Drawer 抽屉

页面左侧或右侧弹出的抽屉面板。

## 基本用法

[Example: Drawer](./_example/DrawerExample.jsx)

## 组件属性

为适配控制台，抽屉样式中 top 默认为 50px，其他情况可通过修改 `style` 自行调整。

[Interface: DrawerProps](./Drawer.tsx)
