import React, { forwardRef } from "react";
import classNames from "classnames";
import { Icon } from "../icon";
import { callBoth } from "../_util/call-both";

export interface TabItemProps {
  label: React.ReactNode;
  actived: boolean;
  disabled: boolean;
  onClose: (evt: React.MouseEvent) => void;
  onClick: (evt: React.MouseEvent) => void;
  render: (children: JSX.Element) => JSX.Element;
}

export const TabItem = forwardRef(
  (
    { label, onClick, actived, disabled, onClose, render }: TabItemProps,
    ref: React.Ref<HTMLLIElement>
  ) => {
    const children = render(<>{label}</>);
    const handleClick = disabled ? null : onClick;
    return (
      <li className="tea-tabs__tabitem" ref={ref}>
        {React.cloneElement(children, {
          className: classNames(children.props.className, "tea-tabs__tab", {
            "is-active": actived,
            "is-disabled": disabled,
          }),
          onClick: callBoth(handleClick, children.props.onClick),
        })}
        {onClose && (
          <a className="tea-tabs__remove" onClick={onClose}>
            <Icon type="dismiss" />
          </a>
        )}
      </li>
    );
  }
);
