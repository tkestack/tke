import React from "react";
import classNames from "classnames";
import { StyledProps } from "../_type";
import { SlideTransition, FadeTransition } from "../transition";

export interface FormControlProps extends StyledProps {
  /**
   * 表单组件
   */
  children?: React.ReactNode;

  /**
   * 字段状态
   */
  status?: "success" | "error" | "validating";

  /**
   * 是否展示 icon
   * @default true
   */
  showStatusIcon?: boolean;

  /**
   * 表单说明消息/错误消息
   */
  message?: React.ReactNode;

  /**
   * 是否增加顶部间距，以对齐标签文本
   * @default false
   */
  alignLabelTop?: boolean;

  /**
   * 是否为必填字段
   * @default false
   */
  required?: boolean;
}

export function FormControl({
  status,
  children,
  message,
  className,
  style,
  alignLabelTop,
  showStatusIcon = true,
}: FormControlProps) {
  const controlClassName = classNames(
    "tea-form__controls",
    {
      [`tea-form__controls--text`]: alignLabelTop,
      [`is-${status}`]: status,
    },
    className
  );
  return (
    <div className={controlClassName} style={style}>
      {children}
      <SlideTransition in={Boolean(status)} from={[-10, 0]}>
        {showStatusIcon ? <b className="tea-icon tea-icon-valid" /> : <b />}
      </SlideTransition>
      {/* <FadeTransition in={Boolean(message)}> */}
      {Boolean(message) && <div className="tea-form__help-text">{message}</div>}
      {/* </FadeTransition> */}
    </div>
  );
}
