import React from "react";
import classNames from "classnames";
import { StyledProps } from "../_type";
import { FormItem } from "./FormItem";
import { FormControl } from "./FormControl";
import { createRocket } from "../_util/create-rocket";
import { FormContext } from "./FormContext";

export interface FormProps extends StyledProps {
  /**
   * 表单布局方式
   *
   * - `default` 默认布局
   * - `fixed` 固定标签栏宽度，可用于对齐多个表单
   * - `vertical` 标签和控件垂直排列
   * - `inline` 表单内容行内流水排列
   * - `inline-vertical` 表单内容行内流水排列，且标签和控件垂直排列
   * @default "default"
   */
  layout?: "default" | "fixed" | "vertical" | "inline" | "inline-vertical";

  /**
   * 是否为纯展示表单（样式更加紧凑）
   *
   * @default false
   */
  readonly?: boolean;

  /**
   * 不展示表单 Label 部分
   *
   * @default false
   */
  hideLabel?: boolean;

  /**
   * 表单内容
   */
  children?: React.ReactNode;
}

export function Form({
  style,
  className,
  children,
  layout,
  readonly,
  hideLabel,
}: FormProps) {
  // readonly 只和 fixed 共存
  const formClassName = classNames(
    "tea-form",
    {
      "tea-form--fixed-layout": layout === "fixed",
      "tea-form--vertical":
        !readonly && (layout === "vertical" || layout === "inline-vertical"),
      "tea-form--inline":
        !readonly && (layout === "inline" || layout === "inline-vertical"),
      "tea-form--readonly": readonly,
    },
    className
  );
  return (
    <div className={formClassName} style={style}>
      <FormContext.Provider value={{ hideLabel }}>
        {children}
      </FormContext.Provider>
    </div>
  );
}

export const FormTitle = createRocket("Form.Title", "h3.tea-form-title");
export const FormAction = createRocket("Form.Action", "div.tea-form-operate");
export const FormText = createRocket("Form.Text", "div.tea-form__text");

Form.Item = FormItem;
Form.Title = FormTitle;
Form.Action = FormAction;
Form.Control = FormControl;
Form.Text = FormText;
