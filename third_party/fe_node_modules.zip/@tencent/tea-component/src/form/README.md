# Form 表单

Tea 表单目前仅提供表单展示层组件，不提供状态管理。可参考示例结合开源方案来进行表单状态管理。

- `Form` 和 `Form.Item` 组件支持表单布局，以及字段状态展示
- `Form.Control` 也可以独立用于字段状态展示

## 使用示例

### 表单布局

[Example: FormLayout](./_example/FormLayoutExample.jsx)

### 表单验证

[Example: FormValidation](./_example/FormValidationExample.jsx)

### 只读表单

[Example: FormReadOnly](./_example/FormReadOnlyExample.jsx)

## 表单状态管理

Tea 组件本身没有提供表单状态管理能力，可结合一些现有社区实现使用。

### React Final Form

High performance subscription-based form state management for React.

https://github.com/final-form/react-final-form

```
npm install --save react-final-form final-form
```

[Example: FormWithReactFinalForm](./_example/FormWithReactFinalFormExample.jsx)

### React Final Form Hooks

Final Form 的 Hooks 版本，可以在不改变组件原有结构的情况下完成状态管理。

https://github.com/final-form/react-final-form-hooks

```
npm install --save react-final-form-hooks final-form
```

[Example: FormWithReactFinalFormHooks](./_example/FormWithReactFinalFormHooksExample.jsx)

提示：当前 `2.0.0` 版本 API 在 Field 粒度的控制较为不便（如想单独控制某个字段使用异步校验），以及部分类型定义缺失。

## 组件属性

[Interface: FormProps](./Form.tsx)

[Interface: FormItemProps](./FormItem.tsx)

[Interface: FormControlProps](./FormControl.tsx)
