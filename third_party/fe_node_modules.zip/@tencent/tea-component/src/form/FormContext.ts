import { createContext } from "react";

interface FormContextValue {
  hideLabel?: boolean;
}

export const FormContext = createContext<FormContextValue>({});
