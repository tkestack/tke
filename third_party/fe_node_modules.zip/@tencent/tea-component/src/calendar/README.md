# Calendar 日历

日历形式的展示组件。

## 依赖安装

日期相关组件实现依赖了 [moment](http://momentjs.com/)，使用时需自行安装：

```
npm install moment
```

如果你的 webpack 配置中忽略了 moment 的语言包（如 `create-react-app` 创建的应用），请手动引入需要的语言包，如：

```js
import "moment/locale/zh-cn";
```

## 使用示例

### 基本用法

[Example: Calendar](./_example/CalendarExample.jsx)

### range 控制可选范围

[Example: CalendarRange](./_example/CalendarRangeExample.jsx)

### disabledDate 控制可选范围

[Example: CalendarDisabled](./_example/CalendarDisabledExample.jsx)

## 组件属性

[Interface: CalendarProps](./Calendar.tsx)
