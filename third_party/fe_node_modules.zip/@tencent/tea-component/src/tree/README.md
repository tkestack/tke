# Tree 树形控件

用于有层级关系数据的展示，包含展开/收起、选择等功能。

## 使用示例

### 基本用法

[Example: Tree](./_example/TreeExample.jsx)

### 包含图标

[Example: TreeIcon](./_example/TreeIconExample.jsx)

### 异步加载

[Example: TreeDynamic](./_example/TreeDynamicExample.jsx)

### 包含操作

[Example: TreeOperation](./_example/TreeOperationExample.jsx)

## 组件属性

[Interface: TreeProps](./Tree.tsx)

[Interface: TreeNodeProps](./TreeNode.tsx)
