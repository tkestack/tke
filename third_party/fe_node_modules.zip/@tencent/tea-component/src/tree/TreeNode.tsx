import React, { useState } from "react";
import classNames from "classnames";
import { TreeContext, TreeContextValue } from "./TreeContext";
import { Check } from "../check";
import { Icon } from "../icon";
import { StyledProps } from "../_type";
import { withStatics } from "../_util/with-statics";
import { injectValue } from "../_util/inject-value";

export interface TreeNodeProps extends StyledProps {
  /**
   * 节点 ID，整棵树中唯一
   */
  id: string;

  /**
   * 节点内容
   */
  content: React.ReactNode;

  /**
   * 节点图标
   *
   * @docType React.ReactNode | (context: { expanded: boolean }) => React.ReactNode
   */
  icon?:
    | ((context: { expanded: boolean }) => React.ReactNode)
    | React.ReactNode;

  /**
   * hover 后展示的操作
   *
   * 推荐使用文字（TreeNode.ActionLink），若超过一项，建议收至 Dropdown 下
   */
  operation?: React.ReactNode;

  /**
   * 当树为 selectable 时，设置当前节点是否展示 Checkbox
   *
   * @default true
   */
  selectable?: boolean;

  /**
   * 当树为 selectable 时，设置当前节点 Checkbox 是否禁用
   *
   * @default false
   */
  disableSelect?: boolean;

  /**
   * 当前节点是否支持展开（用于异步加载）
   *
   * @default false
   */
  expandable?: boolean;

  /**
   * 包含的树节点 <TreeNode />
   */
  children?: React.ReactNode;
}

export const TreeNode = withStatics(
  function TreeNode(props: TreeNodeProps) {
    return (
      <TreeContext.Consumer>
        {context => {
          return <TreeNodeInner {...context} {...props} />;
        }}
      </TreeContext.Consumer>
    );
  },
  {
    ActionLink,
  }
);

export function TreeNodeInner({
  id,
  content,
  icon,
  operation,
  selectable,
  activable,
  activeIds,
  onActive,
  expandable,
  children,
  expandedIds,
  onExpand,
  onLoad,
  onLoadError,
  switcherIcon,
  className,
  style,
}: TreeNodeProps & TreeContextValue) {
  const expanded = expandedIds.includes(id);
  const nodeIcon = injectValue(icon)({ expanded });

  return (
    <li
      className={classNames("tea-tree__node", className, {
        // 高亮
        "is-selected": activable && activeIds.includes(id),
      })}
      style={style}
    >
      <div
        className="tea-tree__node-content"
        style={activable ? { cursor: "pointer" } : undefined}
        onClick={() => activable && onActive(id)}
      >
        <TreeNodeSwitcher
          id={id}
          icon={switcherIcon}
          enable={Boolean(expandable || children)}
          expanded={expanded}
          onExpand={onExpand}
          onLoad={onLoad}
          onLoadError={onLoadError}
        />

        <div className="tea-tree__label">
          {selectable ? (
            <Check name={id} type="checkbox">
              {nodeIcon}
              {content}
            </Check>
          ) : (
            <>
              {nodeIcon}
              <span className="tea-tree__label-title">{content}</span>
            </>
          )}
        </div>
        {operation && <div className="tea-tree__action">{operation}</div>}
      </div>
      {expanded && <ul className="tea-tree__subtree">{children}</ul>}
    </li>
  );
}

interface TreeNodeSwitcherProps {
  id: TreeNodeProps["id"];
  icon: TreeContextValue["switcherIcon"];
  enable: boolean;
  expanded: boolean;
  onExpand: TreeContextValue["onExpand"];
  onLoad: TreeContextValue["onLoad"];
  onLoadError: TreeContextValue["onLoadError"];
}

function TreeNodeSwitcher({
  id,
  enable,
  expanded,
  onExpand,
  onLoad,
  onLoadError = () => null,
  icon = ({ expanded }) => (
    <Icon type={expanded ? "arrowdown" : "arrowright"} />
  ),
}: TreeNodeSwitcherProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);
  const switcherIcon = injectValue(icon)({ expanded });

  async function handleExpand(event: React.MouseEvent) {
    event.stopPropagation();
    if (expanded) {
      onExpand(id, false);
      return;
    }

    if (onLoad) {
      setError(false);
      setLoading(true);
      try {
        await onLoad(id);
        onExpand(id, true);
      } catch (err) {
        setError(true);
        onLoadError(id, err);
      } finally {
        setLoading(false);
      }
    } else {
      onExpand(id, true);
    }
  }

  let switcher = React.isValidElement<any>(switcherIcon) ? (
    React.cloneElement(switcherIcon, {
      onClick: handleExpand,
    })
  ) : (
    <div onClick={handleExpand}>{switcherIcon}</div>
  );

  if (loading) {
    switcher = <Icon type="loading" />;
  }

  if (error) {
    switcher = <Icon type="error" onClick={handleExpand} />;
  }

  return <a className="tea-tree__switcher">{enable && switcher}</a>;
}

function ActionLink({
  children,
  className,
  ...props
}: React.AnchorHTMLAttributes<HTMLAnchorElement>) {
  return (
    <a className={classNames("tea-text--link", className)} {...props}>
      {children}
    </a>
  );
}
