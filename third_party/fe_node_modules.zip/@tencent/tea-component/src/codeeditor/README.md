# CodeEditor 代码输入

基于微软 [MonacoEditor](https://microsoft.github.io/monaco-editor/index.html) 封装的代码编辑器。

## 使用示例

CodeEditor 不是受控组件，需要你使用 API 来获取/修改内容。

[Example: CodeEditorExample](./_example/CodeEditorExample.jsx)

## 组件属性

[Interface: CodeEditorProps](./CodeEditor.tsx)
