# Tooltip 文本解释

为指定内容显示文本说明，用于替代 DOM 的 `title` 属性。如果需要显示复杂内容，请考虑使用 `Bubble` 组件。

## 使用示例

### 基本用法

[Example: TooltipExample](./_example/TooltipExample.jsx)

### 组件中使用

`Text`、`Button`、`Icon`、`Checkbox`、`Radio`、`Switch` 组件提供了快捷的 `tooltip` 属性以添加 tooltip：

[Example: TooltipSugarExample](./_example/TooltipSugarExample.jsx)

## 触发机制

Tooltip 跟普通的 Bubble 不一样：

- 出现位置不参考元素，参考鼠标；

- 如果场上无 Tooltip 实例，则激活后 0.6s 后弹出；

- 如果场上有 Tooltip 实例，则激活后 0.3s 后弹出；

设计上面的规则，是为了对齐系统 `title` 的交互。

## 组件属性

[Interface: TooltipProps](./Tooltip.tsx)
