import React, { useState, Fragment, useRef, useEffect } from "react";
import { Popover, TriggerProps, PopoverProps } from "../popover";
import { DropdownBox } from "../dropdown";
import { StyledProps, Combine } from "../_type";
import { SelectOptionWithGroup } from "../select";
import { List } from "../list";
import { ControlledProps, useDefaultValue } from "../form";
import { Text } from "../text";
import { EmptyTip } from "../tips";

export interface AutoCompleteProps
  extends Combine<StyledProps, ControlledProps<string>> {
  /**
   * 下拉选项列表
   */
  options?: SelectOptionWithGroup[];

  /**
   * 分组
   */
  groups?: {
    [groupKey: string]: React.ReactNode;
  };

  /**
   * `options` 为空时展示，可使用字符串或 [StatusTip](/component/tips) 相关组件
   */
  tips?: React.ReactNode;

  /**
   * 展示为高亮的关键词
   */
  keyword?: string;

  /**
   * 要包裹的输入组件
   */
  children?: (
    ref: React.Ref<HTMLInputElement | HTMLTextAreaElement>,
    context: { close: () => void }
  ) => React.ReactNode;

  /**
   * `options` 滚动至底部的回调
   */
  onScrollBottom?: (event: React.UIEvent) => void;

  /**
   * 是否在父容器滚动时关闭
   * @default true
   */
  closeOnScroll?: PopoverProps["closeOnScroll"];
}

function highlight(text: React.ReactNode, keyword: string): React.ReactNode {
  if (typeof text !== "string") {
    return text;
  }
  return text.split(keyword).map((text, index) => {
    const key = `${text}-${index}`;
    if (index >= 1) {
      return (
        <Fragment key={key}>
          <Text theme={index === 1 ? "primary" : "text"}>{keyword}</Text>
          {text}
        </Fragment>
      );
    }
    return <Text key={key}>{text}</Text>;
  });
}

export function AutoComplete(props: AutoCompleteProps) {
  const {
    className,
    style = {},
    value,
    onChange,
    children,
    options = [],
    groups = {},
    tips = "",
    keyword,
    onScrollBottom,
    closeOnScroll = true,
  } = useDefaultValue(props);
  const timerRef = useRef(null);
  const inputRef = useRef<HTMLElement>(null);
  const [isOpened, setIsOpened] = useState(false);
  const [dropdownWidth, setDropdownWidth] = useState<number>(undefined);

  useEffect(() => () => clearTimeout(timerRef.current), []);

  const close = () => setIsOpened(false);

  const hasGroup = !!options.find(opt => !!opt.groupKey);

  return (
    <Popover
      animationScaleFrom={1}
      transitionTimeout={{ enter: 0, exit: 100 }}
      trigger={AutoCompleteTrigger}
      placement="bottom-start"
      visible={isOpened}
      onVisibleChange={setIsOpened}
      placementOffset={5}
      closeOnScroll={closeOnScroll}
      overlay={
        <DropdownBox
          className={className}
          style={{ width: dropdownWidth, ...style }}
        >
          {Array.isArray(options) && options.length > 0 ? (
            <List
              type={hasGroup ? "option-group" : "option"}
              onScrollBottom={onScrollBottom}
            >
              {options.map(
                (
                  { value: optValue, text, disabled, tooltip, groupKey },
                  index
                ) => {
                  const item = (
                    <List.Item
                      key={optValue}
                      current={optValue === value}
                      disabled={disabled}
                      tooltip={tooltip}
                      onClick={event => {
                        event.stopPropagation();
                        inputRef.current.focus();
                        onChange(optValue, { event });
                        timerRef.current = setTimeout(close, 1);
                      }}
                    >
                      {highlight(text || optValue, keyword)}
                    </List.Item>
                  );

                  if (
                    groupKey &&
                    (index === 0 || groupKey !== options[index - 1].groupKey)
                  ) {
                    return (
                      <Fragment key={optValue}>
                        <List.GroupLabel>{groups[groupKey]}</List.GroupLabel>
                        {item}
                      </Fragment>
                    );
                  }

                  return item;
                }
              )}
            </List>
          ) : (
            !!tips && (
              <List type="option">
                <List.StatusTip>
                  {typeof tips === "string" ? (
                    <EmptyTip emptyText={tips} />
                  ) : (
                    tips
                  )}
                </List.StatusTip>
              </List>
            )
          )}
        </DropdownBox>
      }
    >
      {children(
        dom => {
          inputRef.current = dom;
          if (dom) {
            setDropdownWidth(dom.offsetWidth);
          }
        },
        { close: () => setIsOpened(false) }
      )}
    </Popover>
  );
}

export function AutoCompleteTrigger({
  setVisible,
  openDelay = 0,
  closeDelay = 0,
  render,
}: TriggerProps) {
  const commonProps = {
    onFocus: () => setVisible(true, openDelay),
    onChange: () => setVisible(true, openDelay),
    onClick: () => setVisible(true, openDelay),
    onBlur: () => setVisible(false, closeDelay),
  };
  return render({
    overlayProps: { ...commonProps, tabIndex: 1000 },
    childrenProps: commonProps,
  });
}

AutoComplete.defaultLabelAlign = "middle";
