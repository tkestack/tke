import React from "react";

export const withResize = (methodName: string) => <
  P,
  T extends React.ComponentClass
>(
  Component: T
) =>
  (class WithResize extends React.Component<any> {
    public static displayName = `withResize(${Component.displayName ||
      Component.name ||
      "Unknown"})`;

    private instance: React.Component;

    public componentDidMount() {
      window.addEventListener("resize", this.resizeListener);
    }

    public componentWillUnmount() {
      window.removeEventListener("resize", this.resizeListener);
    }

    private resizeListener = evt => {
      if (this.instance) {
        this.instance[methodName](evt);
      }
    };

    public render() {
      return React.createElement(Component, {
        ...this.props,
        ref: instance => {
          this.instance = instance;
          return instance;
        },
      });
    }
  } as any) as T;
