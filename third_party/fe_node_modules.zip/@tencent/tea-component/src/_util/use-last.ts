import { MutableRefObject, useRef, useEffect } from "react";

export function useLast<T>(value: T): MutableRefObject<T> {
  const ref = useRef(value);

  useEffect(() => {
    ref.current = value;
  });

  return ref;
}
