# Radio 单选

用于在一组可选项中执行单项选择。

## 使用示例

### 单选组

[Example: 单选组](./_example/RadioExample.jsx)

### 受控 Radio

[Example: 受控 Radio](./_example/RadioControlledExample.jsx)

## 组件属性

[Interface: RadioGroupProps](./RadioGroup.tsx)

[Interface: RadioProps](./Radio.tsx)

## 从 Tea v1 升级

- `theme` 属性废弃，设计统一管理
- `onChange` 回调改为规范化的受控组件回调
- 增加 `column` 布局类型，竖排单选框
