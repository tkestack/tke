import moment, { Moment, isMoment } from "moment";
import { TimePickerProps } from "./TimeProps";

const SEQUENCE_24 = Array(24)
  .fill(0)
  .map((_, i) => i);
const SEQUENCE_60 = Array(60)
  .fill(0)
  .map((_, i) => i);

const startOfDay = moment().startOf("day");
const endOfDay = moment().endOf("day");

export function getHourMinuteSecond(time: Moment) {
  return {
    hour: time.hour(),
    minute: time.minute(),
    second: time.second(),
  };
}

/**
 * 解析 format
 * @param format
 */
export function genShowHourMinuteSecond(format: string) {
  // Ref: http://momentjs.com/docs/#/parsing/string-format/
  return {
    showHour:
      format.indexOf("H") > -1 ||
      format.indexOf("h") > -1 ||
      format.indexOf("k") > -1,
    showMinute: format.indexOf("m") > -1,
    showSecond: format.indexOf("s") > -1,
  };
}

/**
 * 校验 range
 */
function isValidRange(range): boolean {
  return Array.isArray(range) && (isMoment(range[0]) || isMoment(range[1]));
}

/**
 * 获取 disabled 部分
 */
export function getDisabledHours({
  range,
  disabledHours = () => [],
}: Partial<TimePickerProps>) {
  if (isValidRange(range)) {
    const min = getHourMinuteSecond(range[0] || startOfDay);
    const max = getHourMinuteSecond(range[1] || endOfDay);
    return [
      ...disabledHours(),
      ...SEQUENCE_24.filter(i => i < min.hour || i > max.hour),
    ];
  }
  return disabledHours();
}

export function getDisabledMinutes(
  hour: number,
  { range, disabledMinutes = () => [] }: Partial<TimePickerProps>
) {
  if (isValidRange(range)) {
    const min = getHourMinuteSecond(range[0] || startOfDay);
    const max = getHourMinuteSecond(range[1] || endOfDay);
    return [
      ...disabledMinutes(hour),
      ...SEQUENCE_60.filter(
        i =>
          (hour === min.hour && i < min.minute) ||
          (hour === max.hour && i > max.minute)
      ),
    ];
  }
  return disabledMinutes(hour);
}

export function getDisabledSeconds(
  hour: number,
  minute: number,
  { range, disabledSeconds = () => [] }: Partial<TimePickerProps>
) {
  if (isValidRange(range)) {
    const min = getHourMinuteSecond(range[0] || startOfDay);
    const max = getHourMinuteSecond(range[1] || endOfDay);
    return [
      ...disabledSeconds(hour, minute),
      ...SEQUENCE_60.filter(
        i =>
          (hour === min.hour && minute === min.minute && i < min.second) ||
          (hour === max.hour && minute === max.minute && i > max.second)
      ),
    ];
  }
  return disabledSeconds(hour, minute);
}

/**
 * 获取自动调整后的合法值
 */
export function getValidTimeValue(
  value: Moment,
  rangeOptions: Partial<TimePickerProps> = {},
  format: string = "HH:mm:ss"
): Moment {
  const { showHour, showMinute, showSecond } = genShowHourMinuteSecond(format);
  let { hour, minute, second } = getHourMinuteSecond(value || moment(0, "HH"));

  const disabledHours = getDisabledHours(rangeOptions);
  if (showHour && disabledHours.includes(hour)) {
    hour = SEQUENCE_24.find(i => !disabledHours.includes(i));
  }

  const disabledMinutes = getDisabledMinutes(hour, rangeOptions);
  if (showMinute && disabledMinutes.includes(minute)) {
    minute = SEQUENCE_60.find(i => !disabledMinutes.includes(i));
  }

  const disabledSeconds = getDisabledSeconds(hour, minute, rangeOptions);
  if (showSecond && disabledSeconds.includes(second)) {
    second = SEQUENCE_60.find(i => !disabledSeconds.includes(i));
  }

  return (value || moment()).set({ hour, minute, second });
}
