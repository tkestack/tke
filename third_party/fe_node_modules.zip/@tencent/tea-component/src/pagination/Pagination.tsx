import React, { useState } from "react";
import classNames from "classnames";
import { StyledProps, Combine } from "../_type";
import { Icon } from "../icon";
import { Tooltip } from "../tooltip";
import { useTranslation } from "../i18n";
import { Select } from "../select";

/** 表示分页信息 */
export interface PagingQuery {
  /** 页码：从 1 开始索引 */
  pageIndex?: number;

  /** 页长：表示每页记录数 */
  pageSize?: number;
}

export interface PaginationProps
  extends Combine<StyledProps, Partial<PagingQuery>> {
  /**
   * 必传，数据总个数，用于计算页数
   */
  recordCount: number;

  /**
   * 切换分页回调函数
   */
  onPagingChange?: (query: PagingQuery) => void;

  /**
   * 切换页长时，是否自动把页码重设为 1
   * @default true
   */
  isPagingReset?: boolean;

  /** 分页组件显示的说明信息，不传将渲染数据个数信息 */
  stateText?: React.ReactNode;

  /**
   * 支持的页长设置
   * @default [10, 20, 30, 50, 100, 200]
   */
  pageSizeOptions?: number[];

  /**
   * 是否显示状态文案
   * @default true
   */
  stateTextVisible?: boolean;

  /**
   * 是否显示页长选择
   * @default true
   */
  pageSizeVisible?: boolean;

  /**
   * 是否显示页码输入
   * @default true
   */
  pageIndexVisible?: boolean;

  /**
   * 是否显示切页按钮（上一页/下一页）
   * @default true
   */
  jumpVisible?: boolean;

  /**
   * 是否显示第一页和最后一页按钮
   * @default true
   */
  endJumpVisible?: boolean;
}

const defaultPageSizeOptions = [10, 20, 30, 50, 100, 200];
const noop = () => {};

export function Pagination({
  pageIndex,
  pageSize,
  pageSizeOptions,
  recordCount,
  onPagingChange = noop,
  isPagingReset = true,
  stateText,
  stateTextVisible,
  pageSizeVisible,
  pageIndexVisible,
  jumpVisible,
  endJumpVisible,
  style,
  className,
}: PaginationProps) {
  const t = useTranslation();

  if (!Array.isArray(pageSizeOptions) || pageSizeOptions.length === 0) {
    pageSizeOptions = defaultPageSizeOptions; // eslint-disable-line no-param-reassign
  }

  // 为非受控组件提供状态管理
  const [internalPaging, setInternalPaging] = useState<PagingQuery>({
    pageIndex: 1,
    pageSize: pageSizeOptions[0],
  });

  // 非受控组件，使用内部状态
  if (typeof pageIndex === "undefined") {
    pageIndex = internalPaging.pageIndex; // eslint-disable-line
  }
  if (typeof pageSize === "undefined") {
    pageSize = internalPaging.pageSize; // eslint-disable-line
  }

  // 状态改变同时更新内部状态和通知外部
  // eslint-disable-next-line no-param-reassign
  onPagingChange = (onPagingChange => (query: PagingQuery) => {
    setInternalPaging(query);
    onPagingChange(query);
  })(onPagingChange);

  // 总页数
  const pageCount = Math.max(1, Math.ceil(recordCount / pageSize));

  // 改变页长
  const changePageSize = (pageSize: number) => {
    onPagingChange({
      pageIndex: isPagingReset ? 1 : pageIndex,
      pageSize,
    });
  };

  // 改变页码
  const changePageIndex = (pageIndex: number) =>
    onPagingChange({
      pageIndex,
      pageSize,
    });

  // 渲染分页状态信息
  const stateElement = (() => {
    if (stateTextVisible === false) {
      return null;
    }
    return (
      <div className="tea-pagination__state">
        <span className="tea-pagination__text">
          {typeof stateText === "undefined"
            ? t.paginationRecordCount(recordCount)
            : stateText}
        </span>
      </div>
    );
  })();

  // 操作区元素
  let operatationElements: JSX.Element[] = [];

  // 页码输入
  if (pageIndexVisible !== false) {
    operatationElements = [
      <PageIndexInput
        key="page-index-input"
        pageIndex={pageIndex}
        pageCount={pageCount}
        onChange={changePageIndex}
      />,
    ];
  }

  // 页码跳转
  if (jumpVisible !== false) {
    operatationElements = [
      <PaginationButton
        key="jump-prev"
        type="pre"
        icon="arrowleft"
        disabled={pageIndex <= 1}
        title={pageIndex > 1 ? t.paginationPrevPage : t.paginationAtFirst}
        onClick={() => changePageIndex(pageIndex - 1)}
      />,
      ...operatationElements,
      <PaginationButton
        key="jump-next"
        type="next"
        icon="arrowright"
        disabled={pageIndex >= pageCount}
        title={
          pageIndex < pageCount ? t.paginationNextPage : t.paginationAtLast
        }
        onClick={() => changePageIndex(pageIndex + 1)}
      />,
    ];
  }

  // 页头页尾跳转
  if (endJumpVisible !== false) {
    operatationElements = [
      <PaginationButton
        key="jump-first"
        type="first"
        icon="firstpage"
        disabled={pageIndex <= 1}
        title={pageIndex > 1 ? t.paginationToFirstPage : t.paginationAtFirst}
        onClick={() => changePageIndex(1)}
      />,
      ...operatationElements,
      <PaginationButton
        key="jump-last"
        type="last"
        icon="lastpage"
        disabled={pageIndex >= pageCount}
        title={
          pageIndex < pageCount ? t.paginationToLastPage : t.paginationAtLast
        }
        onClick={() => changePageIndex(pageCount)}
      />,
    ];
  }

  // 页长选择
  if (pageSizeVisible !== false) {
    operatationElements = [
      <span key="page-size-text" className="tea-pagination__text">
        {t.paginationRecordPerPage}
      </span>,
      <Select
        key="page-size-select"
        type="simulate"
        options={pageSizeOptions.map(page => ({
          value: String(page),
          text: page,
        }))}
        value={String(pageSize)}
        onChange={pageSize => changePageSize(Number(pageSize))}
        placement="top"
        boxClassName="size-auto-width"
      />,
      ...operatationElements,
    ];
  }

  return (
    <div className={classNames("tea-pagination", className)} style={style}>
      {stateElement}
      <div className="tea-pagination__operate">{operatationElements}</div>
    </div>
  );
}

export interface PaginationButtonProps {
  type: "pre" | "next" | "first" | "last" | "cur";
  icon: string;
  disabled?: boolean;
  title?: string;
  onClick?: React.MouseEventHandler;
}
export function PaginationButton({
  type,
  disabled,
  icon,
  title,
  onClick,
}: PaginationButtonProps) {
  const buttonClassName = classNames({
    "tea-pagination__turnbtn": true,
    [`tea-pagination__${type}btn`]: type,
    "is-disabled": disabled,
  });

  const button = (
    <a
      className={buttonClassName}
      onClick={disabled ? null : onClick}
      onDoubleClick={evt => evt.preventDefault()}
      style={{ userSelect: "none" }}
    >
      <Icon type={icon} />
    </a>
  );

  if (title) {
    return <Tooltip title={title}>{button}</Tooltip>;
  }

  return button;
}

interface PageIndexInputProps {
  pageIndex: number;
  pageCount: number;
  onChange: (pageIndex: number) => void;
}

function PageIndexInput({
  pageIndex,
  pageCount,
  onChange,
}: PageIndexInputProps) {
  const [inputValue, setInputValue] = useState(null);
  const t = useTranslation();

  return (
    <div className="tea-pagination__manualinput">
      <input
        type="text"
        className="tea-input tea-pagination__inputpagenum"
        value={inputValue === null ? String(pageIndex) : inputValue}
        onChange={evt => setInputValue(evt.target.value)}
        onBlur={() => setInputValue(null)}
        onKeyDown={evt => {
          // enter to confirm
          if (evt.keyCode === 13) {
            const parsedPageIndex = parseInt(inputValue, 10);
            if (
              parsedPageIndex !== pageIndex &&
              parsedPageIndex >= 1 &&
              parsedPageIndex <= pageCount
            ) {
              onChange(parsedPageIndex);
            }
            setInputValue(null);
          }
          // up/down key
          else if (evt.keyCode === 38 || evt.keyCode === 40) {
            let nextPageValue = parseInt(inputValue, 10);
            if (Number.isNaN(nextPageValue)) {
              nextPageValue = pageIndex;
            }
            if (evt.keyCode === 38) {
              nextPageValue = Math.max(1, nextPageValue + 1);
            } else if (evt.keyCode === 40) {
              nextPageValue = Math.min(pageCount, nextPageValue - 1);
            }
            setInputValue(String(nextPageValue));
          }
        }}
      />
      <span className="tea-pagination__totalpage">
        {t.paginationPageCount(pageCount)}
      </span>
    </div>
  );
}
