import React from "react";
import { Combine, StyledProps } from "../_type";
import { DropdownProps, CommonDropdownProps } from "../dropdown";
import { ControlledProps } from "../form";
import { SelectOption } from "./SelectOption";
import { SelectSearchProps } from "./SelectProps";
export interface SelectMultipleProps extends Combine<SelectSearchProps<SelectOption>, CommonDropdownProps, StyledProps, ControlledProps<string[]>> {
    /**
     * 选项列表
     */
    options?: SelectOption[];
    /**
     * 表示全选的选项
     */
    allOption?: SelectOption | false;
    /**
     * 如果开启了全选支持，则可以指定哪些记录从全选的范围内排除
     *
     * - 默认为 'disabled' 可以排除禁用的记录
     * - 提供回调则自定义哪些记录应该排除，对于应该排除的记录，应该返回 `true`
     *
     * @default "disabled"
     */
    shouldOptionExcludeFromAll?: "disabled" | ((option: SelectOption) => boolean);
    /**
     * 允许不选择项
     *
     * @default true
     */
    allowEmpty?: boolean;
    /**
     * 是否暂存操作结果
     *
     * - 设置为 `true`，则会提供确定和取消按钮，确定后才会触发 onChange
     * - 设置为 `false`，则不渲染确定和取消按钮，修改后直接触发 onChange
     *
     * @default true
     */
    staging?: boolean;
    /**
     * 占位符
     * @default "请选择"（已处理国际化）
     */
    placeholder?: string;
    /**
     * 是否禁用
     * @default false
     */
    disabled?: boolean;
    /**
     * 下拉选框的外观
     *
     * - `default` 无边框，适用于页面标题和表格内
     * - `button` 为按钮风格，有边框，多用于操作栏中
     * - `link` 为超链接风格
     * - `filter` 为过滤组件风格，多用于表头筛选
     * - `pure` 无额外样式
     *
     * 原有 `raw` 类型建议使用 `pure` 进行改造
     *
     * @default "default"
     */
    appearence?: DropdownProps["appearence"];
    /**
     * 按钮显示内容，默认会显示当前选中的选项
     */
    button?: DropdownProps["button"];
    /**
     * 下拉框大小
     */
    size?: DropdownProps["size"];
    /**
     * 弹出区域自定义类名
     */
    boxClassName?: DropdownProps["boxClassName"];
    /**
     * 弹出区域自定义样式
     */
    boxStyle?: DropdownProps["boxStyle"];
    /**
     * 可使用字符串或 [StatusTip](/component/tips) 相关组件
     */
    tips?: React.ReactNode;
}
export declare const SelectMultiple: ((props: SelectMultipleProps) => JSX.Element) & {
    defaultLabelAlign: string;
};
