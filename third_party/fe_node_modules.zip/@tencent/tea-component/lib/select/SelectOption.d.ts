import React from "react";
export interface SelectOption {
    /**
     * 选项值
     */
    value: string;
    /**
     * 选项显示的内容，如不传，则使用 `value` 作为显示内容
     */
    text?: React.ReactNode;
    /**
     * 是否禁用选项
     * @default false
     */
    disabled?: boolean;
    /**
     * 选项显示的 Tooltip 内容
     */
    tooltip?: React.ReactNode;
}
export interface SelectOptionWithGroup extends SelectOption {
    /**
     * 分组 Key
     */
    groupKey?: string;
}
