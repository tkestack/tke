import React from "react";
export interface ModalMessageProps {
    /**
     * 要提示的消息
     */
    message: React.ReactNode;
    /**
     * 可选的详细解释
     */
    description?: React.ReactNode;
    /**
     * 提示图标
     */
    icon?: "error" | "warning" | "pending" | "infoblue" | "success";
}
export declare function ModalMessage({ icon, message, description, }: ModalMessageProps): JSX.Element;
