import React, { ReactNode } from "react";
import { StyledProps } from "../_type";
import { ModalMessage } from "./ModalMessage";
/**
 * 对话框组件配置：
 */
export interface ModalProps extends StyledProps {
    /**
     * 对话框内容
     */
    children?: ReactNode;
    /**
     * 对话框是否可见
     */
    visible?: boolean;
    /**
     * 对话框的标题
     * 如果禁用关闭图标的同时，没有传入对话框标题，则不渲染标题
     */
    caption?: string | JSX.Element;
    /**
     * 对话框尺寸，决定对话框的宽度
     *   - `"s"` 小尺寸对话框，宽度 480px
     *   - `"m"` 默认尺寸对话框，宽度 550px
     *   - `"l"` 大尺寸对话框，宽度 800px
     *   - `"xl"` 超大尺寸对话框，宽度 950px
     *   - `"auto"` 自动适应宽度
     *   - 传入数字/百分比可以自定义宽度
     */
    size?: "s" | "m" | "l" | "xl" | "auto" | number | string;
    /**
     * 对话框关闭按钮点击时回掉
     */
    onClose?: () => void;
    /**
     * 对话框关闭动画结束时回调
     */
    onExited?: () => void;
    /**
     * 默认 ESC 键会触发 `onClose` 的调用，设置为 `true` 禁止该行为
     * @default false
     */
    disableEscape?: boolean;
    /**
     * 是否禁用关闭图标
     * 如果禁用关闭图标的同时，没有传入对话框标题，则不渲染标题
     * @default false
     */
    disableCloseIcon?: boolean;
    /**
     * 是启用点击遮罩关闭
     * @default false
     */
    maskClosable?: boolean;
}
/**
 * 模态对话框组件
 */
export declare function Modal({ visible, caption, size, onClose, onExited, disableEscape, disableCloseIcon, maskClosable, className, style, children, }: ModalProps): React.ReactPortal;
export declare namespace Modal {
    var Body: React.ForwardRefExoticComponent<import("../_util/create-rocket").RocketProps & React.RefAttributes<HTMLElement>>;
    var Footer: React.ForwardRefExoticComponent<import("../_util/create-rocket").RocketProps & React.RefAttributes<HTMLElement>>;
    var Message: typeof ModalMessage;
}
