/// <reference types="react" />
import { Modal as ModalMain, ModalProps } from "./ModalMain";
import { confirm, ModalConfirm, ModalConfirmProps, ConfirmOptions } from "./ModalConfirm";
import { success, error, alert, ModalAlert, ModalAlertProps, AlertOptions } from "./ModalAlert";
export { ModalProps, ModalConfirm, ModalConfirmProps, ConfirmOptions, ModalAlert, ModalAlertProps, AlertOptions, };
export declare const Modal: typeof ModalMain & {
    /**
     * 渲染对话框的主要内容
     */
    Body: import("react").ForwardRefExoticComponent<import("../_util/create-rocket").RocketProps & import("react").RefAttributes<HTMLElement>>;
    /**
     * 渲染对话框的底部内容
     */
    Footer: import("react").ForwardRefExoticComponent<import("../_util/create-rocket").RocketProps & import("react").RefAttributes<HTMLElement>>;
    /**
     * 对话框消息内容，可置于 ModalMain..Body 中
     */
    Message: typeof import("./ModalMessage").ModalMessage;
    /**
     * API 的方式唤起一个确认对话框
     * @returns 异步返回布尔值，为 `true` 则表示用户确认，为 `false` 则表示用户取消
     */
    confirm: typeof confirm;
    /**
     * API 的方式唤起一个对话框显示成功信息
     */
    success: typeof success;
    /**
     * API 的方式唤起一个对话框显示失败信息
     */
    error: typeof error;
    /**
     * API 的方式唤起一个对话框显示提醒信息
     */
    alert: typeof alert;
};
