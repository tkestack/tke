import React from "react";
import { ModalProps } from "./ModalMain";
import { Combine } from "../_type";
/**
 * `Modal.confirm` 方法接收以下参数：
 */
export interface ConfirmOptions {
    /**
     * 要询问的消息
     */
    message: React.ReactNode;
    /**
     * 可选的详细解释
     */
    description?: React.ReactNode;
    /**
     * 确认按钮的文案
     */
    okText?: React.ReactNode;
    /**
     * 取消按钮的文案
     */
    cancelText?: React.ReactNode;
    /**
     * 是否禁用关闭图标。
     *
     * 默认情况下会显示，关闭对话框认为是取消操作。
     * @default false
     */
    disableCloseIcon?: boolean;
    /**
     * 对话框尺寸，决定对话框的宽度，详见 ModalProps 中 `size` 属性
     */
    size?: ModalProps["size"];
}
/**
 * API 的方式唤起一个确认对话框
 * @param options
 * @returns 异步返回布尔值，为 true 则表示用户确认，为 false 则表示用户取消
 */
export declare function confirm(options: ConfirmOptions): Promise<boolean>;
export interface ModalConfirmProps extends Combine<ModalProps, ConfirmOptions> {
    onOk(): void;
    onCancel(): void;
}
/**
 * 提供原始的 ModalConfirm 组件。
 * 推荐使用 `Modal.confirm()` API 来简化用法
 */
export declare function ModalConfirm({ message, description, ...modalProps }: ModalConfirmProps): JSX.Element;
