import React from "react";
import { TreeContextValue } from "./TreeContext";
import { StyledProps } from "../_type";
export interface TreeNodeProps extends StyledProps {
    /**
     * 节点 ID，整棵树中唯一
     */
    id: string;
    /**
     * 节点内容
     */
    content: React.ReactNode;
    /**
     * 节点图标
     *
     * @docType React.ReactNode | (context: { expanded: boolean }) => React.ReactNode
     */
    icon?: ((context: {
        expanded: boolean;
    }) => React.ReactNode) | React.ReactNode;
    /**
     * hover 后展示的操作
     *
     * 推荐使用文字（TreeNode.ActionLink），若超过一项，建议收至 Dropdown 下
     */
    operation?: React.ReactNode;
    /**
     * 当树为 selectable 时，设置当前节点是否展示 Checkbox
     *
     * @default true
     */
    selectable?: boolean;
    /**
     * 当树为 selectable 时，设置当前节点 Checkbox 是否禁用
     *
     * @default false
     */
    disableSelect?: boolean;
    /**
     * 当前节点是否支持展开（用于异步加载）
     *
     * @default false
     */
    expandable?: boolean;
    /**
     * 包含的树节点 <TreeNode />
     */
    children?: React.ReactNode;
}
export declare const TreeNode: ((props: TreeNodeProps) => JSX.Element) & {
    ActionLink: typeof ActionLink;
};
export declare function TreeNodeInner({ id, content, icon, operation, selectable, activable, activeIds, onActive, expandable, children, expandedIds, onExpand, onLoad, onLoadError, switcherIcon, className, style, }: TreeNodeProps & TreeContextValue): JSX.Element;
declare function ActionLink({ children, className, ...props }: React.AnchorHTMLAttributes<HTMLAnchorElement>): JSX.Element;
export {};
