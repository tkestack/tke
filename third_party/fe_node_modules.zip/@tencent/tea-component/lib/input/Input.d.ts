import React from "react";
import { Combine, StyledProps, Omit } from "../_type";
import { ControlledProps } from "../form/controlled";
export declare type SizeType = "full" | "l" | "m" | "s" | "xs";
/**
 * Input 组件支持的属性。
 *
 * 除表格中列出的属性外，支持透传原生 `<input>` 或 `<textarea>` 标签支持的属性。
 */
export interface InputProps extends Combine<StyledProps, ControlledProps<string>, Omit<React.InputHTMLAttributes<HTMLInputElement> & React.TextareaHTMLAttributes<HTMLTextAreaElement>, "onChange" | "size">> {
    /**
     * 是否多行输入
     */
    multiline?: boolean;
    /**
     * Input 组件不应该传入 children
     */
    children?: never;
    /**
     * 占位符
     */
    placeholder?: string;
    /**
     * 是否禁用
     * @default false
     */
    disabled?: boolean;
    /**
     * 是否为只读模式
     * @default false
     */
    readonly?: boolean;
    /**
     * 最大输入长度
     */
    maxLength?: number;
    /**
     * 原生 `<input>` 标签 `type` 属性
     */
    type?: React.InputHTMLAttributes<HTMLInputElement>["type"];
    /**
     * 输入框尺寸，使用 full 撑满容器宽度
     */
    size?: SizeType;
    /**
     * 改变 Input 的基本样式类名，不建议使用
     */
    baseClassName?: string;
}
export declare const Input: React.FunctionComponent<InputProps & React.RefAttributes<HTMLInputElement | HTMLTextAreaElement>> & {
    /**
     * 在表单布局中，和 label 的默认对齐方式
     */
    defaultLabelAlign: string;
};
