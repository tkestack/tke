/// <reference types="react" />
import { Omit } from "../_type";
import { CheckProps } from "../check";
/**
 * Switch 组件所接收的参数
 */
export interface SwitchProps extends Omit<CheckProps, "type"> {
    /**
     * 是否繁忙
     */
    loading?: boolean;
}
export declare function Switch(props: SwitchProps): JSX.Element;
