import React from "react";
import { InputProps } from "../input";
export interface SearchBoxProps extends InputProps {
    /**
     * 是否为多行搜索模式
     *
     * @default false
     */
    multiline?: boolean;
    /**
     * 是否为简洁模式
     *
     * @default false
     */
    simple?: boolean;
    /**
     * 点击搜索或输入回车时回调
     * 如果自行绑定了 onKeydown 处理方法，则该回调不再提供
     */
    onSearch?: (keyword?: string) => void;
    /**
     * 用户清空搜索时回调
     * */
    onClear?: () => void;
}
export declare const SearchBox: React.ForwardRefExoticComponent<SearchBoxProps & React.RefAttributes<HTMLInputElement | HTMLTextAreaElement>>;
