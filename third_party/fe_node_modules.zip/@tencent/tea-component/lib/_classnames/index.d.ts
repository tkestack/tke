export declare const TeaClassNames: {
    Heading: {
        H1: string;
        H2: string;
        H3: string;
        H4: string;
        H5: string;
        H6: string;
    };
    TextOverflow: string;
    TextNowrap: string;
    FloatLeft: string;
    FloatRight: string;
    Clearfix: string;
};
