import React from "react";
import { StyledProps } from "../_type";
import { MenuGroup } from "./MenuGroup";
import { SubMenu } from "./SubMenu";
import { MenuItem } from "./MenuItem";
export interface MenuBackOptions {
    /**
     * 返回区域标题
     */
    title?: React.ReactNode;
    /**
     * 返回区域描述
     */
    description?: React.ReactNode;
    /**
     * 为该区域文字添加 Tooltip 说明
     */
    tooltip?: React.ReactNode;
    /**
     * 返回按钮点击回调
     */
    onClick?: (event: React.MouseEvent) => void;
}
export interface MenuProps extends StyledProps {
    /**
     * 标题
     */
    title?: React.ReactNode;
    /**
     * 标题旁标签内容
     */
    tag?: React.ReactNode;
    /**
     * 导航折叠后标题处显示的图标 URL
     */
    icon?: [string, string] | string;
    /**
     * 顶部返回区域相关配置
     */
    back?: MenuBackOptions;
    /**
     * 主题样式
     *
     * @default "light"
     */
    theme?: "light" | "dark";
    /**
     * 导航内容（Menu.Group 或 Menu.SubMenu 或 Menu.Item）
     */
    children?: React.ReactNode;
    /**
     * 导航是否支持折叠（展示底部折叠/展示操作区）
     *
     * 如开启支持请为菜单项配置图标
     *
     * @default false
     */
    collapsable?: boolean;
    /**
     * 导航是否默认被折叠
     *
     * @default false
     */
    defaultCollapsed?: boolean;
    /**
     * 导航是否被折叠
     *
     * @default false
     */
    collapsed?: boolean;
    /**
     * 导航折叠变化时回调
     */
    onCollapsedChange?: (collapsed: boolean) => void;
}
export declare const Menu: (({ theme, title, tag, icon, back, children, className, style, collapsable, defaultCollapsed, collapsed, onCollapsedChange, }: MenuProps) => JSX.Element) & {
    Group: typeof MenuGroup;
    SubMenu: typeof SubMenu;
    Item: typeof MenuItem;
};
