import React from "react";
export interface MetricsBoardProps {
    /**
     * 标题
     */
    title: React.ReactNode;
    /**
     * 统计数值
     */
    value: React.ReactNode;
    /**
     * 统计数值单位
     */
    unit?: React.ReactNode;
    /**
     * 统计信息
     */
    infos?: React.ReactNode[];
    /**
     * 点击回调
     *
     * **当传递该回调函数后，组件会变为可点击的样式**
     */
    onClick?: (event: React.MouseEvent<HTMLDivElement>) => void;
}
export declare function MetricsBoard({ title, value, unit, infos, onClick, }: MetricsBoardProps): JSX.Element;
export declare namespace MetricsBoard {
    var InfoLabel: React.ForwardRefExoticComponent<import("../_util/create-rocket").RocketProps & React.RefAttributes<HTMLElement>>;
    var InfoKey: React.ForwardRefExoticComponent<import("../_util/create-rocket").RocketProps & React.RefAttributes<HTMLElement>>;
}
