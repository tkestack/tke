import React from "react";
import { AttributeValue } from "./AttributeSelect";
export interface TagInputProps {
    /**
     * 触发标签相关事件
     */
    dispatchTagEvent: (type: string, payload?: any) => void;
    /**
     * 所有属性集合
     */
    attributes: Array<AttributeValue>;
    /**
     * 是否为 Focus 态
     */
    isFocused: boolean;
    /**
     * 搜索框是否处于展开状态
     */
    active: boolean;
    /**
     * 输入框类型（用于修改标签值的 Input type 为 "edit"）
     */
    type?: "edit" | "add";
    /**
     * 是否隐藏
     */
    hidden?: boolean;
    /**
     * 最大宽度
     */
    maxWidth: number;
    /**
     * 处理按键事件
     */
    handleKeyDown?: (e: any) => void;
    /**
     * 位置偏移
     */
    inputOffset?: number;
}
export interface InputState {
    inputWidth: number;
    inputValue: string;
    attribute: AttributeValue;
    values: Array<any>;
    showAttrSelect: boolean;
    showValueSelect: boolean;
    ValueSelectOffset: number;
}
export declare class TagInput extends React.Component<TagInputProps, any> {
    state: InputState;
    _scheduleUpdate: () => any;
    wrapperRef: React.RefObject<HTMLDivElement>;
    constructor(props: any);
    componentDidMount(): void;
    /**
     * 刷新下拉列表位置
     */
    scheduleUpdate: () => any;
    /**
     * 刷新选择组件显示
     */
    refreshShow: () => void;
    focusInput: () => void;
    moveToEnd: () => void;
    selectValue: () => void;
    selectAttr: () => void;
    setInfo(info: any, callback?: Function): void;
    setInputValue: (value: string, callback?: Function) => void;
    resetInput: (callback?: Function) => void;
    getInputValue: () => string;
    addTagByInputValue: () => boolean;
    handleInputChange: (e: any) => void;
    handleInputClick: (e: any) => void;
    handleAttrSelect: (attr: AttributeValue) => void;
    handleValueChange: (values: any[]) => void;
    /**
     * 值选择组件完成选择
     */
    handleValueSelect: (values: any[]) => void;
    /**
     * 值选择组件取消选择
     */
    handleValueCancel: () => void;
    /**
     * 处理粘贴事件
     */
    handlePaste: (e: any) => void;
    handlekeyDown: (e: any) => void;
    getAttrStrAndValueStr: (str: string) => any;
    render(): JSX.Element;
}
