import React from "react";
import { AttributeValue } from "./AttributeSelect";
import { FocusPosType } from "./TagSearchBox";
import { TranslationProps } from "../i18n";
export interface TagValue {
    /**
     * 标签标识
     */
    _key: string;
    /**
     * 当前是否在编辑状态
     */
    _edit?: boolean;
    /**
     * 标签属性
     */
    attr?: AttributeValue;
    /**
     * 标签属性值
     */
    values?: any[];
}
export interface TagProps {
    /**
     * 标签属性
     */
    attr?: AttributeValue;
    /**
     * 标签属性值
     */
    values?: any[];
    /**
     * 触发标签相关事件
     */
    dispatchTagEvent?: (type: string, payload?: any) => void;
    /**
     * 所有属性集合
     */
    attributes: AttributeValue[];
    /**
     * 当前聚焦状态
     */
    focused: FocusPosType;
    /**
     * 最大长度
     */
    maxWidth?: number;
    /**
     * 搜索框是否处于展开状态
     */
    active: boolean;
}
export interface TagState {
    inEditing: boolean;
}
export declare class Tag extends React.Component<TagProps & TranslationProps, TagState> {
    state: TagState;
    focusTag(): void;
    focusInput(): void;
    resetInput(): void;
    setInputValue(value: string, callback?: Function): void;
    getInputValue(): string;
    addTagByInputValue(): boolean;
    addTagByEditInputValue(): boolean;
    setInfo(info: any, callback?: Function): void;
    moveToEnd(): void;
    getInfo(): any;
    edit(pos: string): void;
    editDone(): void;
    handleTagClick: (e: any, pos?: string) => void;
    handleDelete: (e: any) => void;
    handleKeyDown: (e: any) => void;
    render(): JSX.Element;
}
