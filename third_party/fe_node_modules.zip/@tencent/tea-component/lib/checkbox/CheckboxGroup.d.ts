import React from "react";
import { ControlledProps } from "../form/controlled";
import { CheckChangeContext } from "../check/Check";
import { Combine, StyledProps } from "../_type";
/**
 * CheckboxGroup 组件所接收的参数
 */
export interface CheckboxGroupProps extends Combine<StyledProps, ControlledProps<string[]>> {
    /**
     * 已选中的值集合，由 `value = true` 的 `<Checkbox />` 的 `name` 属性组成
     */
    value?: string[];
    /**
     * 值变更时回调
     */
    onChange?: (value: string[], context: CheckChangeContext) => void;
    /**
     * 禁用组件
     * */
    disabled?: boolean;
    /**
     * 使用水平布局（`inline`）还是纵向排列布局（`column`）
     * @default "inline"
     */
    layout?: "inline" | "column";
    /**
     * 复选框内容
     */
    children?: React.ReactNode;
}
/**
 * 单选选项组，里面可以嵌套 <Radio />
 */
export declare function CheckboxGroup(props: CheckboxGroupProps): JSX.Element;
