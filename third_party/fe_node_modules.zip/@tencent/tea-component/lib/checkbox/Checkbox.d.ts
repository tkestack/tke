import React from "react";
import { Omit } from "../_type";
import { CheckProps } from "../check";
import { CheckboxGroup } from "./CheckboxGroup";
/**
 * Checkbox 组件所接收的参数
 */
export interface CheckboxProps extends Omit<CheckProps, "type"> {
}
export declare const Checkbox: React.FunctionComponent<CheckboxProps & React.RefAttributes<HTMLLabelElement>> & {
    Group: typeof CheckboxGroup;
};
