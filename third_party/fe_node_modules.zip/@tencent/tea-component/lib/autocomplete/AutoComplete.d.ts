import React from "react";
import { TriggerProps, PopoverProps } from "../popover";
import { StyledProps, Combine } from "../_type";
import { SelectOptionWithGroup } from "../select";
import { ControlledProps } from "../form";
export interface AutoCompleteProps extends Combine<StyledProps, ControlledProps<string>> {
    /**
     * 下拉选项列表
     */
    options?: SelectOptionWithGroup[];
    /**
     * 分组
     */
    groups?: {
        [groupKey: string]: React.ReactNode;
    };
    /**
     * `options` 为空时展示，可使用字符串或 [StatusTip](/component/tips) 相关组件
     */
    tips?: React.ReactNode;
    /**
     * 展示为高亮的关键词
     */
    keyword?: string;
    /**
     * 要包裹的输入组件
     */
    children?: (ref: React.Ref<HTMLInputElement | HTMLTextAreaElement>, context: {
        close: () => void;
    }) => React.ReactNode;
    /**
     * `options` 滚动至底部的回调
     */
    onScrollBottom?: (event: React.UIEvent) => void;
    /**
     * 是否在父容器滚动时关闭
     * @default true
     */
    closeOnScroll?: PopoverProps["closeOnScroll"];
}
export declare function AutoComplete(props: AutoCompleteProps): JSX.Element;
export declare namespace AutoComplete {
    var defaultLabelAlign: string;
}
export declare function AutoCompleteTrigger({ setVisible, openDelay, closeDelay, render, }: TriggerProps): JSX.Element;
