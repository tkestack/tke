/// <reference types="react" />
import { Moment } from "moment";
import { StyledProps, Combine } from "../_type";
import { ControlledProps } from "../form/controlled";
import { RangeDateType } from "./DateProps";
export interface CalendarProps extends Combine<StyledProps, ControlledProps<Moment>> {
    /**
     * 允许选择的日期范围，可同时使用 `disabledDate` 实现更精细控制
     */
    range?: RangeDateType;
    /**
     * 可选的日期范围
     */
    disabledDate?: (date: Moment) => boolean;
}
export declare function Calendar(props: CalendarProps): JSX.Element;
