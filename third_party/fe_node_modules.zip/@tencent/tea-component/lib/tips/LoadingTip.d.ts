import React from "react";
import { StyledProps } from "../_type";
export interface LoadingTipProps extends StyledProps {
    /**
     * 加载文案
     * @default "加载中..."
     */
    loadingText?: React.ReactNode;
    /**
     * 隐藏图标
     * @default false
     */
    hideIcon?: boolean;
}
export declare function LoadingTip(props: LoadingTipProps): JSX.Element;
