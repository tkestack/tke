import React from "react";
import { StyledProps } from "../_type";
export interface BreadcrumbProps extends StyledProps {
    /**
     * 导航内容
     */
    children?: React.ReactNode;
    /**
     * 较大字号的样式，可用于 Layout.Content 标题处
     */
    large?: boolean;
}
export declare const Breadcrumb: (({ large, children, className, style }: BreadcrumbProps) => JSX.Element) & {
    Item: typeof BreadcrumbItem;
};
interface BreadcrumbItemProps extends StyledProps {
    current?: boolean;
    children?: React.ReactNode;
}
export declare function BreadcrumbItem({ current, children, className, style, }: BreadcrumbItemProps): JSX.Element;
export {};
