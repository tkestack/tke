import React from "react";
import { RectProps } from "../_chart/type";
export interface BasicLineProps extends RectProps {
    /**
     * 状态提示，可使用 StatusTip 相关组件
     */
    tips?: React.ReactNode;
    /**
     * Tips 遮罩层样式
     */
    tipsStyle?: React.CSSProperties;
}
export declare function BasicLine(props: BasicLineProps): JSX.Element;
