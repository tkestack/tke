import React from "react";
export interface ProgressProps {
    /**
     * 进度条类型
     *
     * @default "line"
     */
    type?: "line" | "circle";
    /**
     * 百分比，取值 \[0, 100\]
     *
     * @default 0
     */
    percent?: number;
    /**
     * 描述内容
     *
     * **环形进度条中默认展示当前进度百分比**
     *
     * @docType React.ReactNode | ((percent: number) => React.ReactNode);
     */
    text?: React.ReactNode | ((percent: number) => React.ReactNode);
    /**
     * 进度条下提示内容
     *
     * 仅在 `type = "circle"` 时有效
     */
    tips?: React.ReactNode;
    /**
     * 进度条样式
     *
     * **默认将在 `percent` 小于 100 时使用 `default`，等于 100 时使用 `success`**
     */
    theme?: "default" | "success" | "danger";
}
export declare function Progress({ type, percent, text, tips, theme, }: ProgressProps): JSX.Element;
