import React from "react";
import { AffixProps } from "./AffixProps";
export interface AffixHandles {
    update: () => void;
}
export declare const Affix: React.ForwardRefExoticComponent<AffixProps & React.RefAttributes<AffixHandles>>;
