import { AffixTargetType } from "./AffixProps";
export declare function addListener(target: AffixTargetType, affixId: string, onChange: (event: Event) => void): void;
export declare function removeListener(target: AffixTargetType, affixId: string): void;
