import { AffixProps, AffixTargetType } from "./AffixProps";
export declare function getTarget(target: AffixProps["target"]): AffixTargetType;
export declare function getRect(target: AffixTargetType): ClientRect;
export declare function getFixed(target: AffixProps["target"], placeholder: HTMLDivElement, offset: number, isTop?: boolean): number;
export declare function throttle(fn: Function): (...args: any[]) => void;
