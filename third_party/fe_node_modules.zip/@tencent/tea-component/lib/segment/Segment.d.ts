import React from "react";
import { ControlledProps } from "../form/controlled";
import { Combine, StyledProps } from "../_type";
import { SegmentOption } from "./SegmentOption";
export interface SegmentProps extends Combine<StyledProps, ControlledProps<string>> {
    /**
     * Segment 中选项
     */
    options: SegmentOption[];
    /**
     * 分组
     */
    groups?: {
        [groupKey: string]: React.ReactNode;
    };
    /**
     * 是否为无边框样式
     * @default false
     */
    rimless?: boolean;
}
export declare function Segment(props: SegmentProps): JSX.Element;
export declare namespace Segment {
    var defaultLabelAlign: string;
}
