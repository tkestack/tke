import React from "react";
import { ControlledProps } from "../form/controlled";
import { SegmentOption } from "./SegmentOption";
import { Combine, StyledProps } from "../_type";
export interface SegmentMultipleProps extends Combine<StyledProps, ControlledProps<string[]>> {
    options?: SegmentOption[];
    /**
     * 分组
     */
    groups?: {
        [groupKey: string]: React.ReactNode;
    };
    /**
     * 是否为无边框样式
     * @default false
     */
    rimless?: boolean;
}
export declare function SegmentMultiple(props: SegmentMultipleProps): JSX.Element;
export declare namespace SegmentMultiple {
    var defaultLabelAlign: string;
}
