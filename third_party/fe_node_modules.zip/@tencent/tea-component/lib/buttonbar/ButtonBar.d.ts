import React from "react";
import { StyledProps } from "../_type";
export interface ButtonBarItem {
    name: string | JSX.Element;
    value: number | string;
    icon?: string | JSX.Element;
    disabled?: boolean;
    tip?: string;
}
export interface ButtonBarProps extends StyledProps {
    list: ButtonBarItem[];
    selected?: ButtonBarItem | number | string;
    onSelect?: (value: ButtonBarItem) => void;
}
export declare const ButtonBar: React.ForwardRefExoticComponent<ButtonBarProps & React.RefAttributes<HTMLDivElement>>;
