import React from "react";
export interface RegionPanelProps {
    /**
     * 地域选择面板的内容
     *
     * 可以包含 `RegionPanel.Head` 及 `RegionPanel.Column`
     */
    children?: React.ReactNode;
}
/**
 * 地域选择布局面板
 */
export declare function RegionPanel({ children }: RegionPanelProps): JSX.Element;
export declare namespace RegionPanel {
    var Head: typeof RegionPanelHead;
    var Column: typeof RegionPanelColumn;
    var Group: typeof RegionPanelGroup;
}
interface RegionPanelHeadProps {
    /**
     * 地域面板头部，可以用于包含所有地域的选项
     */
    children: React.ReactNode;
}
declare function RegionPanelHead({ children }: RegionPanelHeadProps): JSX.Element;
interface RegionPanelColumnProps {
    /**
     * 包含地域分组 `RegionPanel.Group`
     */
    children: React.ReactNode;
}
declare function RegionPanelColumn({ children }: RegionPanelColumnProps): JSX.Element;
interface RegionPanelGroupProps {
    /**
     * 地域分组名称，如果 "中国大陆"
     */
    name?: string;
    /**
     * 地域分组，应该包含一个或多个地域选项 `RegionOption`
     */
    children?: React.ReactNode;
}
declare function RegionPanelGroup({ name, children }: RegionPanelGroupProps): JSX.Element;
export {};
