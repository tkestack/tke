import React from "react";
import { ControlledProps } from "../form/controlled";
import { Combine, Omit } from "../_type";
import { DropdownProps, CommonDropdownProps } from "../dropdown";
export interface RegionSelectProps extends Combine<CommonDropdownProps, ControlledProps<string>, Omit<DropdownProps, "button" | "children" | "appearence">> {
    /**
     * 下拉内容，应该使用 `RegionPanel`
     */
    children?: React.ReactNode;
    /**
     * 在下拉按钮显示的额外信息
     */
    moreInfo?: React.ReactNode;
}
export declare function RegionSelect(props: RegionSelectProps): JSX.Element;
export declare namespace RegionSelect {
    var defaultLabelAlign: string;
}
