import React from "react";
import { Omit } from "../_type";
import { CheckProps } from "../check";
import { RadioGroup } from "./RadioGroup";
/**
 * Radio 组件所接收的属性
 */
export interface RadioProps extends Omit<CheckProps, "type" | "indeterminate"> {
}
export declare const Radio: React.FunctionComponent<RadioProps & React.RefAttributes<HTMLLabelElement>> & {
    Group: typeof RadioGroup;
};
