import React from "react";
import { Tab } from "./TabProps";
export interface TabBarProps {
    activeId: string;
    tabs: Tab[];
    onActive: (tab: Tab, evt: React.SyntheticEvent) => void;
    addon: React.ReactNode;
    vertical: boolean;
    maxHeight: number;
    tabBarRender: (children: JSX.Element, tab: Tab) => JSX.Element;
}
export declare function TabBar({ activeId, tabs, onActive, addon, vertical, maxHeight, tabBarRender, }: TabBarProps): JSX.Element;
