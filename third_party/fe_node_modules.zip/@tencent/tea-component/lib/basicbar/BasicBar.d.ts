import React from "react";
import { RectProps } from "../_chart/type";
import { Omit } from "../_type";
export interface BasicBarProps extends Omit<RectProps, "size"> {
    /**
     * 每根柱的宽度
     */
    size?: number;
    /**
     * 状态提示，可使用 StatusTip 相关组件
     */
    tips?: React.ReactNode;
    /**
     * Tips 遮罩层样式
     */
    tipsStyle?: React.CSSProperties;
}
export declare function BasicBar(props: BasicBarProps): JSX.Element;
