export { InputNumber, InputNumberProps } from "./InputNumber";
