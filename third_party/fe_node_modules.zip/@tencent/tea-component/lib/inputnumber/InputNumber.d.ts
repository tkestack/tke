/// <reference types="react" />
import { StyledProps, Combine } from "../_type";
import { ControlledProps } from "../form/controlled";
export interface InputNumberProps extends Combine<StyledProps, ControlledProps<number>> {
    /** 最小值 */
    min?: number;
    /** 最大值 */
    max?: number;
    /**
     * 使用按钮增减时的步长
     * @default 1
     */
    step?: number;
    /** 单位 */
    unit?: string;
    /** 是否可用 */
    disabled?: boolean;
    /**
     * 精度（保留小数位数）
     */
    precision?: number;
}
/**
 * 数字输入组件
 */
export declare const InputNumber: ((props: InputNumberProps) => JSX.Element) & {
    defaultLabelAlign: string;
};
