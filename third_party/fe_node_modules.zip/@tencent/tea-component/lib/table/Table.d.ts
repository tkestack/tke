import React from "react";
import { TableProps } from "./TableProps";
import * as addons from "./addons";
export declare const Table: (<T>(props: TableProps<T>) => JSX.Element) & {
    addons: typeof addons;
    ActionPanel: React.ForwardRefExoticComponent<import("../_util/create-rocket").RocketProps & React.RefAttributes<HTMLElement>>;
};
