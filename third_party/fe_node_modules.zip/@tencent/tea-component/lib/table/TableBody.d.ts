import React from "react";
import { TableProps } from "./TableProps";
export declare const TableBody: React.ForwardRefExoticComponent<TableProps<any> & {
    boxStyle?: React.CSSProperties;
    onScrollCapture?: (event: React.UIEvent<HTMLDivElement>) => void;
} & React.RefAttributes<HTMLDivElement>>;
