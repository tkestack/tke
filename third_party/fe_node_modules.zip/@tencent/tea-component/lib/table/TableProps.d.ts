import React from "react";
export interface TableProps<Record = any> {
    /**
     * 表格的列配置，必须提供
     */
    columns: TableColumn<Record>[];
    /**
     * 表格的数据，可以是任意类型
     */
    records?: Record[];
    /**
     * 提供数据的 `key` 字段名，或者提供回调，根据每个数据提供 `key` 值。注意两点：
     *
     *  - 不同的数据不要提供重复的 `key` 值，否则只会渲染一条，与数据不一致
     *  - 如果不提供 `rowKey`，则会用索引位置生成 `key`，在某些场景下，会导致性能问题，所以，总是提供你的 `rowKey`
     */
    recordKey?: (Record extends {
        [key: string]: any;
    } ? keyof Record : string) | ((record: Record, recordIndex: number) => string);
    /**
     * 如何判定给定的记录是否禁用（禁用的记录将不可选）
     * */
    rowDisabled?: (record: Record) => boolean;
    /**
     *
     * 可以为每一行指定 `className`
     */
    rowClassName?: (record: Record) => string;
    /**
     * 表格顶部显示的内容，可以用于显示 `loading`、数据为空等
     */
    topTip?: React.ReactNode;
    /**
     * 表格底部显示的内容，可用于显示记录创建等
     * */
    bottomTip?: React.ReactNode;
    /**
     * 使用的表格插件列表
     */
    addons?: TableAddon[];
    /**
     * 是否带全边框
     * @default false
     */
    bordered?: boolean;
    /**
     * 是否展示为紧凑样式
     * @default false
     */
    compact?: boolean;
    /**
     * 禁用 Hover 时高亮
     * @default false
     */
    disableHoverHighlight?: boolean;
    /**
     * 禁用默认的文本溢出样式
     *
     * 也可以通过 `columns` 中 `render` 对各列进行更精细的控制
     *
     * @default false
     */
    disableTextOverflow?: boolean;
    /**
     * 隐藏表头
     * @default false
     */
    hideHeader?: boolean;
    /**
     * 表格内容展示为上对齐，默认居中对齐
     * @default false
     */
    verticalTop?: boolean;
}
export interface TableColumn<Record = any> {
    /**
     * 列标识
     */
    key: string;
    /**
     * 表头
     * @docType React.ReactNode | ((column: TableColumn<Record>) => React.ReactNode)
     */
    header: React.ReactNode | ((column: TableColumn<Record>) => React.ReactNode);
    /**
     * 数据渲染方法
     * 如果不提供渲染方法，会尝试查找数据中 `key` 属性所指向的字段
     *
     * @param record 对应的数据记录
     * @param column 正在渲染的列
     * @param rowKey 当前渲染行的 `key` 值
     * @param recordIndex 数据记录在记录集中的索引
     */
    render?: (record: Record, rowKey: string, recordIndex: number, column: TableColumn<Record>) => React.ReactNode;
    /**
     * 列宽度，可以指定 CSS 属性或数字 (单位：px)
     */
    width?: string | number;
    /**
     * 对齐规则，左中右
     */
    align?: "left" | "center" | "right";
}
export interface TableAddon<Record = any> {
    /**
     * 在表格渲染前，可以返回更改的 props
     */
    onInjectProps?: TableMiddleware<TableProps<Record>>;
    /**
     * 对于每一行 (`<tr>`) 的渲染结果，返回变更的结果。
     * 变更的结果可以在原结果前后插入新行
     */
    onInjectRow?: TableMiddleware<TableRowRender<Record>>;
    /**
     * 对于每一列的渲染结果，返回变更的结果
     */
    onInjectColumn?: TableMiddleware<TableColumnRender<Record>>;
    /**
     * 变更 `<tbody>` 的渲染结果
     */
    onInjectBody?: TableMiddleware<TableBodyRender<Record>>;
    /**
     * 变更 `<thead>` 的渲染结果
     */
    onInjectHead?: TableMiddleware<(props: TableProps<Record>) => JSX.Element>;
    /**
     * 变更 `<table>` 的渲染结果
     */
    onInjectTable?: TableMiddleware<(props: TableProps<Record>) => JSX.Element>;
}
export interface TableMiddleware<T> {
    (next: T): T;
}
export interface TableBodyRender<Record = any> {
    (records: Record[], columns: TableColumn<Record>[], topTip: React.ReactNode, bottomTip: React.ReactNode): JSX.Element;
}
export interface TableRowRender<Record = any> {
    (record: Record, rowKey: string, recordIndex: number, columns: TableColumn<Record>[]): TableRowRenderResult;
}
export interface TableRowRenderResult {
    prepends: JSX.Element[];
    row: JSX.Element;
    appends: JSX.Element[];
}
export interface TableColumnRender<Record = any> {
    (record: Record, rowKey: string, recordIndex: number, column: TableColumn<Record>): TableColumnRenderResult;
}
export interface TableColumnRenderResult {
    props: React.TdHTMLAttributes<HTMLTableDataCellElement>;
    children: React.ReactNode;
}
export interface RowRenderContext<Record = any> {
    /**
     * 原内容
     */
    children: React.ReactNode;
    /**
     * 当前行记录
     */
    record: Record;
    /**
     * 当前行 Key
     */
    rowKey: string;
    /**
     * 当前行序号
     */
    recordIndex: number;
    /**
     * 当前行是否被禁用
     */
    disabled: boolean;
    /**
     * 当前行深度
     */
    depth?: number;
}
