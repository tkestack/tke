import React from "react";
import { TableProps } from "./TableProps";
export declare const TableHead: React.ForwardRefExoticComponent<TableProps<any> & {
    boxStyle?: React.CSSProperties;
} & React.RefAttributes<HTMLDivElement>>;
