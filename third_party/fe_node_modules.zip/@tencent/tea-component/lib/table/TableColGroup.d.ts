/// <reference types="react" />
import { TableColumn } from "./TableProps";
export interface TableColGroupProps {
    columns: TableColumn[];
}
export declare function TableColGroup({ columns }: TableColGroupProps): JSX.Element;
