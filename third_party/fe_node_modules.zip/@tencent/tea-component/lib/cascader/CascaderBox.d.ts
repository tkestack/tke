/// <reference types="react" />
import { CascaderBoxProps, CascaderData, CascaderOption } from "./CascaderProps";
export declare function getOptions(data: CascaderData, valueList: CascaderBoxProps["value"]): CascaderOption[];
export declare function CascaderBox({ data, value, onChange, onLoad, onClose, changeOnSelect, className, style, scheduleUpdate, }: CascaderBoxProps & {
    scheduleUpdate: () => void;
}): JSX.Element;
