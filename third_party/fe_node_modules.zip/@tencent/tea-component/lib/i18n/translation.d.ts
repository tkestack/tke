import { zh_cn } from "./locale/zh_cn";
declare type Locale = typeof zh_cn;
export interface Translation extends Locale {
}
declare const translationMap: {
    zh_cn: Translation;
    zh: Translation;
    en_us: Translation;
    en: Translation;
    ja: Translation;
    jp: Translation;
    ko: Translation;
};
export declare function setLocale(locale: keyof typeof translationMap, moment?: typeof import("moment")): void;
export declare function useTranslation(moment?: typeof import("moment")): Translation;
export declare function getTranslation(): Translation;
export interface TranslationProps {
    t?: Translation;
}
export {};
