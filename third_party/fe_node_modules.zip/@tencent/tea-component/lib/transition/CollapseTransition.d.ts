/// <reference types="react" />
import { TransitionProps } from "react-transition-group/Transition";
export interface CollapseTransitionProps extends Partial<TransitionProps> {
    /**
     * 动画元素目标高度
     */
    height?: number;
}
export declare function CollapseTransition({ height, timeout, ...rest }: CollapseTransitionProps): JSX.Element;
