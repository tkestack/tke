/// <reference types="react" />
import { TransitionProps } from "react-transition-group/Transition";
import { Position } from "../_util/transition";
export interface SlideTransitionProps extends Partial<TransitionProps> {
    /**
     * 从哪个位置进入，相对 DOM 本身的位置 [x, y]。默认为 [0, -30]
     */
    from?: Position;
    /**
     * 消失到哪个位置，默认和 from 相等
     */
    to?: Position;
}
export declare function SlideTransition({ from, to, timeout, ...rest }: SlideTransitionProps): JSX.Element;
