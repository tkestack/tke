import React, { Ref } from "react";
import { StyledProps } from "../_type";
/**
 * 支持当前 `parent` 标签原生支持的属性
 */
export interface TextProps<P extends keyof JSX.IntrinsicElements> extends StyledProps {
    /**
     * 使用什么标签来渲染文本，对应标签原生属性可透传至组件
     * @default span
     */
    parent?: P;
    /**
     * 文本的水平居中方式
     */
    align?: "left" | "center" | "right" | "justify";
    /**
     * 文本的垂直居中方式
     */
    verticalAlign?: "baseline" | "top" | "middle" | "bottom" | "text-top" | "text-bottom";
    /**
     * 指定 `overflow` 为 `true` 对文本进行单行溢出控制，宽度溢出的文本会以 ... 显示
     */
    overflow?: boolean;
    /**
     * 指定 `nowrap` 为 `true` 强制文本不换行，超长溢出
     */
    nowrap?: boolean;
    /**
     * 内容所使用的 `tooltip`
     */
    tooltip?: React.ReactNode;
    /**
     * 文本的颜色主题
     */
    theme?: "text" | "label" | "weak" | "strong" | "primary" | "success" | "warning" | "danger";
    /**
     * 文本的背景颜色主题
     */
    bgTheme?: "success" | "warning" | "danger";
    /**
     * 文本浮动方式，配置 `clear` 以清除浮动
     */
    float?: "left" | "right" | "clear";
    /**
     * 重置文字 fontSize
     *
     * @default false
     */
    reset?: boolean;
    /**
     * 文本内容
     */
    children?: React.ReactNode;
}
export declare type TextPropsType<P extends keyof JSX.IntrinsicElements> = JSX.IntrinsicElements[P] & TextProps<P>;
declare function TextRaw<P extends keyof JSX.IntrinsicElements = "span">(props: TextPropsType<P>, ref: Ref<JSX.IntrinsicElements[P]>): JSX.Element;
export declare const Text: typeof TextRaw;
export {};
