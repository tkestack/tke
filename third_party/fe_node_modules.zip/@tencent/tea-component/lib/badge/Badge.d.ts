import React from "react";
import { StyledProps } from "../_type";
export interface BadgeProps extends StyledProps {
    /**
     * 颜色主题
     *
     * @default "default"
     */
    theme?: "default" | "success" | "warning" | "danger";
    /**
     * 是否为深色背景
     *
     * @default false
     */
    dark?: boolean;
    /**
     * 徽章中内容
     */
    children?: React.ReactNode;
}
export declare function Badge({ theme, dark, children, className, style, }: BadgeProps): JSX.Element;
