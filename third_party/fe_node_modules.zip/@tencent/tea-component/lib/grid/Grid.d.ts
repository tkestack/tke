import React from "react";
import { StyledProps } from "../_type";
export interface RowProps extends StyledProps {
    /**
     * 列之间的间隙
     * @default 20
     */
    gap?: number;
    /**
     * 栅格对齐方式，不传则栅格等高
     */
    verticalAlign?: "top" | "middle" | "bottom";
    /**
     * 是否展示分割线
     * @default false
     */
    showSplitLine?: boolean;
    /**
     * 包括的栅格列，请使用 <Col /> 作为子节点
     */
    children?: ColChild | ColChild[];
}
export interface ColProps extends StyledProps {
    /**
     * 栅格占位格数
     */
    span?: number;
    /**
     * 栅格单元中内容
     */
    children?: React.ReactNode;
}
declare type ColChild = React.ReactElement<ColProps, typeof Col>;
export declare function Row({ gap, verticalAlign, showSplitLine, children, className, style, }: RowProps): JSX.Element;
export declare function Col({ span, className, style, children }: ColProps): JSX.Element;
export {};
