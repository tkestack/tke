/// <reference types="react" />
import { DateChangeContext } from "../calendar/DateProps";
export interface SelectProps {
    /**
     * 当前选择的值
     */
    value: number;
    /**
     * 起始值
     */
    from?: number;
    /**
     * 结束值
     */
    to: number;
    /**
     * 步长
     */
    step?: number;
    /**
     * 禁选范围
     */
    disabledValues?: number[];
    /**
     * 变化回调
     */
    onChange: (value: number, context: DateChangeContext) => void;
}
export declare function TimeSelect({ value, from, to, step, disabledValues, onChange, }: SelectProps): JSX.Element;
