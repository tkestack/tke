/**
 * 获取精度
 */
export declare function getPrecision(value: number): number;
