export declare function callBoth<T extends (...args: any[]) => any>(...fns: T[]): T;
