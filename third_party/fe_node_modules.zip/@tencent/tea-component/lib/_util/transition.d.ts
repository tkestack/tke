/**
 * Animation transition can be used in TransitionGroup
 * */
export interface Transition {
    classNames: string;
    timeout: {
        enter: number;
        exit: number;
    };
    mountOnEnter: boolean;
    unmountOnExit: boolean;
}
export declare type Position = [number, number];
/**
 * generate a fade transition, enjoy it with TransitionGroup
 * */
export declare function fade(visibleOpacity?: number, enterTimeout?: number, leaveTimeout?: number): Transition;
/**
 * generate a slide transition, enjoy it with TransitionGroup
 * */
export declare function slide(enterPosition?: Position, leavePosition?: Position, enterTimeout?: number, leaveTimeout?: number): Transition;
/**
 * generate a slide transition, enjoy it with TransitionGroup
 * */
export declare function collapse(targetHeight: number, enterTimeout?: number, leaveTimeout?: number): Transition;
/**
 * generate a scale transition, enjoy it with TransitionGroup
 * */
export declare function scale(enterScale?: number, exitScale?: number, enterTimeout?: number, leaveTimeout?: number, origin?: string): Transition;
