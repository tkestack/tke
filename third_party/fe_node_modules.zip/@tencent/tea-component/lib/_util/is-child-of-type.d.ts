import React from "react";
export declare function isChildOfType(child: React.ReactNode, type: "text"): child is string;
export declare function isChildOfType(child: React.ReactNode, type: "number"): child is number;
export declare function isChildOfType<T extends keyof JSX.IntrinsicElements>(child: React.ReactNode, type: T): child is React.ReactComponentElement<T>;
export declare function isChildOfType<T extends React.ElementType>(child: React.ReactNode, type: T): child is React.ReactElement<T extends React.ElementType<infer P> ? P : any, T>;
