export declare function getScrollBarSize(): number;
