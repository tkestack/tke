/// <reference types="react" />
/**
 * 提供一个 DOM，在 DOM 的外部点击之后，会触发回调函数
 * @param domRefs 给定一个或多个 DOM 的 ref，在此 DOM 之外点击认为是外部点击
 * @param once 是否只触发一次外部点击事件，默认为 true
 */
export declare function useOutsideClick(domRefs: React.RefObject<HTMLElement> | React.RefObject<HTMLElement>[], enabled?: boolean): {
    listen: (handle: (evt: MouseEvent) => void) => {
        portalInterceptProps: {
            onMouseDown: (evt: import("react").MouseEvent<Element, MouseEvent>) => import("react").MouseEvent<Element, MouseEvent>;
        };
    };
    remove: () => void;
};
