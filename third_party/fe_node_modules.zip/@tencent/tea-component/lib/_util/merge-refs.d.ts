import { Ref } from "react";
export declare function mergeRefs<T>(...refs: Ref<T>[]): (instance: T) => void;
