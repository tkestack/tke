import React from "react";
export declare function getPropsFromChildrenByType<P>(children: React.ReactNode, component: React.ComponentType<P>): P[];
