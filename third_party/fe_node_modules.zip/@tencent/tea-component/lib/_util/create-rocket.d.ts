import React, { ReactNode } from "react";
import { StyledProps } from "../_type";
export interface RocketProps extends StyledProps {
    /**
     * 组件内容
     */
    children?: ReactNode;
}
/**
 * 快速创建 DOM 容器组件
 * @param displayName 组件名称
 * @param paths 组件的容器路径，如 div.tea-card__body
 */
export declare const createRocket: <P extends RocketProps = RocketProps>(displayName: string, ...paths: string[]) => React.ForwardRefExoticComponent<React.PropsWithoutRef<P> & React.RefAttributes<HTMLElement>>;
