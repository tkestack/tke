export declare function hashString(str: any): number;
