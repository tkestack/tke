export declare function useVisibleTransition(visible: boolean): {
    /**
     * 内容是否应该渲染
     */
    shouldContentRender: boolean;
    /**
     * 内容是否应该显示
     */
    shouldContentEnter: boolean;
    /**
     * 内容退出完成后回调
     */
    onContentExit: () => void;
};
