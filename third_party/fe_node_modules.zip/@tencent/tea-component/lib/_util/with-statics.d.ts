/// <reference types="react" />
export declare function withStatics<C extends React.ComponentType<any>, S = {}>(component: C, statics?: S): C & S;
