import { RefObject } from "react";
export declare function useParentScroll(elementRef: RefObject<HTMLElement>, onScroll: (event: Event) => void): void;
