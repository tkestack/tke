export declare function uuid(): string;
