export interface ProgressInfo {
    /**
     * 文件总大小
     */
    total: number;
    /**
     * 已上传部分大小
     */
    loaded: number;
    /**
     * 百分比
     */
    percent: number;
}
export interface UploadEventContext {
    /**
     * 进度事件
     */
    event: ProgressEvent;
    /**
     * XHR 对象
     */
    xhr: XMLHttpRequest;
    /**
     * 当前文件
     */
    file: File;
}
export interface UploadOption {
    action: string;
    file: File;
    filename: string;
    data?: object;
    headers?: object;
    withCredentials?: boolean;
    onProgress?: (progress: ProgressInfo, context: UploadEventContext) => void;
    onSuccess?: (result: object | string, context: UploadEventContext) => void;
    onError?: (error: Error, context: UploadEventContext) => void;
}
export declare function upload({ action, file, filename, data, headers, withCredentials, onProgress, onSuccess, onError, }: UploadOption): XMLHttpRequest;
