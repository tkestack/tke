import React from "react";
import { BubbleContentProps } from "./BubbleContent";
import { PopoverProps } from "../popover";
export interface BubbleProps extends BubbleContentProps {
    /**
     * 气泡内容
     *
     * 如果气泡内容传入 `null` 或者 `undefined`，则不会出现气泡
     */
    content?: React.ReactNode;
    /**
     * 触发方式
     * @default "hover"
     */
    trigger?: PopoverProps["trigger"];
    /**
     * 传入 `visible` 则表示使用受控模式来控制弹出气泡的显示，请处理 `onVisibleChange` 方法
     */
    visible?: PopoverProps["visible"];
    /**
     * 处理 `visible` 变化的情况
     */
    onVisibleChange?: PopoverProps["onVisibleChange"];
    /**
     * 弹出层的样式
     */
    overlayStyle?: PopoverProps["overlayStyle"];
    /**
     * 打开延时
     */
    openDelay?: PopoverProps["openDelay"];
    /**
     * 关闭延时
     */
    closeDelay?: PopoverProps["closeDelay"];
    /**
     * 是否在父容器滚动时关闭
     * @default false
     */
    closeOnScroll?: PopoverProps["closeOnScroll"];
    /**
     * 是否在 resize 和 scroll 发生时更新位置
     */
    updateOnDimensionChange?: PopoverProps["updateOnDimensionChange"];
    /**
     * 自定义定位参考信息
     * @see https://github.com/FezVrasta/react-popper#usage-without-a-reference-htmlelement
     */
    referenceElement?: PopoverProps["referenceElement"];
    /**
     * 弹出位置距离参考位置的偏移量
     * @default 10
     */
    placementOffset?: PopoverProps["placementOffset"];
    /**
     * 出现动画滑动距离
     */
    animationScaleFrom?: PopoverProps["animationScaleFrom"];
    /**
     * 动画时长
     */
    transitionTimeout?: PopoverProps["transitionTimeout"];
    /**
     * 导致位置更新的依赖列表，可用于性能优化
     *
     * @default [content]
     */
    updateDeps?: any[];
}
export declare function Bubble({ visible, onVisibleChange, content, trigger, overlayStyle, openDelay, closeDelay, closeOnScroll, updateOnDimensionChange, transitionTimeout, referenceElement, placement, placementOffset, animationScaleFrom, children, updateDeps, ...bubbleProps }: BubbleProps): JSX.Element;
