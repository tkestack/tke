import React, { HTMLAttributes } from "react";
import { Placement } from "popper.js";
export interface BubbleContentProps extends HTMLAttributes<HTMLDivElement> {
    /**
     * Bubble 放置的位置，将影响三角的朝向和位置
     * @default "top"
     */
    placement?: Placement;
    /**
     * 指定 `error = true` 则渲染为红色，指示错误内容
     * @default false
     */
    error?: boolean;
    /**
     * 指定 `dark = true` 则渲染为黑色
     * @default false
     */
    dark?: boolean;
    /**
     * 指定 `tooltip = true` 则渲染为 Tooltip 样式
     * @default false
     */
    tooltip?: boolean;
}
export declare const BubbleContent: React.ForwardRefExoticComponent<BubbleContentProps & React.RefAttributes<HTMLDivElement>>;
