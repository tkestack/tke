import React from "react";
import { InferProps, StyledProps } from "../_type";
export interface LayoutContentHeaderProps extends StyledProps {
    /**
     * 是否展示返回按钮
     *
     * @default false
     */
    showBackButton?: boolean;
    /**
     * 返回按钮点击回调
     */
    onBackButtonClick?: (event: React.MouseEvent) => void;
    /**
     * 标题
     */
    title?: React.ReactNode;
    /**
     * 小标题（说明文字）
     */
    subtitle?: React.ReactNode;
    /**
     * 标题后区域内容
     */
    children?: React.ReactNode;
    /**
     * 操作区内容
     */
    operation?: React.ReactNode;
}
export declare function LayoutContentHeader({ showBackButton, onBackButtonClick, title, subtitle, children, operation, className, style, }: LayoutContentHeaderProps): JSX.Element;
export interface LayoutContentBodyProps extends StyledProps {
    /**
     * 是否为全屏
     *
     * @default false
     */
    full?: boolean;
    /**
     * 内容
     */
    children?: React.ReactNode;
}
export declare function LayoutContentBody({ full, children, className, style, }: LayoutContentBodyProps): JSX.Element;
export declare const LayoutContent: React.ForwardRefExoticComponent<import("../_util/create-rocket").RocketProps & React.RefAttributes<HTMLElement>> & {
    Header: typeof LayoutContentHeader;
    Body: typeof LayoutContentBody;
    Footer: React.ForwardRefExoticComponent<import("../_util/create-rocket").RocketProps & React.RefAttributes<HTMLElement>>;
};
export interface LayoutContentProps extends InferProps<typeof LayoutContent> {
}
