import React from "react";
import { RocketProps } from "../_util/create-rocket";
import { InferProps } from "../_type";
declare function LayoutBody({ className, style, children }: RocketProps): JSX.Element;
export declare const Layout: React.ForwardRefExoticComponent<RocketProps & React.RefAttributes<HTMLElement>> & {
    Header: React.ForwardRefExoticComponent<RocketProps & React.RefAttributes<HTMLElement>>;
    Body: typeof LayoutBody;
    Footer: React.ForwardRefExoticComponent<RocketProps & React.RefAttributes<HTMLElement>>;
    Sider: React.ForwardRefExoticComponent<RocketProps & React.RefAttributes<HTMLElement>>;
    Content: React.ForwardRefExoticComponent<RocketProps & React.RefAttributes<HTMLElement>> & {
        Header: typeof import("./LayoutContent").LayoutContentHeader;
        Body: typeof import("./LayoutContent").LayoutContentBody;
        Footer: React.ForwardRefExoticComponent<RocketProps & React.RefAttributes<HTMLElement>>;
    };
};
export interface LayoutProps extends InferProps<typeof Layout> {
}
export {};
