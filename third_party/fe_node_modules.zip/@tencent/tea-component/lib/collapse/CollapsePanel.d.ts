import React from "react";
import { StyledProps } from "../_type";
export interface CollapsePanelProps extends StyledProps {
    /**
     * 面板唯一标识
     */
    id: string;
    /**
     * 头部标题
     */
    title?: React.ReactNode;
    /**
     * 头部标题
     */
    content?: React.ReactNode;
}
export declare function CollapsePanel({ id, title, content, className, style, }: CollapsePanelProps): JSX.Element;
