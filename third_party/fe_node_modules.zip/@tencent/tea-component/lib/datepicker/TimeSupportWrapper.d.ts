import React from "react";
import { Moment } from "moment";
import { CommonDatePickerProps } from "./DatePickerProps";
import { CalendarTableType, showTimeType, RangeDateType } from "../calendar/DateProps";
import { CalendarTableProps } from "../calendar/CalendarTable";
import { Omit } from "../_type";
interface TimeSupportWrapperProps extends CommonDatePickerProps {
    /**
     * Render Props
     */
    children: (props: any) => React.ReactNode;
    /**
     * 确定回调
     */
    onOk?: (event: React.MouseEvent) => void;
    /**
     * 当前展示的日历类型
     */
    type?: CalendarTableType | [CalendarTableType, CalendarTableType];
    /**
     * 日历类型改变回调
     */
    onTypeChange?: (types: CalendarTableType | [CalendarTableType, CalendarTableType]) => void;
    /**
     * 是否开启时间选择
     */
    showTime?: showTimeType<Moment | RangeDateType>;
}
export declare function TimeSupportWrapper({ onOk, children, ...props }: TimeSupportWrapperProps & Omit<CalendarTableProps, "type">): JSX.Element;
export {};
