/// <reference types="react" />
import { Moment } from "moment";
import { ControlledProps } from "../form/controlled";
import { Combine } from "../_type";
import { TimeDisabledProps } from "../timepicker/TimeProps";
import { showTimeType } from "../calendar/DateProps";
import { CommonDatePickerProps } from "./DatePickerProps";
export interface DatePickerProps extends Combine<CommonDatePickerProps, ControlledProps<Moment>> {
    /**
     * 是否开启时间选择
     */
    showTime?: showTimeType<Moment>;
    /**
     * 不可选的日期
     */
    disabledDate?: (date: Moment) => boolean;
    /**
     * 不可选的时间
     */
    disabledTime?: (date: Moment) => TimeDisabledProps;
}
export declare const DatePicker: ((props: DatePickerProps) => JSX.Element) & {
    RangePicker: ((props: import("./RangePicker").RangePickerProps) => JSX.Element) & {
        defaultLabelAlign: string;
    };
    MonthPicker: ((props: import("./MonthPicker").MonthPickerProps) => JSX.Element) & {
        defaultLabelAlign: string;
    };
    defaultLabelAlign: string;
};
