import React from "react";
import { StyledProps } from "../_type";
export interface StepperProps extends StyledProps {
    /**
     * 步骤条的类型
     *
     * - `default` - 默认类型，一般用于提示用户在多步操作中进行到哪个步骤
     * - `process` - 用于展示一个流程说明，水平布局
     * - `process-vertical` - 用于展示一个流程说明，垂直布局
     * - `process-vertical-dot` 用于展示一个流程说明，垂直布局，并且用圆点表示步骤
     * @default "default"
     */
    type?: "default" | "process" | "process-vertical" | "process-vertical-dot";
    /**
     * 步骤条中步骤列表
     */
    steps: Step[];
    /**
     * 当前激活步骤的 `key`
     */
    current?: string;
    /**
     * 仅用做展示的步骤条，没有进度状态区分
     *
     * @default false
     */
    readonly?: boolean;
    /**
     * 步骤标题展示不换行
     *
     * @default false
     */
    nowrap?: boolean;
}
export interface Step {
    /**
     * 步骤条中步骤项 `id`，在同一个步骤条中不允许重复
     */
    id: string;
    /**
     * 步骤说明文本
     */
    label?: React.ReactNode;
    /**
     * 关于当前步骤的详细说明，适用于垂直布局的步骤
     */
    detail?: React.ReactNode;
    /**
     * 当前步骤到下一个步骤的提示内容
     * 可以描述步骤的预计耗时，或者通过条件等
     */
    tip?: React.ReactNode;
}
export declare function Stepper({ type, steps, current, readonly, nowrap, className, style, }: StepperProps): JSX.Element;
