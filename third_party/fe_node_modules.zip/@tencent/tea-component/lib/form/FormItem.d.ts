import React from "react";
import { StyledProps } from "../_type";
import { FormControlProps } from "./FormControl";
export interface FormItemProps extends StyledProps {
    /**
     * HTML for 属性
     *
     * 包含 `label` 时生效
     */
    htmlFor?: string;
    /**
     * 表单项说明
     */
    label?: React.ReactNode;
    /**
     * 表单控件内容，可以容纳任意表单组件，如 Input, CheckGroup 等
     * 如果是只读表单内容，则可传入字符串
     */
    children?: React.ReactNode;
    /**
     * 表单项状态
     */
    status?: FormControlProps["status"];
    /**
     * 是否展示 icon
     * @default true
     */
    showStatusIcon?: boolean;
    /**
     * 表单项提示信息/校验信息
     */
    message?: FormControlProps["message"];
    /**
     * 控件和标签对齐方式
     *
     * - `auto` 自动根据传入的控件类型决定对齐方式
     * - `top` 增加间距以实现标签文本和控件内容顶部对齐
     * - `middle` 标签文本对齐到控件的中间
     *
     * @default "auto"
     */
    align?: "auto" | "top" | "middle";
    /**
     * 是否为必填项（样式）
     *
     * @default false
     */
    required?: boolean;
    /**
     * 表单控件后的装饰内容
     */
    suffix?: React.ReactNode;
}
export declare function FormItem({ htmlFor, label, children, className, style, status, message, align, required, showStatusIcon, suffix, }: FormItemProps): JSX.Element;
