export interface DelayVisibleHookOption {
    visible?: boolean;
    defaultVisible?: boolean;
    onVisibleChange?: (visible: boolean) => void;
}
/**
 * @hooks
 *
 * 延迟设置可见值
 */
export declare function useDelayVisible(option: DelayVisibleHookOption): {
    visible: boolean;
    setVisible: (nextVisible: boolean, delay?: number) => Promise<boolean>;
};
