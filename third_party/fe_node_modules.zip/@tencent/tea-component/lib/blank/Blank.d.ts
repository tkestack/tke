import React from "react";
import { BlankSteps } from "./BlankSteps";
import { StyledProps } from "../_type/StyledProps";
export interface BlankTheme {
    image: {
        background: string;
        gif: string;
    };
}
export interface BlankProps extends StyledProps {
    /**
     * 预置主题
     */
    theme?: "error" | "open" | "arrears" | "permission" | BlankTheme;
    /**
     * 描述
     */
    description?: string;
    /**
     * 操作区
     */
    operation?: React.ReactNode;
    /**
     * 操作区下方内容
     */
    extra?: React.ReactNode;
    /**
     * 描述与操作区间内容
     */
    children?: React.ReactNode;
}
export declare const Blank: (({ theme, description, operation, extra, children, className, style, }: BlankProps) => JSX.Element) & {
    Steps: typeof BlankSteps;
};
