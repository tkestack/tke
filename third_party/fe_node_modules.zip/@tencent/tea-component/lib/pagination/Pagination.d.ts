import React from "react";
import { StyledProps, Combine } from "../_type";
/** 表示分页信息 */
export interface PagingQuery {
    /** 页码：从 1 开始索引 */
    pageIndex?: number;
    /** 页长：表示每页记录数 */
    pageSize?: number;
}
export interface PaginationProps extends Combine<StyledProps, Partial<PagingQuery>> {
    /**
     * 必传，数据总个数，用于计算页数
     */
    recordCount: number;
    /**
     * 切换分页回调函数
     */
    onPagingChange?: (query: PagingQuery) => void;
    /**
     * 切换页长时，是否自动把页码重设为 1
     * @default true
     */
    isPagingReset?: boolean;
    /** 分页组件显示的说明信息，不传将渲染数据个数信息 */
    stateText?: React.ReactNode;
    /**
     * 支持的页长设置
     * @default [10, 20, 30, 50, 100, 200]
     */
    pageSizeOptions?: number[];
    /**
     * 是否显示状态文案
     * @default true
     */
    stateTextVisible?: boolean;
    /**
     * 是否显示页长选择
     * @default true
     */
    pageSizeVisible?: boolean;
    /**
     * 是否显示页码输入
     * @default true
     */
    pageIndexVisible?: boolean;
    /**
     * 是否显示切页按钮（上一页/下一页）
     * @default true
     */
    jumpVisible?: boolean;
    /**
     * 是否显示第一页和最后一页按钮
     * @default true
     */
    endJumpVisible?: boolean;
}
export declare function Pagination({ pageIndex, pageSize, pageSizeOptions, recordCount, onPagingChange, isPagingReset, stateText, stateTextVisible, pageSizeVisible, pageIndexVisible, jumpVisible, endJumpVisible, style, className, }: PaginationProps): JSX.Element;
export interface PaginationButtonProps {
    type: "pre" | "next" | "first" | "last" | "cur";
    icon: string;
    disabled?: boolean;
    title?: string;
    onClick?: React.MouseEventHandler;
}
export declare function PaginationButton({ type, disabled, icon, title, onClick, }: PaginationButtonProps): JSX.Element;
