// @ts-check
const fs = require("fs");
const path = require("path");

const COMPONENT_ROOT = path.resolve(__dirname, "../");
const LOCALE_DIR = path.resolve(COMPONENT_ROOT, "src/i18n/locale");
const JSON_OUT_DIR = path.resolve(LOCALE_DIR, "json");

if (!fs.existsSync(JSON_OUT_DIR)) {
  fs.mkdirSync(JSON_OUT_DIR);
}

/**
 * $1: comment
 * $2: key
 * $3: text
 */
const wordRegex = /\/\/ (.+)\n\s+(\w+):.*\(\s*\n\s*(.+)\s*\n\s*\)/g;

for (const lng of ["en_us", "ja", "ko"]) {
  const lngFilePath = path.resolve(LOCALE_DIR, `${lng}.tsx`);
  const lngFileSource = fs.readFileSync(lngFilePath, "utf8");

  const jsonLines = [];
  jsonLines.push("{");

  lngFileSource.replace(wordRegex, (_, comment, key, text) => {
    jsonLines.push(`  // ${comment}`);
    jsonLines.push(`  "${key}": ${JSON.stringify(text)},`);
    jsonLines.push("");
    return _;
  });
  jsonLines.push("}");
  jsonLines.push("");

  fs.writeFileSync(
    path.resolve(JSON_OUT_DIR, `${lng}.json`),
    jsonLines.join("\n"),
    "utf8"
  );
}
