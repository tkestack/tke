export declare const _bridge: (moduleName: string) => any;
export declare const _manager: any;
export declare const _util: any;
export declare const _appUtil: any;
export declare const _sdk: any;
