/**
 * @deprecated
 */
export declare const css: {
    /**
     * @deprecated
     *
     * 返回内置 CSS URL
     * @param preset 内置 CSS 名称
     */
    preset(preset: "tea-component"): any;
    /**
     * @deprecated
     *
     * 返回 CDN URL
     * @param pathname CDN 路径
     */
    cdn(pathname: string): string;
};
export declare type CSSPreset = "tea-component";
