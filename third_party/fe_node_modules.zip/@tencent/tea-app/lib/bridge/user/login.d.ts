/**
 * 清除用户当前登录态，并弹出登录对话框
 */
export declare function login(): any;
/**
 * 清除用户当前登录态
 */
export declare function logout(): any;
