export declare function getLastRegionId(): number;
export declare function setLastRegionId(regionId: number): void;
