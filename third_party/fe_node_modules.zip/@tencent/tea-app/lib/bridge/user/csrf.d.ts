export declare const getAntiCSRFToken: () => string;
