/**
 * 打印异常信息到浏览器控制台
 */
export declare function logTrace(leadMessage: string, trace: any): void;
