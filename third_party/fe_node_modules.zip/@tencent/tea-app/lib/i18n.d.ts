import { i18n } from "./core/i18n";
export = i18n;
