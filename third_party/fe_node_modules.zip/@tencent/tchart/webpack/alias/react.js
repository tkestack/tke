import * as React from "__react-global";

export * from "__react-global";
export default React;