import * as ReactDOM from "__react-dom-global";

export * from "__react-dom-global";
export default ReactDOM;