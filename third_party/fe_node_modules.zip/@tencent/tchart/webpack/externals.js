module.exports = {
  'babel-polyfill': 'null',
  '__react-global': 'none window.React16',
  '__react-dom-global': 'none window.ReactDOM16',
  '@tencent/tea-component': `commonjs @tencent/tea-component`,
  'moment': 'commonjs moment',
  'axios': 'commonjs axios',
};