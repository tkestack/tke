
/**
 * 要求主键的数据，一般用于数组
 */
export interface Identifiable {
  id: string | number;
}