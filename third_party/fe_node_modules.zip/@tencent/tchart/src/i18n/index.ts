import * as zh from './zh.json';
import * as en from './en.json';

export {
  zh,
  en
}

